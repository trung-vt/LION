#!/usr/bin/env bash
set -Eeuo pipefail
R=/store/LION/ttv22/pcm/results/pcm/tune1_ternary_20261109_v1/test45/random_one_per_category_v1
WT=/home/t/Documents/GIT/LION_pcm_tune1_ternary_20261109
PY=/home/t/micromamba/envs/lion_3/bin/python
cd "$WT"
exec 9>"$R/logs/baselines_resume.lock"
flock -n 9 || exit 66
export PYTHONDONTWRITEBYTECODE=1 LION_DATA_PATH=/store/LION/ttv22/pcm/data LION_TTV22_PATH=/store/LION/ttv22
export OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 CUBLAS_WORKSPACE_CONFIG=:4096:8
export CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES=GPU-05267a12-f71f-101d-59e5-05e5c430d8ef PYTHONUNBUFFERED=1
trap 'ec=$?;if [ "$ec" -ne 0 ];then echo "BASELINES_FAILED_EXIT_$ec $(date -Is)" > "$R/logs/baselines_resume_status.txt";fi' EXIT
echo "BASELINES_REPLAYING $(date -Is)" > "$R/logs/baselines_resume_status.txt"
for cat in CIGS Organic Perovskite Reference Silicone;do
 "$PY" -B -u -m scripts.experiments.pcm.tune1_ternary_20261109.replay_baselines_random_one --category "$cat"
done
"$PY" -B - <<'PYTHON'
from pathlib import Path
root=Path('/store/LION/ttv22/pcm/results/pcm/tune1_ternary_20261109_v1/test45/baselines/raw')
for m in ('zero_filled','spgl1_bp','spgl1_bpdn','pnp_admm_oracle','tv','utv_c60'):
    arr=list((root/m).glob('*.npy'))
    assert len(arr)==45,(m,len(arr))
print('ALL_6_REFERENCE_REPLAYS_READY',flush=True)
PYTHON
echo "BASELINES_COMPLETE $(date -Is)" > "$R/logs/baselines_resume_status.txt"
