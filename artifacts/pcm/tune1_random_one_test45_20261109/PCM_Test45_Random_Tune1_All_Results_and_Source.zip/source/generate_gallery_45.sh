#!/usr/bin/env bash
set -Eeuo pipefail
R=/store/LION/ttv22/pcm/results/pcm/tune1_ternary_20261109_v1/test45/random_one_per_category_v1
WT=/home/t/Documents/GIT/LION_pcm_tune1_ternary_20261109
PY=/home/t/micromamba/envs/lion_3/bin/python
cd "$WT"
exec 9>"$R/logs/gallery.lock"
flock -n 9 || exit 66
export PYTHONDONTWRITEBYTECODE=1 LION_DATA_PATH=/store/LION/ttv22/pcm/data LION_TTV22_PATH=/store/LION/ttv22
export OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 MPLBACKEND=Agg PYTHONUNBUFFERED=1
trap 'ec=$?;if [ "$ec" -ne 0 ];then echo "GALLERY_FAILED_EXIT_$ec $(date -Is)" > "$R/logs/gallery_status.txt";fi' EXIT
test -s "$R/analysis/test45_10_methods_per_image.csv"
for m in zero_filled spgl1_bp spgl1_bpdn pnp_admm_oracle tv utv_c60;do
 test "$(find "/store/LION/ttv22/pcm/results/pcm/tune1_ternary_20261109_v1/test45/baselines/raw/$m" -name '*.npy'|wc -l)" -eq 45
done
echo "GALLERY_RUNNING $(date -Is)" > "$R/logs/gallery_status.txt"
mkdir -p "$R/analysis/galleries"
for category in CIGS Organic Perovskite Reference Silicone;do
 p="$R/analysis/galleries/$category""_9_Pages.pdf"
 if [ -s "$p" ];then
  test "$(pdfinfo "$p"|awk '/^Pages:/{print $2}')" -eq 9
  echo "REUSE_GALLERY $category"
 else
  "$PY" -B -u -m scripts.experiments.pcm.tune1_ternary_20261109.random_one_gallery --category "$category"
 fi
done
p="$R/analysis/galleries/Test45_All_10_Methods_45_Pages.pdf"
if [ ! -s "$p" ];then
 pdfunite "$R/analysis/galleries/CIGS_9_Pages.pdf" \
          "$R/analysis/galleries/Organic_9_Pages.pdf" \
          "$R/analysis/galleries/Perovskite_9_Pages.pdf" \
          "$R/analysis/galleries/Reference_9_Pages.pdf" \
          "$R/analysis/galleries/Silicone_9_Pages.pdf" "$p"
fi
test "$(pdfinfo "$p"|awk '/^Pages:/{print $2}')" -eq 45
echo "GALLERY_ALL_45_PAGES_COMPLETE $(date -Is)" > "$R/logs/gallery_status.txt"
