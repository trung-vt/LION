#!/usr/bin/env bash
set -Eeuo pipefail
R=/store/LION/ttv22/pcm/results/pcm/tune1_ternary_20261109_v1/test45/random_one_per_category_v1
WT=/home/t/Documents/GIT/LION_pcm_tune1_ternary_20261109
PY=/home/t/micromamba/envs/lion_3/bin/python
cd "$WT"
exec 9>"$R/logs/gs_resume.lock"
flock -n 9 || exit 66
export PYTHONDONTWRITEBYTECODE=1 LION_DATA_PATH=/store/LION/ttv22/pcm/data LION_TTV22_PATH=/store/LION/ttv22
export OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 CUBLAS_WORKSPACE_CONFIG=:4096:8
export CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES=GPU-fcdc8ea0-7187-86d7-15ba-615774f8801f PYTHONUNBUFFERED=1
trap 'ec=$?;if [ "$ec" -ne 0 ];then echo "GS_RESUME_FAILED_EXIT_$ec $(date -Is)" > "$R/logs/gs_resume_status.txt";fi' EXIT
echo "GS_RESUMING $(date -Is)" > "$R/logs/gs_resume_status.txt"
for cat in CIGS Organic Perovskite Reference Silicone;do
  "$PY" -B -u -m scripts.experiments.pcm.tune1_ternary_20261109.random_one_test45 --method gs --category "$cat"
done
"$PY" -B - <<'PYTHON'
from pathlib import Path
r=Path('/store/LION/ttv22/pcm/results/pcm/tune1_ternary_20261109_v1/test45/random_one_per_category_v1/recon')
for m in ('gs','admm'):
    records=list((r/m).glob('*/records/*/*.json'))
    raws=list((r/m).glob('*/raw/*/*.npy'))
    assert len(records)==len(raws)==45,(m,len(records),len(raws))
print('ALL_90_NEW_RECONSTRUCTIONS_VERIFIED',flush=True)
PYTHON
echo "BOTH_45_COMPLETE $(date -Is)" > "$R/logs/status.txt"
echo "GS_RESUME_COMPLETE $(date -Is)" > "$R/logs/gs_resume_status.txt"
