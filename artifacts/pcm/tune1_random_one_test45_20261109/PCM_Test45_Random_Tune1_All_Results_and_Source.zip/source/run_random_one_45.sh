#!/usr/bin/env bash
set -Eeuo pipefail
WT=/home/t/Documents/GIT/LION_pcm_tune1_ternary_20261109
R=/store/LION/ttv22/pcm/results/pcm/tune1_ternary_20261109_v1/test45/random_one_per_category_v1
PY=/home/t/micromamba/envs/lion_3/bin/python
MOD=scripts.experiments.pcm.tune1_ternary_20261109.random_one_test45
mkdir -p "$R/logs"
exec 9>"$R/logs/controller.lock"
flock -n 9 || { echo "Another random-one controller is active";exit 66; }
cd "$WT"
export PYTHONDONTWRITEBYTECODE=1 LION_DATA_PATH=/store/LION/ttv22/pcm/data LION_TTV22_PATH=/store/LION/ttv22
export OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=2 MKL_NUM_THREADS=2
export CUBLAS_WORKSPACE_CONFIG=:4096:8 CUDA_DEVICE_ORDER=PCI_BUS_ID PYTHONUNBUFFERED=1
trap 'ec=$?;if [ "$ec" -ne 0 ];then echo "FAILED_EXIT_$ec $(date -Is)" > "$R/logs/status.txt";fi' EXIT
"$PY" -B - <<'PYTHON'
import json
from pathlib import Path
from scripts.experiments.pcm.tune1_ternary_20261109.test45_run import assert_all_frozen
a,t,f=assert_all_frozen()
assert len(a)==25 and len(t)==45 and len(f)==50
p=Path('/store/LION/ttv22/pcm/results/pcm/tune1_ternary_20261109_v1/test45/random_one_per_category_v1/selection.json')
x=json.loads(p.read_text())
assert x['status']=='frozen_before_test_access' and not x['using_test_metrics_for_selection']
assert len(x['selected_calibrations']['admm'])==len(x['selected_calibrations']['gs'])==5
print('FROZEN_ALL_50_SELECTIONS_AND_RANDOM_TEN_CHOICES_VERIFIED',flush=True)
PYTHON
echo "RUNNING_TEST45 $(date -Is)" > "$R/logs/status.txt"
(
 export CUDA_VISIBLE_DEVICES=GPU-05267a12-f71f-101d-59e5-05e5c430d8ef
 for cat in CIGS Organic Perovskite Reference Silicone;do
  "$PY" -B -u -m "$MOD" --method admm --category "$cat"
 done
) > "$R/logs/admm.log" 2>&1 & A=$!
(
 export CUDA_VISIBLE_DEVICES=GPU-fcdc8ea0-7187-86d7-15ba-615774f8801f
 for cat in CIGS Organic Perovskite Reference Silicone;do
  "$PY" -B -u -m "$MOD" --method gs --category "$cat"
 done
) > "$R/logs/gs.log" 2>&1 & B=$!
echo "ADMM_WORKER=$A GS_WORKER=$B" > "$R/logs/workers.txt"
ra=0;rb=0
wait "$A" || ra=$?
wait "$B" || rb=$?
if ((ra != 0 || rb != 0));then echo "ADMM_EXIT_$ra GS_EXIT_$rb" >&2;exit 1;fi
"$PY" -B - <<'PYTHON'
import json
from pathlib import Path
root=Path('/store/LION/ttv22/pcm/results/pcm/tune1_ternary_20261109_v1/test45/random_one_per_category_v1')
for method in ('admm','gs'):
 records=list((root/'recon'/method).glob('*/records/*/*.json'))
 raws=list((root/'recon'/method).glob('*/raw/*/*.npy'))
 assert len(records)==45 and len(raws)==45,(method,len(records),len(raws))
 print('COMPLETE',method,len(records),flush=True)
PYTHON
echo "TEST45_BOTH_METHODS_COMPLETE $(date -Is)" > "$R/logs/status.txt"
