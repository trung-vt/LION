#!/usr/bin/env bash
set -Eeuo pipefail
WT=/home/t/Documents/GIT/LION_pcm_tune1_ternary_20261109
ROOT=/store/LION/ttv22/pcm/results/pcm/tune1_ternary_20261109_v1
R="$ROOT/test45/random_one_per_category_v1"
PY=/home/t/micromamba/envs/lion_3/bin/python
mkdir -p "$R/logs"
exec 9>"$R/logs/replay.lock"
flock -n 9 || exit 66
cd "$WT"
export PYTHONDONTWRITEBYTECODE=1 LION_DATA_PATH=/store/LION/ttv22/pcm/data LION_TTV22_PATH=/store/LION/ttv22
export OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=2 MKL_NUM_THREADS=2
export CUBLAS_WORKSPACE_CONFIG=:4096:8 CUDA_DEVICE_ORDER=PCI_BUS_ID PYTHONUNBUFFERED=1
trap 'ec=$?;if [ "$ec" -ne 0 ];then echo "REPLAY_FAILED_EXIT_$ec $(date -Is)" > "$R/logs/replay_status.txt";fi' EXIT
test -s "$R/analysis/test45_10_methods_summary.json"
echo "RUNNING_REFERENCE_REPLAY $(date -Is)" > "$R/logs/replay_status.txt"
(
 export CUDA_VISIBLE_DEVICES=GPU-05267a12-f71f-101d-59e5-05e5c430d8ef
 for cat in CIGS Organic Perovskite Reference Silicone;do
  "$PY" -B -u -m scripts.experiments.pcm.tune1_ternary_20261109.replay_baselines --category "$cat"
 done
) > "$R/logs/baseline_replay.log" 2>&1 & A=$!
(
 export CUDA_VISIBLE_DEVICES=GPU-fcdc8ea0-7187-86d7-15ba-615774f8801f
 for cat in CIGS Organic Perovskite Reference Silicone;do
  "$PY" -B -u -m scripts.experiments.pcm.tune1_ternary_20261109.replay_c60 --category "$cat"
 done
) > "$R/logs/c60_replay.log" 2>&1 & B=$!
echo "BASELINES_PID=$A C60_PID=$B" > "$R/logs/replay_workers.txt"
a=0;b=0
wait "$A" || a=$?
wait "$B" || b=$?
if (( a!=0 || b!=0 ));then echo "REPLAY_FAIL_BASELINES_$a_C60_$b" >&2;exit 1;fi
"$PY" -B - <<'PYTHON'
from pathlib import Path
base=Path('/store/LION/ttv22/pcm/results/pcm/tune1_ternary_20261109_v1/test45/baselines/raw')
for m in ('zero_filled','spgl1_bp','spgl1_bpdn','pnp_admm_oracle','tv','utv_c60'):
  x=list((base/m).glob('*.npy'))
  assert len(x)==45,(m,len(x))
print('REFERENCE_6_METHODS_REPLAYED_ALL_45_IMAGES',flush=True)
PYTHON
echo "ALL_REFERENCE_ARRAYS_COMPLETE $(date -Is)" > "$R/logs/replay_status.txt"
