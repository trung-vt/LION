# Random Tune-1 on PCM test set 45, 9 November 2026

Status: COMPLETE. tuni confirmed. Exactly ten requested method labels.
One random validation-tuned parameter set per category and PnP algorithm,
frozen before examining test metrics. Five ADMM and five GS-PnP selected
configs. 45 matched 20% NPL-noisy acquisitions evaluated per method.

Requested references: zero-fill, SPGL1-BP, SPGL1-BPDN, PnP-ADMM-tuned-5,
GS-PnP validation-selected oracle, scalar TV, original UTV-C60,
GS-PnP-tuned-5, PnP-ADMM Tune-1, GS-PnP Tune-1. The old ADMM oracle and
expanded GS SSDU-5 were excluded, as requested.

- report/: editable TeX and completed PDF.
- gallery/: 45-page visual PDF plus 5 nine-page category PDFs.
- results/: 45-image ten-method metrics CSV, per-category/overall JSON,
  paired differences and comparisons.
- selected_calibrations/: ten frozen source JSON selections.
- new_test_records/: 90 raw reconstructed image metrics and solver records.
- raw_examples/: five category examples with ten raw arrays each.
- baseline_replay_provenance/: 45 records per replayed old method,
  including SPGL1-BP reconstruction differences.
- source/: scripts and frozen execution commands.

Full arrays for all 90 new test reconstructions and 270 historical
replays remain on tuni, without loss:
  /store/LION/ttv22/pcm/results/pcm/tune1_ternary_20261109_v1/
  test45/random_one_per_category_v1/recon/
  /store/LION/ttv22/pcm/results/pcm/tune1_ternary_20261109_v1/
  test45/baselines/raw/

The portable ZIP does not include all these large raw arrays,
but includes 50 representative raw arrays and complete scores/hashes.

Technical caveat: SPGL1-BP numerical replay differs slightly from the
original archived 450-case metrics for several cases. Comparison
tables retain the original archived baseline metrics. Visual
captions for BP are scored from the displayed replayed arrays.
No method parameters were changed to match a test score.

One random calibration choice per category is insufficient to
establish calibration selection variability. The report presents
this as one fixed retrospective comparison, not general optimality.
