"""Regenerate SSDU tuning figures using only frozen validation score JSON files."""
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT=Path("/store/LION/ttv22/pcm/results/pcm/ssdu_pnp_tuning_20261108_v1")
OUT=ROOT/"report/figures"
OUT.mkdir(parents=True,exist_ok=True)
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":9.5,"pdf.fonttype":42})
methods=("admm","gs")
stages=("pilot5","full50")
categories=("CIGS","Organic","Perovskite","Reference","Silicone")
series={}
for method in methods:
    for stage in stages:
        items=sorted((ROOT/stage/method/"candidates").glob("*/summary.json"))
        assert len(items)==(15 if method=="admm" else 18)
        series[(method,stage)]={}
        for p in items:
            record=json.loads(p.read_text())
            assert record["uses_ground_truth"] is False and record["test_set_access"] is False
            series[(method,stage)][p.parent.name]=record

fig,ax=plt.subplots(2,1,figsize=(8.2,6.1),layout="constrained")
for axis,method,title in zip(ax,methods,("PnP-ADMM","GS-PnP")):
    ids=sorted(series[(method,"pilot5")])
    for stage,colour,fmt,label in (("pilot5","#416D9E","o-","5 images"),
                                   ("full50","#B65E45","s-","50 images")):
        y=[series[(method,stage)][key]["loss"] for key in ids]
        axis.plot(range(len(ids)),y,fmt,color=colour,lw=1.5,ms=3.7,label=label)
    axis.set_xticks(range(len(ids)),[key.split("_")[-1] for key in ids])
    axis.grid(alpha=.24,axis="y")
    axis.set_title(title,weight="bold",loc="left")
    axis.set_ylabel("Held-out measurement MSE")
    axis.legend(ncol=2,frameon=False)
fig.savefig(OUT/"candidate_losses.pdf",bbox_inches="tight")
plt.close(fig)

fig,ax=plt.subplots(1,2,figsize=(8.2,3.7),layout="constrained")
for axis,method,title in zip(ax,methods,("PnP-ADMM","GS-PnP")):
    for stage,colour,fmt,label in (("pilot5","#416D9E","o-","5 images"),
                                   ("full50","#B65E45","s-","50 images")):
        frozen=json.loads((ROOT/stage/method/"frozen_selection.json").read_text())
        best=series[(method,stage)][frozen["winner"]["candidate_id"]]
        y=[best["category_means"][c] for c in categories]
        axis.plot(range(5),y,fmt,color=colour,lw=1.6,ms=4,label=label)
    axis.set_xticks(range(5),categories,rotation=30,ha="right")
    axis.set_title(title,weight="bold")
    axis.set_ylabel("Held-out measurement MSE")
    axis.grid(alpha=.24,axis="y")
    axis.legend(frameon=False)
fig.savefig(OUT/"category_losses.pdf",bbox_inches="tight")
plt.close(fig)
for f in sorted(OUT.glob("*.pdf")): print("FIGURE",f,f.stat().st_size)
