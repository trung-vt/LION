"""Archive report: relaxation-rule comparisons for scalar TV, TGV2 and TGV3.

Uses ONLY actual frozen archived reconstructions and local PDHG experiment
outputs. No solver or model code modified. Output is a standalone PDF.
"""
from pathlib import Path
import csv, json, math, textwrap, hashlib
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.colors import TwoSlopeNorm
from matplotlib.cm import ScalarMappable

ROOT=Path("/store/LION/ttv22/pcm/results/pcm")
BASE=ROOT/"perovskite0292_c60_ternary_20261109_v1/frozen_case.npz"
OUT=ROOT/"perovskite0292_relaxation_three_methods_archive_20261110_v1"
OUT.mkdir(parents=True,exist_ok=True)
CASES={}
for name in ("TV","TGV-2","TGV-3"):
  short={"TV":"tv","TGV-2":"tgv2","TGV-3":"tgv3"}[name]
  directory=ROOT/f"perovskite0292_{short}_cp_extrapolation_20261110_v1"
  assert directory.is_dir()
  with (directory/"summary.json").open() as f:info=json.load(f)
  with (directory/"metrics_by_iterations.csv").open() as f:history=list(csv.DictReader(f))
  with np.load(directory/"reconstructions.npz",allow_pickle=False) as z:
    ground=z["ground_truth"].copy()
    original=z["lion_existing"].copy()
    canonical=z["canonical_cp"].copy()
    measurement=z["measurement"].copy()
    idx=z["indices"].copy()
  assert len(history)==18
  assert len(original.shape)==2 and original.shape==(256,256)
  assert np.isfinite(original).all() and np.isfinite(canonical).all()
  CASES[name]={"data":directory,"summary":info,"history":history,
               "gt":ground,"original":original,"canonical":canonical,
               "measurement":measurement,"indices":idx}
with np.load(BASE,allow_pickle=False) as z:
  gt=z["ground_truth"].copy()
  y=z["measurement"].copy()
  indices=z["sampled_indices"].copy()
for c in CASES.values():
  np.testing.assert_array_equal(c["gt"],gt)
  np.testing.assert_array_equal(c["measurement"],y)
  np.testing.assert_array_equal(c["indices"],indices)
with np.load(ROOT/"perovskite0292_c60_ternary_with_baselines_20261109_v1/ternary_selected_reconstruction.npz",allow_pickle=False) as z:
  utv=z["reconstruction"].copy()
pnp=np.load(ROOT/"bad_images_for_utv_20261109_v3_23/raw_new9/Perovskite_0292.npy",allow_pickle=False)
S=("TV","TGV-2","TGV-3")
PARAMS={"TV":"lambda = 0.0240982484",
        "TGV-2":"alpha1 = 0.0282842712, alpha0 = 0.01",
        "TGV-3":"alpha2 = 0.032, alpha1 = 0.01, alpha0 = 0.024"}
N=8192
def get(name,variant,key):
  return float(CASES[name]["summary"][variant+"_final"][key])
def runrows(name,var):
  return sorted((r for r in CASES[name]["history"] if r["variant"]==var),
                key=lambda r:int(r["iterations"]))
def fnum(x,nd=3):
  return f"{x:,.{nd}f}"
def pct(name):
  a=get(name,"legacy","objective");b=get(name,"canonical","objective")
  return 100*(a-b)/a
def boxtext(fig,x,y,text,width=107,size=11,color="#263342",step=.037):
  lines=textwrap.wrap(text,width=width,break_long_words=False)
  fig.text(x,y,"\n".join(lines),fontsize=size,ha="left",va="top",
           linespacing=1.47,color=color)
  return y-step*(len(lines)+0.45)
def header(fig,num,title,sub):
  fig.text(.052,.964,f"{num}  {title}",size=23,weight="bold",va="top",color="#162438")
  fig.text(.052,.917,sub,size=11,va="top",color="#586477")
  fig.add_artist(plt.Line2D([.052,.948],[.887,.887],transform=fig.transFigure,
                            color="#bbcad9",lw=1.0))
def pagefoot(fig,text):
  fig.text(.052,.033,text,size=8.7,color="#626a75",va="bottom")
def tab(ax,headers,rows,widths=None,font=10):
  ax.axis("off")
  t=ax.table(cellText=rows,colLabels=headers,loc="center",cellLoc="center",
             colLoc="center",colWidths=widths)
  t.auto_set_font_size(False);t.set_fontsize(font);t.scale(1.0,1.72)
  for (i,j),cell in t.get_celld().items():
    cell.set_edgecolor("#cdd6df");cell.set_linewidth(.6)
    cell.set_facecolor("#edf2f7" if i==0 else ("#f8fafc" if i%2 else "white"))
    if i==0:cell.get_text().set_weight("bold")
  return t
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":10,
                      "pdf.fonttype":42,"figure.facecolor":"white",
                      "savefig.facecolor":"white"})
PATH=OUT/"Perovskite_0292_TV_TGV2_TGV3_Relaxation_Experiment_Report.pdf"
with PdfPages(PATH,metadata={
   "Title":"PCM Perovskite 0292: canonical Chambolle-Pock vs LION relaxation",
   "Author":"PCM reconstruction experiments",
   "Subject":"TV, TGV-2 and TGV-3 fixed-weight, fixed-data comparison"
}) as book:
  # Executive summary
  fig=plt.figure(figsize=(13.6,9.5))
  header(fig,1,"Executive summary","One frozen Perovskite 0292 acquisition | 20% Hadamard | NPL-default noise")
  y0=.858
  for lead,text in [
    ("Question.","Does replacing LION's interpolation-style primal relaxation with canonical Chambolle-Pock extrapolation improve reconstruction or optimisation?"),
    ("Answer.","For TV, TGV-2 and TGV-3, the reconstructed images are almost identical after 8,192 iterations. The canonical update gives a lower variational objective, often substantially earlier."),
    ("Largest benefit.","The objective falls much faster for TGV-2 and TGV-3. Canonical CP at 512 iterations already beats the legacy objective at 8,192 iterations for both models."),
    ("Practical limit.","Faster objective convergence does not imply better PSNR or preserved details on this one case. Each PDHG iteration has nearly the same cost under either rule.")
  ]:
    y0=boxtext(fig,.061,y0,lead+" "+text,width=124,size=11.1,step=.026)-.01
  fig.text(.061,.575,"Quality and objective after 8,192 iterations",size=13.5,weight="bold")
  rows=[]
  for name in S:
    for var,label in (("legacy","LION interpolation"),("canonical","Canonical CP")):
      rows.append([name,label,fnum(get(name,var,"psnr"),6),fnum(get(name,var,"ssim"),6),
                   fnum(get(name,var,"haarpsi"),6),fnum(get(name,var,"objective"),5),
                   fnum(get(name,var,"seconds"),3)])
  ax=fig.add_axes([.055,.258,.89,.295])
  tab(ax,["Method","Relaxation","PSNR (dB)","SSIM","HaarPSI","Objective","Time (s)"],rows,
      [.12,.22,.135,.12,.12,.155,.12],font=9.4)
  rows=[[n,f"{pct(n):.4f}%",f"{get(n,'canonical','psnr')-get(n,'legacy','psnr'):+.7f}",
         f"{1000*get(n,'legacy','seconds')/N:.3f}",
         f"{1000*get(n,'canonical','seconds')/N:.3f}"] for n in S]
  fig.text(.061,.241,"Effect size and per-iteration computational cost",size=13.1,weight="bold")
  ax=fig.add_axes([.075,.085,.84,.14])
  tab(ax,["Method","Objective reduction","Delta PSNR (dB)","LION ms/step","CP ms/step"],rows,
      [.13,.24,.24,.19,.19],font=9.7)
  pagefoot(fig,"Single-image oracle scalar weights are held fixed. All metrics are on unmodified reconstructions.")
  book.savefig(fig);plt.close(fig)

  # Protocol
  fig=plt.figure(figsize=(13.6,9.5))
  header(fig,2,"Experiment design and controlled variables","Same algorithms, identical parameters; only the relaxed-primal update differs")
  y0=.846
  y0=boxtext(fig,.062,y0,"Existing LION PDHG uses interpolation:  zbar[n+1] = (1-rho) z[n] + rho z[n+1].  Here rho=1, so zbar[n+1] = z[n+1].",width=129,size=11.5,step=.029)
  y0-=.02
  y0=boxtext(fig,.062,y0,"Canonical Chambolle-Pock uses extrapolation:  zbar[n+1] = z[n+1] + theta (z[n+1]-z[n]). Here theta=1, so zbar[n+1] = 2 z[n+1]-z[n].",width=129,size=11.5,step=.029)
  y0-=.025
  y0=boxtext(fig,.062,y0,"For all three methods, the solver's initial primal and dual variables were zero; lambda/alpha weights, sampling indices, measured currents, normalisation, boundary conditions, and step sizes (tau=sigma=0.18) were unchanged. We used two local solver copies differing by one line; no LION source was modified.",width=130,size=10.8,step=.028)
  fig.text(.061,.575,"PSNR-optimised scalar weights, selected previously on this image",size=13.2,weight="bold")
  ax=fig.add_axes([.072,.415,.84,.14])
  tab(ax,["Method","Fixed scalar weights","PDHG iterations"],[[n,PARAMS[n],"8,192"] for n in S],
      [.17,.59,.23],font=10.1)
  fig.text(.061,.393,"Convergence recording and validation",size=13.2,weight="bold")
  y=.365
  for line in [
    "Nine independent zero-start runs per rule: iterations 1, 2, 64, 256, 512, 1,024, 2,048, 4,096 and 8,192. The displayed final full reconstructions and metric tables use 8,192 iterations.",
    "The copied legacy implementation reproduced each original archived TV, TGV-2 and TGV-3 reconstruction exactly, pixel for pixel. The two rules agree after the first iteration and differ from the second.",
    "Objective is the complete method-specific primal functional: one half of the squared normalized PCM data residual plus the method's fixed scalar TV/TGV penalty. Objective values are comparable between relaxation rules for the SAME method, but not across TV, TGV-2 and TGV-3.",
    "Runtime is the elapsed time for each independent GPU run, including the solver loop and its per-run startup. Per-iteration runtime is total runtime divided by iteration count, so it is a useful estimate rather than an isolated kernel benchmark."
  ]:
    y=boxtext(fig,.062,y,"- "+line,width=133,size=10.6,step=.024)-.009
  pagefoot(fig,"Provenance: original PCM frozen test data; local LION/MRPro PDHG copies; NPL-default noise.")
  book.savefig(fig);plt.close(fig)

  # Full-image visual comparison
  fig=plt.figure(figsize=(18.6,12.7))
  header(fig,3,"Full-image reconstruction comparison","GT, PnP-ADMM and UTV benchmarks plus the six relaxation-rule reconstructions")
  full=[("Ground truth",gt,None),("PnP-ADMM-tuned-5",pnp,None),
        ("UTV C60, best rho",utv,None)]
  for n in S:
    full += [(f"{n} | LION",CASES[n]["original"],("legacy",n)),
             (f"{n} | Canonical CP",CASES[n]["canonical"],("canonical",n))]
  gs=fig.add_gridspec(3,3,left=.06,right=.95,bottom=.105,top=.81,
                      wspace=.21,hspace=.44)
  for i,(label,image,key) in enumerate(full):
    ax=fig.add_subplot(gs[i//3,i%3])
    ax.imshow(image,cmap="magma",vmin=0,vmax=1,interpolation="nearest")
    ax.set_xticks([]);ax.set_yticks([])
    sub="" if key is None else (
      f"PSNR {get(key[1],key[0],'psnr'):.6f} dB  |  "
      f"SSIM {get(key[1],key[0],'ssim'):.6f}\n"
      f"HaarPSI {get(key[1],key[0],'haarpsi'):.6f}  |  8,192 steps"
    )
    if key is None and i==1:sub="PSNR 32.369354 dB"
    if key is None and i==2:sub="PSNR 29.408306 dB"
    ax.set_title(label+"\n"+sub,fontsize=10.8,pad=8,
                 weight="bold" if key and key[0]=="canonical" else "normal")
  fig.text(.06,.056,"All panels use the same fixed [0,1] intensity range. Metrics use the original raw (unclipped) reconstructions.",
           fontsize=10.7)
  pagefoot(fig,"The canonical images are ACTUAL reconstructed arrays, not placeholders or copies of the legacy panels.")
  book.savefig(fig);plt.close(fig)

  # Paired detail comparisons
  fig=plt.figure(figsize=(18.6,13.2))
  header(fig,4,"Matched texture crops and signed differences","Each row compares the same method under both relaxation rules")
  gs=fig.add_gridspec(3,3,left=.09,right=.91,bottom=.12,top=.81,
                      wspace=.19,hspace=.46)
  for i,n in enumerate(S):
    a=CASES[n]["original"]
    b=CASES[n]["canonical"]
    diff=b-a
    mx=max(float(np.abs(diff).max()),1e-8)
    for j,(image,title,cmap,vmin,vmax) in enumerate([
      (a,f"{n} | LION","magma",0,1),
      (b,f"{n} | Canonical CP","magma",0,1),
      (diff,f"{n} | CP - LION","coolwarm",-mx,mx),
    ]):
      ax=fig.add_subplot(gs[i,j])
      if j<2:
        ax.imshow(image[40:185,65:205],cmap=cmap,vmin=vmin,vmax=vmax,interpolation="nearest")
      else:
        ax.imshow(image[40:185,65:205],cmap=cmap,vmin=vmin,vmax=vmax,interpolation="nearest")
      ax.set_xticks([]);ax.set_yticks([])
      sub=(f"Max |difference|: {mx:.3e}" if j==2
           else f"PSNR {get(n,'legacy' if j==0 else 'canonical','psnr'):.6f} dB")
      ax.set_title(title+"\n"+sub,fontsize=11,pad=6)
  fig.text(.09,.062,"Identical crop: rows 40-184, columns 65-204. Signed differences use a separate symmetric scale for each method.",
           fontsize=10.4)
  pagefoot(fig,"Small visual differences should not be mistaken for equivalence of the auxiliary TGV fields.")
  book.savefig(fig);plt.close(fig)

  # Convergence curves
  fig=plt.figure(figsize=(17.2,11.6))
  header(fig,5,"Objective convergence and reconstruction quality","Upper row: method-specific objectives. Lower row: PSNR at the same iteration checkpoints")
  gs=fig.add_gridspec(2,3,left=.065,right=.956,bottom=.14,top=.80,
                      wspace=.25,hspace=.46)
  for j,n in enumerate(S):
    h0=runrows(n,"LION_existing")
    h1=runrows(n,"canonical_CP")
    x=[int(r["iterations"]) for r in h0]
    for i,(metric,ylabel) in enumerate([("objective","Primal objective"),("psnr","PSNR (dB)")]):
      ax=fig.add_subplot(gs[i,j])
      for hist,label,marker in [(h0,"Existing LION","o"),(h1,"Canonical CP","s")]:
        vals=[float(r[metric]) for r in hist]
        ax.plot(x,vals,marker+"-",linewidth=1.7,markersize=4.5,label=label)
      ax.set_xscale("log",base=2)
      ax.set_xlim(64,10000)
      if i==0:
        values=[float(r[metric]) for r in h0+h1 if int(r["iterations"])>=64]
        low,high=min(values),max(values)
        ax.set_ylim(max(0,low-(high-low)*.08),high+(high-low)*.08)
      else:
        ax.set_ylim(28.0,30.65)
      ax.grid(alpha=.2)
      ax.set_ylabel(ylabel);ax.set_xlabel("PDHG iterations")
      ax.set_title(n+" | "+ylabel,fontsize=12,pad=8)
      if i==0:ax.legend(fontsize=8.6,loc="upper right")
  fig.text(.065,.085,"The curves show independently restarted runs. Canonical CP reduces the objective much sooner, especially for TGV-2 and TGV-3.",
           fontsize=11)
  pagefoot(fig,"The converged image quality need not improve even when the full variational objective decreases faster.")
  book.savefig(fig);plt.close(fig)

  # Runtime comparison and takeaway
  fig=plt.figure(figsize=(13.6,9.5))
  header(fig,6,"Iteration cost, savings and interpretation","Objective improvements at a fixed iteration budget versus a smaller computational budget")
  rows=[]
  for n in S:
    a=get(n,"legacy","seconds")
    b=get(n,"canonical","seconds")
    r0=next(r for r in runrows(n,"canonical_CP") if int(r["iterations"])==512)
    t512=float(r0["seconds"])
    legacy_obj=get(n,"legacy","objective")
    o512=float(r0["objective"])
    rows.append([n,f"{a:.3f}",f"{b:.3f}",f"{a/N*1000:.3f}",
                 f"{b/N*1000:.3f}",f"{o512:.5f}",f"{legacy_obj:.5f}",f"{t512:.3f}"])
  ax=fig.add_axes([.05,.60,.91,.22])
  tab(ax,["Method","LION 8192 s","CP 8192 s","LION ms/step","CP ms/step",
          "CP objective @512","LION objective @8192","CP 512 s"],
      rows,[.095,.105,.105,.125,.125,.14,.16,.11],font=9.0)
  y=.545
  for txt in [
    "Time per iteration. At 8,192 iterations, TV requires about 0.958 ms/step, TGV-2 about 1.486 ms/step, and TGV-3 about 2.031 ms/step under the existing rule. The canonical update adds almost no per-step cost.",
    "Relative cost. On this GPU, the TGV-2 step takes about 1.55x the TV step, while TGV-3 takes about 2.12x the TV step and 1.37x the TGV-2 step.",
    "Objective threshold benefit. Canonical TGV-2 and TGV-3 each reach a lower objective after 512 iterations than existing LION after 8,192. For TV, canonical CP needs 1,024 iterations to reach a lower objective than LION after 8,192. This does not certify a global optimum.",
    "Image quality caveat. Final PSNR changes are below 0.00005 dB in all three models. Earlier stopping under canonical CP may reduce compute time if the desired criterion is objective convergence, but should not be used without checking image quality and optimality gaps.",
    "Cross-method caution. The three models have different regularisers and objectives. Compare LION versus CP objectives within one method only. Compare TV/TGV-2/TGV-3 using reconstruction quality or wall-clock time, not their absolute objective magnitudes."
  ]:
    y=boxtext(fig,.062,y,"- "+txt,width=124,size=10.6,step=.024)-.012
  fig.text(.06,.105,"Primary references",size=12.8,weight="bold")
  fig.text(.06,.082,"Chambolle and Pock (2011), DOI 10.1007/s10851-010-0251-1; Bredies, Kunisch and Pock (2010), DOI 10.1137/090769521.",
           fontsize=9.1)
  pagefoot(fig,"Local experiment archive: no changes to LION or MRPro code. Same frozen PCM acquisition across all comparisons.")
  book.savefig(fig);plt.close(fig)
print("OUTPUT_PDF",PATH,PATH.stat().st_size)
print("METHOD_SUMMARY",json.dumps({n:{"legacy":CASES[n]["summary"]["legacy_final"],
                         "canonical":CASES[n]["summary"]["canonical_final"]} for n in S},indent=2)[:2500])

