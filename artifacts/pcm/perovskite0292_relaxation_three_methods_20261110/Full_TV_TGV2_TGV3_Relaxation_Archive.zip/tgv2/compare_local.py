"""Local-only TGV2 comparison: LION interpolation vs canonical CP extrapolation."""
import csv,hashlib,importlib.util,json,time
from pathlib import Path
import numpy as np,torch
from LION.config.sapm_config import SAPMModelConfig,AdaptivePDHGConfig
from LION.models.AdaptiveTGVPCMNetwork import AdaptiveTGVPCMNetwork
from LION.operators.PhotocurrentMapOp import PhotocurrentMapOp
from LION.pcm.pcm_sapm import PhotocurrentMapMRProOp
from LION.utils.metrics import compute_metrics
R=Path('/store/LION/ttv22/pcm/results/pcm')
O=R/'perovskite0292_tgv2_cp_extrapolation_20261110_v1'
STEPS=(1,2,64,256,512,1024,2048,4096,8192)
def sha(a):return hashlib.sha256(np.ascontiguousarray(a).tobytes()).hexdigest()
def mod(tag,path):
 spec=importlib.util.spec_from_file_location(tag,path)
 x=importlib.util.module_from_spec(spec);spec.loader.exec_module(x);return x
def score(x,gt):
 m=compute_metrics(recon=torch.from_numpy(x)[None,None],target=torch.from_numpy(gt)[None,None],data_range=1.)
 return {k:float(m[k]) for k in ('psnr','ssim','haarpsi','mse')}
def main():
 torch.set_num_threads(3);dev=torch.device('cuda:0')
 assert torch.cuda.is_available()
 with np.load(R/'perovskite0292_c60_ternary_20261109_v1/frozen_case.npz') as z:
  gt=z['ground_truth'].copy();y=z['measurement'].copy();ix=z['sampled_indices'].copy()
 previous=R/'perovskite0292_scalar_tgv_oracle_20261109_v1'
 old_meta=json.loads((previous/'selected.json').read_text())
 weights=(float(old_meta['selected']['alpha1']),float(old_meta['selected']['alpha0']))
 assert weights==(0.028284271247461905,0.01)
 assert sha(y)=='f8ffea66daeedaef8df0b1f711d609266d654d86af5dd6da34f6b13b2c287dfa'
 assert sha(ix)=='6a81317079c12733583d014d158fe0ecb46d3739f6d67cc027edfad0960cc9f5'
 cfg=SAPMModelConfig(name='local-cp',input_image='zeros',initial_image='zeros',n_iters=8192,
  backend='new',cnn=None,pdhg=AdaptivePDHGConfig(regularisation='TGV',
  primal_stepsize=.18,dual_stepsize=.18,initial_scale_factor_raw=.1,
  scale_factor_softplus_beta=1.,lambda_softplus_beta=1.,
  fd_pad_mode=['zeros','zeros'],fd_dim=[-2,-1],theta=1.))
 model=AdaptiveTGVPCMNetwork(cfg,None).to(dev).eval()
 A=PhotocurrentMapMRProOp(PhotocurrentMapOp(j_order=8,s_indices=ix,normalized=True,device=dev))
 K=model.make_stacked_operator(A)
 yt=torch.from_numpy(y).to(dev)
 x0=torch.zeros(1,1,256,256,device=dev)
 f=model.make_f(yt,lambda_reg=weights)
 variants={
  'LION_existing':mod('local_existing',O/'pdhg_lion_legacy_local.py'),
  'canonical_CP':mod('local_canonical',O/'pdhg_canonical_cp_local.py'),
 }
 records=[];saved={}
 for name,solver in variants.items():
  print('START',name,flush=True)
  for n in STEPS:
   torch.cuda.synchronize();start=time.perf_counter()
   with torch.inference_mode():
    z=solver.pdhg(f=f,g=model.g,operator=K,initial_values=model.make_initial_values(x0),
       max_iterations=n,primal_stepsize=.18,dual_stepsize=.18,relaxation=1.,use_checkpoint=False)
   torch.cuda.synchronize();elapsed=time.perf_counter()-start
   x=z[0].squeeze().cpu().numpy().astype('float32')
   assert x.shape==(256,256) and np.isfinite(x).all()
   m=score(x,gt)
   with torch.inference_mode():
    obj=float(f(*K(*z))[0])
    fidelity=.5*float((A(z[0])[0]-yt).square().sum())
    auxnorm=float(z[1].norm())
   row={'variant':name,'iterations':n,'seconds':elapsed,
       'objective':obj,'fidelity':fidelity,'auxiliary_norm':auxnorm,**m}
   records.append(row)
   if n in (1,2,512,2048,8192):saved[(name,n)]=x.copy()
   print('RESULT',name,n,'PSNR',round(m['psnr'],7),'SSIM',round(m['ssim'],6),
         'HaarPSI',round(m['haarpsi'],6),'objective',round(obj,7),
         'seconds',round(elapsed,3),flush=True)
  if name=='LION_existing':
   reference=np.load(previous/'best_tgv.npy')
   diff=np.max(np.abs(saved[(name,8192)]-reference))
   assert diff<3e-5,('baseline failed',diff)
   print('ARCHIVED_RESULT_REPRODUCED',float(diff),flush=True)
 assert np.array_equal(saved['LION_existing',1],saved['canonical_CP',1])
 diff2=float(np.max(np.abs(saved['LION_existing',2]-saved['canonical_CP',2])))
 assert diff2>0
 a=next(x for x in records if x['variant']=='LION_existing' and x['iterations']==8192)
 b=next(x for x in records if x['variant']=='canonical_CP' and x['iterations']==8192)
 delta=saved['canonical_CP',8192]-saved['LION_existing',8192]
 with (O/'metrics_by_iterations.csv').open('w',newline='') as fp:
  wr=csv.DictWriter(fp,fieldnames=list(records[0]),lineterminator='\n')
  wr.writeheader();wr.writerows(records)
 np.savez_compressed(O/'reconstructions.npz',ground_truth=gt,measurement=y,indices=ix,
  lion_existing=saved['LION_existing',8192],canonical_cp=saved['canonical_CP',8192],
  cp_minus_lion=delta,cp_512=saved['canonical_CP',512],
  lion_512=saved['LION_existing',512],cp_2048=saved['canonical_CP',2048],
  lion_2048=saved['LION_existing',2048],
  alpha1=np.float64(weights[0]),alpha0=np.float64(weights[1]))
 summary={
  'sample':'Perovskite_0292','frozen_measurement_sha256':sha(y),
  'frozen_indices_sha256':sha(ix),'weights':weights,
  'primal_stepsize':.18,'dual_stepsize':.18,'theta':1.,
  'sampled_iterations':STEPS,'first_iteration_identical':True,
  'second_iteration_max_abs_difference':diff2,
  'same_initial_primal_and_dual':True,
  'legacy_matches_archived':True,
  'legacy_final':a,'canonical_final':b,
  'psnr_difference_dB':b['psnr']-a['psnr'],
  'objective_difference':b['objective']-a['objective'],
  'max_abs_pixel_difference':float(np.max(np.abs(delta))),
  'rms_pixel_difference':float(np.sqrt(np.mean(delta*delta))),
  'only_changed_expression':'primal_new+rho*(primal_new-primal) instead of torch.lerp(primal,primal_new,rho)',
  'no_LION_code_change':True}
 (O/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 print('DONE',json.dumps({
 'PSNR_LION':a['psnr'],'PSNR_CP':b['psnr'],
 'PSNR_CHANGE':summary['psnr_difference_dB'],
 'OBJECTIVE_LION':a['objective'],'OBJECTIVE_CP':b['objective'],
 'OBJECTIVE_CHANGE':summary['objective_difference'],
 'MAXPIXELDIFF':summary['max_abs_pixel_difference']}),flush=True)
if __name__=='__main__':main()
