"""Preflight and fixed acquisition for CIGS0279 20% vs 10%."""
import os
os.environ["CUDA_DEVICE_ORDER"]="PCI_BUS_ID"
os.environ["CUDA_VISIBLE_DEVICES"]="GPU-fcdc8ea0-7187-86d7-15ba-615774f8801f"
os.environ["PYTHONDONTWRITEBYTECODE"]="1"
os.environ["OPENBLAS_NUM_THREADS"]="2"
os.environ["OMP_NUM_THREADS"]="2"
os.environ["MKL_NUM_THREADS"]="2"
import csv,hashlib,json,subprocess
from pathlib import Path
import numpy as np
from PIL import Image
import torch
from LION.operators.PhotocurrentMapOp import PhotocurrentMapOp
from LION.pcm.noise import PCMNoiseSimulation
from LION.pcm.simulation import simulate_pcm_acquisition
from LION.pcm_tools.pcm_sampling import sample_indices
from LION.utils.reproduce import seed_from_parts
from LION.experiments.pcm_presets.presets import QUICK_METHODS,NOISY_PCM_METHODS
from scripts.experiments.pcm.gs_pnp_gs_drunet_tuned_20261104.step6_frozen_reconstructor import load_frozen_selection

R=Path("/store/LION/ttv22/pcm/results/pcm")
O=R/"cigs0279_20pct_vs_10pct_comparison_v1"
S=R/"pcm_utv_fixed20_npl_default_20261103/cases/CIGS_0279.npz"
CSV=R/"pcm_utv_fixed20_npl_default_20261103/all_450_metrics.csv"
PROTO=R/"pcm_utv_fixed20_npl_default_20261103/protocol.json"
TV=R/"cigs0279_iteration_comparison_20261106/reconstructions.npz"
TVOR=R/"cigs0279_scalar_tv_oracle_20261106/best_reconstruction.npz"
GS=R/"gs_pnp_gs_drunet_step6_full_validation_20261104_v1/selected_config.json"
CKPT=R/"pcm_utv_4090_3x56_winner_snapshot_20261103/checkpoints/best_val_epoch60.pt"
CONFIG=R/"pcm_utv_4090_3x56_winner_snapshot_20261103/requested_config.yaml"
PIN=R/"pcm_utv_three_training_selection_20261103/source_9188b07/LION/pcm/pcm_sapm.py"
PNG=Path("/store/LION/ttv22/pcm/data/PCM Synthetic Data Set/Synthetic Data/Synthetic Data/CIGS/image0279.png")
NS="cigs0279_20pct_vs_10pct_comparison_v1"
def sha(x):return hashlib.sha256(np.ascontiguousarray(x).tobytes()).hexdigest()
def shafile(p):
    with p.open("rb") as f:return hashlib.file_digest(f,"sha256").hexdigest()
def emit(p,v):
    p.parent.mkdir(parents=True,exist_ok=True); b=(json.dumps(v,indent=2,sort_keys=True,allow_nan=False)+"\n").encode()
    if p.exists():assert p.read_bytes()==b,"Protocol drift "+str(p)
    else:p.write_bytes(b)
def save(k,rate,x):
    x=np.asarray(x).squeeze().copy()
    assert x.shape==(256,256) and np.isfinite(x).all(),(k,rate,x.shape)
    p=O/"reconstructions"/rate/(k+".npy");p.parent.mkdir(parents=True,exist_ok=True)
    if p.exists():assert np.array_equal(np.load(p,allow_pickle=False),x),"Reconstruction drift "+str(p)
    else:
        with p.open("xb") as f:np.save(f,x)
    print("SAVED",rate,k,sha(x),flush=True)
for p in (S,CSV,PROTO,TV,TVOR,GS,CKPT,CONFIG,PIN,PNG):assert p.exists(),p
O.mkdir(parents=True,exist_ok=True);(O/"source").mkdir(exist_ok=True)
with np.load(S,allow_pickle=False) as f:
    gt=f["ground_truth"].copy();y20=f["measurement"].copy();i20=f["sampled_indices"].copy()
    zf20=f["zero_filled"].copy();bp20=f["spgl1_bp"].copy();c60_20=f["C"].copy()
assert gt.shape==(256,256) and gt.dtype==np.float32
assert np.array_equal(gt,(np.array(Image.open(PNG).convert("L"))/255.).astype(np.float32))
assert y20.shape==(1,1,13107) and i20.shape==(13107,)
with CSV.open(newline="") as f: row=next(r for r in csv.DictReader(f) if r["category"]=="CIGS" and r["sample_id"]=="279")
assert row["measurement_sha256"]==sha(y20) and row["pattern_sha256"]==sha(i20.astype(np.int64))
with np.load(TV,allow_pickle=False) as f,np.load(TVOR,allow_pickle=False) as z:
    assert np.array_equal(gt,f["target"]) and np.array_equal(y20,f["y"]) and np.array_equal(i20,f["indices"])
    assert np.array_equal(gt,z["reference"]) and abs(float(z["lambda_reg"])-.0322552321)<1e-12
    tv20=f["ScalarTV_one_image_oracle_1024_512"].copy()
source_proto=json.loads(PROTO.read_text());assert source_proto["sampling_ratio"]==.2 and source_proto["coarse_J"]==6 and source_proto["J"]==8
assert source_proto["noise_parameter_sampling"] is False
gs=json.loads(GS.read_text())
assert gs["status"]=="frozen_before_test" and gs["method_id"]=="gs_pnp_gs_drunet_tuned"
assert gs["output"]=="paper_final_z"
assert load_frozen_selection()==gs
sp=QUICK_METHODS["spgl1"];b=NOISY_PCM_METHODS["spgl1_bpdn"]
assert (sp.factor,sp.iters,sp.debias_iters,sp.wavelet_name)==(1e5,100,10,"db4")
assert (b.noise_rms,b.factor,b.iters,b.opt_tol,b.debias)==(.06,1.,300,1e-6,False)
assert torch.cuda.is_available() and "4090" in torch.cuda.get_device_name(0)
torch.set_num_threads(4)
device=torch.device("cuda:0")
op20=PhotocurrentMapOp(j_order=8,s_indices=i20,normalized=True,device=device)
zf=op20.pseudo_inv(torch.from_numpy(y20).to(device)).cpu().squeeze().numpy()
assert np.allclose(zf,zf20,rtol=3e-6,atol=3e-6)
seeds={k:int(seed_from_parts(NS,"CIGS","0279",k)) for k in ("mask","noise")}
q=O/"page2_10pct_measurement.npz"
if q.exists():
    with np.load(q,allow_pickle=False) as f:
        i10=f["sampled_indices"].copy();y10=f["measurement"].copy();gx=f["ground_truth"].copy()
        assert int(f["mask_seed"])==seeds["mask"] and int(f["noise_seed"])==seeds["noise"] and np.array_equal(gx,gt)
    print("REUSE_10PCT_ACQUISITION",q,flush=True)
else:
    i10=sample_indices(j_order=8,sampling_ratio=.1,coarse_j=6,randomising_scheme="multilevel",rng=np.random.default_rng(seeds["mask"]))
    assert len(i10)==6553
    noise=PCMNoiseSimulation.npl_default(current_to_model_scale=1/3.5e-8,j_order=8,n_repeat_acquisitions=1)
    acq=simulate_pcm_acquisition(torch.from_numpy(gt)[None,None].to(device),j_order=8,sampled_indices=i10,noise=noise,rng=np.random.default_rng(seeds["noise"]),device=device,record_swaps=True)
    y10=acq.measurement.detach().cpu().numpy().copy()
    assert y10.shape==(1,1,6553) and y10.dtype==np.float32
    with q.open("xb") as f:np.savez_compressed(f,ground_truth=gt,sampled_indices=i10,measurement=y10,swap_flags=acq.swap_flags.cpu().numpy(),mask_seed=np.int64(seeds["mask"]),noise_seed=np.int64(seeds["noise"]))
    print("NEW_10PCT_ACQUISITION",q,flush=True)
op10=PhotocurrentMapOp(j_order=8,s_indices=i10,normalized=True,device=device)
zf10=op10.pseudo_inv(torch.from_numpy(y10).to(device)).cpu().squeeze().numpy()
for rate,items in (("20pct",{"target":gt,"zero_filled":zf20,"spgl1_bp":bp20,"tv_best_scalar":tv20,"utv_c60":c60_20}),("10pct",{"target":gt,"zero_filled":zf10})):
    for k,v in items.items():save(k,rate,v)
payload={
    "experiment":"CIGS 0279, 20% saved and 10% newly simulated NPL noisy acquisitions",
    "test_split":"held-out test, permutation position 916",
    "target_source":str(PNG),"target_sha256":sha(gt),"target_file_sha256":shafile(PNG),
    "20pct_source":str(S),"20pct_source_sha256":shafile(S),"20pct_measurement_sha256":sha(y20),"20pct_indices_sha256":sha(i20),
    "10pct_measurement_file":str(q),"10pct_measurement_sha256":sha(y10),"10pct_indices_sha256":sha(i10),
    "10pct_seeds":seeds,"10pct_seed_namespace":NS,"sampling_ratio":[.2,.1],"sample_counts":[13107,6553],
    "image_shape":[256,256],"forward":"normalised Hadamard PCM, J=8, multilevel, coarse_J=6",
    "noise_model":"PCMNoiseSimulation.npl_default(current_to_model_scale=1/3.5e-8,j_order=8,n_repeat_acquisitions=1)",
    "noise_settings":source_proto["noise_parameters_fixed"],
    "spgl1_bp":sp.serialize(),"spgl1_bpdn":b.serialize(),
    "pnp_admm_tuned":{"rho":.5,"sigma":.075,"min_iter":20,"max_iter":100,"eps_abs":1e-4,"eps_rel":1e-3,"consecutive_passes":5,"source":"step3_final_heldout.py"},
    "gs_pnp_tuned_frozen":gs["config"],"gs_pnp_tuned_stopping":gs["stopping"],"gs_pnp_output":"paper_final_z","gs_pnp_selection_sha256":shafile(GS),
    "scalar_tv":{"lambda_reg":.0322552321,"iters":512,"primal_step":.3,"dual_step":.3,"theta":1.,"source_at_20pct":str(TV),"note":"test-image oracle at 20%; unchanged at 10%"},
    "c60":{"config":str(CONFIG),"config_sha256":shafile(CONFIG),"checkpoint":str(CKPT),"checkpoint_sha256":shafile(CKPT),"epoch":60,"iters":512,"multiplier":1.0,"pinned_source":str(PIN),"pinned_source_sha256":shafile(PIN)},
    "code_git_head":subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip(),"device":torch.cuda.get_device_name(0),
    "render":{"cmap":"afmhot","limits":[0,1]},
    "caution":"20% TV uses test-specific oracle; 10% uses frozen 20% settings without retuning"
}
emit(O/"protocol.json",payload)
selfsource=Path(__file__).read_text()
p=O/"source/00_preflight.py"
if not p.exists():p.write_text(selfsource)
else:assert p.read_text()==selfsource
print("PREFLIGHT_COMPLETE",json.dumps({"10pct_seeds":seeds,"20pct_sha":sha(y20),"10pct_sha":sha(y10),"output":str(O)}),flush=True)
