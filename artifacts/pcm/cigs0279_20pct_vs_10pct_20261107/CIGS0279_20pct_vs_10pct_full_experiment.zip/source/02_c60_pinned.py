"""Original frozen C60 epoch60 at 10% from pinned pre-2026-11-03 source."""
import os,sys
from pathlib import Path
R=Path("/store/LION/ttv22/pcm/results/pcm")
PIN=R/"pcm_utv_three_training_selection_20261103/source_9188b07"
sys.path.insert(0,str(PIN))
os.environ["LION_DATA_PATH"]="/store/LION/ttv22/pcm/data"
os.environ["LION_TTV22_PATH"]="/store/LION/ttv22"
os.environ["CUDA_DEVICE_ORDER"]="PCI_BUS_ID"
os.environ["CUDA_VISIBLE_DEVICES"]="GPU-fcdc8ea0-7187-86d7-15ba-615774f8801f"
os.environ["OPENBLAS_NUM_THREADS"]="2"
os.environ["OMP_NUM_THREADS"]="2"
os.environ["MKL_NUM_THREADS"]="2"
os.environ["PYTHONDONTWRITEBYTECODE"]="1"
import hashlib
import numpy as np
import torch
from LION.operators.PhotocurrentMapOp import PhotocurrentMapOp
from LION.pcm.pcm_config import load_pcm_sapm_supervised_config_from_path,make_supervised_pcm_training_cases
from LION.pcm.pcm_sapm import load_trained_pcm_checkpoint_model,make_pcm_forward_data,forward_func_sapm_pcm
from LION.pcm import pcm_sapm
O=R/"cigs0279_20pct_vs_10pct_comparison_v1"
CFG=R/"pcm_utv_4090_3x56_winner_snapshot_20261103/requested_config.yaml"
CKPT=R/"pcm_utv_4090_3x56_winner_snapshot_20261103/checkpoints/best_val_epoch60.pt"
assert Path(pcm_sapm.__file__).resolve().is_relative_to(PIN.resolve()),pcm_sapm.__file__
device=torch.device("cuda:0")
torch.set_num_threads(4)
assert torch.cuda.is_available() and "4090" in torch.cuda.get_device_name(0)
with np.load(O/"page2_10pct_measurement.npz",allow_pickle=False) as f:
    y=f["measurement"].copy();idx=f["sampled_indices"].copy()
assert y.shape==(1,1,6553) and idx.shape==(6553,)
cf=load_pcm_sapm_supervised_config_from_path(CFG)
assert cf.model.n_iters==512 and cf.model.cnn.init_filters==56 and cf.model.cnn.n_blocks==3
assert cf.model.input_image=="cg" and cf.model.initial_image=="zeros"
model,epoch,step=load_trained_pcm_checkpoint_model(config=cf,cases=make_supervised_pcm_training_cases(cf),checkpoint_path=CKPT,device=device)
assert epoch==60
model.eval().requires_grad_(False)
op=PhotocurrentMapOp(j_order=8,s_indices=idx,normalized=True,device=device)
data=make_pcm_forward_data(config=cf,op=op,measurement=torch.from_numpy(y).to(device),key=0,sampling_ratio=.10,coarse_j=6,device=device)
with torch.inference_mode():
    out=forward_func_sapm_pcm(model=model,data=data,config=cf,skip_grad_checkpoint=True)
x=out.reconstruction.detach().cpu().squeeze().numpy().copy()
assert x.shape==(256,256) and np.isfinite(x).all()
p=O/"reconstructions/10pct/utv_c60.npy"
p.parent.mkdir(parents=True,exist_ok=True)
if p.exists():assert np.allclose(np.load(p,allow_pickle=False),x,rtol=1e-5,atol=1e-5)
else:
    with p.open("xb") as f:np.save(f,x)
q=O/"source/02_c60_pinned.py";src=Path(__file__).read_text()
if not q.exists():q.write_text(src)
else:assert q.read_text()==src
print("C60_ORIGINAL_10PCT_COMPLETE",p,"epoch",epoch,"step",step,"dtype",x.dtype,"sha256",hashlib.sha256(x.tobytes()).hexdigest(),"pinned",pcm_sapm.__file__,flush=True)
