"""Render CIGS0279 two-page matched PCM PDF with raw-array quality metrics."""
import os
os.environ["LION_DATA_PATH"]="/store/LION/ttv22/pcm/data"
os.environ["LION_TTV22_PATH"]="/store/LION/ttv22"
os.environ["MPLBACKEND"]="Agg"
os.environ["OPENBLAS_NUM_THREADS"]="2"
os.environ["OMP_NUM_THREADS"]="2"
os.environ["MKL_NUM_THREADS"]="2"
os.environ["PYTHONDONTWRITEBYTECODE"]="1"
import csv,hashlib,json,math
from pathlib import Path
import numpy as np
import torch
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from LION.pcm.randomized.figure_style import image_style
from LION.utils.metrics import compute_metrics
R=Path("/store/LION/ttv22/pcm/results/pcm")
O=R/"cigs0279_20pct_vs_10pct_comparison_v1"
NAMES=[
("target","Target"),
("zero_filled","Zero-filled"),
("spgl1_bp","SPGL1-BP"),
("spgl1_bpdn","SPGL1-BPDN"),
("pnp_admm_tuned","PnP-ADMM-DRUNet-tuned"),
("gs_pnp_tuned","GS-PnP-GS-DRUNet-tuned"),
("tv_best_scalar","TV-best scalar"),
("utv_c60","UTV C60 (original)")]
assert len(NAMES)==8
cmap,vmin,vmax=image_style("reconstruction")
assert (vmin,vmax)==(0.,1.)
gt=np.load(O/"reconstructions/20pct/target.npy",allow_pickle=False)
assert np.array_equal(gt,np.load(O/"reconstructions/10pct/target.npy",allow_pickle=False))
reference=torch.from_numpy(gt)[None,None]
data_range=float(gt.max()-gt.min())
def sha(x):return hashlib.sha256(np.ascontiguousarray(x).tobytes()).hexdigest()
def savejson(p,d):
    b=(json.dumps(d,indent=2,allow_nan=False,sort_keys=True)+"\n").encode()
    if p.exists():assert p.read_bytes()==b,"Metric drift "+str(p)
    else:p.write_bytes(b)
pages={}
for rate in ("20pct","10pct"):
    images={};metrics={}
    for key,title in NAMES:
        a=np.load(O/"reconstructions"/rate/(key+".npy"),allow_pickle=False)
        assert a.shape==(256,256) and np.isfinite(a).all()
        images[key]=a
        if key=="target":
            vals={"psnr":None,"ssim":1.,"haarpsi":1.,"mse":0.}
        else:
            res=compute_metrics(recon=torch.from_numpy(a)[None,None],target=reference,data_range=data_range)
            vals={name:float(res[name]) for name in ("psnr","ssim","haarpsi","mse")}
            assert all(math.isfinite(v) for v in vals.values()),(rate,key,vals)
        metrics[key]={**vals,"raw_sha256":sha(a)}
    savejson(O/("page1_20pct_metrics.json" if rate=="20pct" else "page2_10pct_metrics.json"),metrics)
    pages[rate]=(images,metrics)
pdf=O/"comparison_2pages.pdf"
if pdf.exists():raise FileExistsError(pdf)
plt.rcParams.update({"font.family":"DejaVu Sans","pdf.fonttype":42})
with PdfPages(pdf,metadata={"Title":"CIGS0279 20% vs 10% matched PCM reconstruction comparison","Author":"PCM reconstruction experiments"}) as doc:
    for page,rate in enumerate(("20pct","10pct"),start=1):
        images,metrics=pages[rate]
        fig=plt.figure(figsize=(18.4,10.5),facecolor="white")
        title="CIGS 0279 -- 20% sampling -- stored noisy measurement" if rate=="20pct" else "CIGS 0279 -- 10% sampling -- newly simulated noisy measurement"
        fig.text(.5,.973,title,fontsize=20,weight="bold",ha="center",va="top",color="#0F172A")
        fig.text(.5,.927,"NPL-default PCM noise  |  Normalised Hadamard J=8, coarse J=6  |  AFM-hot, fixed intensity [0,1]",fontsize=11.7,ha="center",va="top",color="#475569")
        for idx,(key,label) in enumerate(NAMES):
            r,c=divmod(idx,4)
            cx=(.125,.375,.625,.875)[c]
            y=.554 if r==0 else .144
            title_y=.876 if r==0 else .465
            ax=fig.add_axes([cx-.101,y,.202,.284])
            ax.imshow(images[key],cmap=cmap,vmin=vmin,vmax=vmax,interpolation="nearest")
            ax.set_xticks([]);ax.set_yticks([])
            for spine in ax.spines.values():
                spine.set_edgecolor("#CBD5E1");spine.set_linewidth(.65)
            fig.text(cx,title_y,label,ha="center",va="center",fontsize=11.3,weight="bold",color="#0F172A")
            m=metrics[key]
            ps="inf" if key=="target" else f'{m["psnr"]:.2f}'
            fig.text(cx,y-.023,f'PSNR {ps} dB  |  SSIM {m["ssim"]:.4f}',ha="center",va="top",fontsize=10.2,color="#1E293B")
            fig.text(cx,y-.052,f'HaarPSI {m["haarpsi"]:.4f}  |  MSE {m["mse"]:.3e}',ha="center",va="top",fontsize=10.0,color="#334155")
        if rate=="20pct":
            foot="All methods use one stored 20% acquisition. TV-best scalar uses a test-image oracle weight (lambda=0.0322552321) at 512 iterations."
        else:
            foot="PnP-ADMM-DRUNet-tuned, GS-PnP-GS-DRUNet-tuned, and TV-best scalar use their 20%-selected parameters and were not re-tuned for 10% sampling."
        fig.text(.5,.035,foot,ha="center",va="bottom",fontsize=10,color="#475569")
        fig.text(.975,.020,f'{page} / 2',ha="right",va="bottom",fontsize=9,color="#64748B")
        doc.savefig(fig);plt.close(fig)
        print("PAGE",page,rate,"PSNR",json.dumps({k:None if metrics[k]["psnr"] is None else round(metrics[k]["psnr"],3) for k,_ in NAMES}),flush=True)
print("PDF_COMPLETE",pdf,"bytes",pdf.stat().st_size,flush=True)
p=O/"source/03_render.py";b=Path(__file__).read_text()
if p.exists():assert p.read_text()==b
else:p.write_text(b)
