"""Run fixed CIGS0279 PCM methods without hyperparameter changes."""
import os
os.environ["CUDA_DEVICE_ORDER"]="PCI_BUS_ID"
os.environ["CUDA_VISIBLE_DEVICES"]="GPU-fcdc8ea0-7187-86d7-15ba-615774f8801f"
os.environ["LION_DATA_PATH"]="/store/LION/ttv22/pcm/data"
os.environ["LION_TTV22_PATH"]="/store/LION/ttv22"
os.environ["OPENBLAS_NUM_THREADS"]="2"
os.environ["OMP_NUM_THREADS"]="2"
os.environ["MKL_NUM_THREADS"]="2"
os.environ["PYTHONDONTWRITEBYTECODE"]="1"
import csv,hashlib,json,time
from copy import deepcopy
from pathlib import Path
import numpy as np
import torch
from LION.operators.PhotocurrentMapOp import PhotocurrentMapOp
from LION.pcm.denoiser import build_grayscale_denoiser
from LION.experiments.pcm_presets.presets import QUICK_METHODS,NOISY_PCM_METHODS
from LION.pcm.reconstruct import ReconInput,ScalarTVParameter,ScalarTVReconFn,spgl1_reconstruction
from LION.pcm.spgl1_bpdn import SPGL1BPDNReconFn
from scripts.experiments.pcm.pnp_admm_tuning.step3_final_heldout import live_admm
from scripts.experiments.pcm.gs_pnp_gs_drunet_tuned_20261104.step6_frozen_reconstructor import FrozenGSPnPGSDRUNetTuned
R=Path("/store/LION/ttv22/pcm/results/pcm")
O=R/"cigs0279_20pct_vs_10pct_comparison_v1"
S=R/"pcm_utv_fixed20_npl_default_20261103/cases/CIGS_0279.npz"
device=torch.device("cuda:0")
torch.set_num_threads(4)
def sh(a):return hashlib.sha256(np.ascontiguousarray(a).tobytes()).hexdigest()
def writejson(path,data):
    data=(json.dumps(data,indent=2,sort_keys=True,allow_nan=False)+"\n").encode()
    if path.exists():assert path.read_bytes()==data,"Drift "+str(path)
    else:path.write_bytes(data)
def save(k,pct,x):
    a=x.detach().cpu().squeeze().numpy().copy() if isinstance(x,torch.Tensor) else np.asarray(x).squeeze().copy()
    assert a.shape==(256,256) and np.isfinite(a).all()
    p=O/"reconstructions"/pct/(k+".npy");p.parent.mkdir(parents=True,exist_ok=True)
    if p.exists():
        assert np.allclose(np.load(p,allow_pickle=False),a,atol=1e-5,rtol=1e-5),str(p)
    else:
        with p.open("xb") as f:np.save(f,a)
    print("DONE",pct,k,"minmax",float(a.min()),float(a.max()),"sha",sh(a),flush=True)
def has(k,pct):return (O/"reconstructions"/pct/(k+".npy")).is_file()
assert (O/"protocol.json").is_file()
with np.load(S,allow_pickle=False) as f: y20=f["measurement"].copy();i20=f["sampled_indices"].copy()
with np.load(O/"page2_10pct_measurement.npz",allow_pickle=False) as f:y10=f["measurement"].copy();i10=f["sampled_indices"].copy()
assert y20.shape==(1,1,13107) and y10.shape==(1,1,6553)
cases={}
for pct,y,ind in (("20pct",y20,i20),("10pct",y10,i10)):
    op=PhotocurrentMapOp(j_order=8,s_indices=ind,normalized=True,device=device)
    yy=torch.from_numpy(y).to(device)
    ri=ReconInput(op=op,y=yy,x0=op.pseudo_inv(yy),i0=None)
    cases[pct]=(op,yy,ri)
    assert np.allclose(ri.x0.cpu().squeeze().numpy(),np.load(O/"reconstructions"/pct/"zero_filled.npy"),atol=3e-6,rtol=3e-6)
# 20% SPGL1 BP and TV were already archived and verified.
pct="10pct"
if not has("spgl1_bp",pct):
    op,yy,_=cases[pct]
    t=time.perf_counter()
    with torch.no_grad():
        rec=spgl1_reconstruction(op,yy,deepcopy(QUICK_METHODS["spgl1"]),device=device,shows_prog_bar=False)
    save("spgl1_bp",pct,rec)
    writejson(O/f"diagnostics_{pct}_spgl1_bp.json",{"seconds":time.perf_counter()-t,"iterations":100,"source":"QUICK_METHODS['spgl1']"})
# Matched SPGL1-BPDN pilot preset: no per-image or 10% retuning.
for pct,(op,yy,ri) in cases.items():
    if has("spgl1_bpdn",pct):continue
    t=time.perf_counter()
    with torch.no_grad():
        engine=SPGL1BPDNReconFn(deepcopy(NOISY_PCM_METHODS["spgl1_bpdn"]),device=device)
        result=engine(ri)
    save("spgl1_bpdn",pct,result.reconstruction)
    writejson(O/f"diagnostics_{pct}_spgl1_bpdn.json",{"seconds":time.perf_counter()-t,"diagnostics":result.diagnostics})
# Single-image TV oracle is reused at 20%, frozen lambda transferred at 10%.
pct="10pct"
if not has("tv_best_scalar",pct):
    op,yy,ri=cases[pct]
    t=time.perf_counter()
    solver=ScalarTVReconFn(config=ScalarTVParameter(lambda_reg=.0322552321,iters=512,primal_stepsize=.3,dual_stepsize=.3,theta=1.0,metric_every=512))
    with torch.no_grad(): result=solver(ri)
    save("tv_best_scalar",pct,result.reconstruction)
    writejson(O/f"diagnostics_{pct}_tv_best_scalar.json",{"seconds":time.perf_counter()-t,"lambda":.0322552321,"iterations":512})
# PnP-ADMM: 20%-validated rho=.5 sigma=.075 and fixed stopping rule.
if any(not has("pnp_admm_tuned",pct) for pct in cases):
    den=build_grayscale_denoiser(deepcopy(QUICK_METHODS["pnp_admm_drunet"].denoiser),device).eval()
    den.requires_grad_(False)
    for pct,(op,yy,ri) in cases.items():
        if has("pnp_admm_tuned",pct):continue
        with torch.no_grad():result=live_admm(op,yy,den)
        save("pnp_admm_tuned",pct,result["x"])
        diag={k:v for k,v in result.items() if k not in ("x","snapshots")}
        writejson(O/f"diagnostics_{pct}_pnp_admm_tuned.json",diag)
    del den
    torch.cuda.empty_cache()
# GS-PnP frozen selection: use paper final z, not an alternate original x.
if any(not has("gs_pnp_tuned",pct) for pct in cases):
    den=build_grayscale_denoiser(deepcopy(QUICK_METHODS["pnp_gs_deepinv_drunet"].denoiser),device).eval()
    den.requires_grad_(False)
    gs=FrozenGSPnPGSDRUNetTuned(den)
    for pct,(op,yy,ri) in cases.items():
        if has("gs_pnp_tuned",pct):continue
        t=time.perf_counter()
        with torch.no_grad():z=gs(op,yy)
        save("gs_pnp_tuned",pct,z)
        writejson(O/f"diagnostics_{pct}_gs_pnp_tuned.json",{"seconds":time.perf_counter()-t,**gs.last_diagnostics})
    del den
    torch.cuda.empty_cache()
p=O/"source/01_classical_pnp.py";b=Path(__file__).read_text()
if p.exists():assert p.read_text()==b
else:p.write_text(b)
print("CLASSICAL_AND_PNP_COMPLETE",flush=True)
