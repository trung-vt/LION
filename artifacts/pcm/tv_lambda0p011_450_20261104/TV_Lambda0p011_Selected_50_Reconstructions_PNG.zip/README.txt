Classical TV reconstruction, lambda=0.011, 1024 PDHG iterations.
Fixed 20% multilevel Hadamard and NPL-default PCM noise.
50 images exactly match the user-provided visual PDF selection.
These are individually displayed AFM-hot PNGs at 256x256, range [0,1].
Metrics and SHA-256 files are included in manifest.json.
