"""Render the frozen C60 rho grid outputs and package the experiment.

Inputs are metric files and 100 reconstruction arrays from c60_rho_sweep_20261107.py.
No model inference or tuning is performed by this rendering step.
"""
from __future__ import annotations

import argparse
import csv
import io
import json
from pathlib import Path
import re
import shutil
import subprocess
import zipfile

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import MultipleLocator

from LION.pcm.randomized.figure_style import image_style

ROOT=Path("/store/LION/ttv22/pcm/results/pcm")
OUT=ROOT/"c60_cigs0279_rho_sweep_v1"
PNG=OUT/"png_reconstructions"
FIG=OUT/"figures"
METRICS=("psnr","ssim","haarpsi","mse")
CATS=("Ground truth","Zero-filled","TV oracle (512)","C60 (rho=1)","C60 (best rho)")


def prepare():
    summary=json.loads((OUT/"summary.json").read_text())
    protocol=json.loads((OUT/"protocol.json").read_text())
    cases=list(csv.DictReader((OUT/"rho_sweep.csv").open(newline="")))
    assert len(cases)==100 and summary["status"]=="complete"
    assert len(list((OUT/"reconstructions").glob("rho_*.npz")))==100
    assert (OUT/"comparison_reference/step6_tv_oracle_reference.json").exists()
    assert protocol["tv_reference"].endswith("512 iterations, not 1024")
    rhos=np.array([float(r["rho"]) for r in cases])
    assert np.allclose(rhos,np.arange(1,101)/10,rtol=0,atol=1e-12)
    with np.load(OUT/"best_vs_baseline.npz") as d:
        imgs={
            "gt":d["ground_truth"].copy(),
            "zf":d["zero_filled"].copy(),
            "tv":d["TV_oracle_512"].copy(),
            "c60":d["baseline_reconstruction"].copy(),
            "best":d["best_reconstruction"].copy(),
            "map":d["original_map"].copy(),
        }
    assert all(img.shape==(256,256) for img in imgs.values())
    FIG.mkdir(parents=True,exist_ok=True); PNG.mkdir(parents=True,exist_ok=True)
    return summary,cases,imgs


def metric_curves(summary,cases):
    rho=np.array([float(x["rho"]) for x in cases])
    best=float(summary["rho_best"]); base=1.0
    ref=summary["reference_metrics"]
    fig,axes=plt.subplots(2,2,figsize=(14,8.9))
    fig.subplots_adjust(left=.075,right=.975,bottom=.13,top=.865,hspace=.36,wspace=.24)
    colors={"psnr":"#2878AD","ssim":"#187F63","haarpsi":"#A06DB1","mse":"#BE6B35"}
    for ax,k in zip(axes.flat,METRICS):
        y=np.array([float(x[k]) for x in cases])
        ax.plot(rho,y,color=colors[k],linewidth=1.8,zorder=2)
        idx=round(best*10)-1
        ax.scatter([best],[y[idx]],s=35,c="#C56836",zorder=4,label=f"Best PSNR rho={best:g}")
        ax.axvline(1,color="#777777",linewidth=1.1,linestyle="--",label="rho=1" if k=="psnr" else None)
        ax.axvline(best,color="#C56836",linewidth=1.1,linestyle=":",alpha=.8)
        ax.set_xlim(.1,10)
        ax.set_xlabel("Map multiplier rho",fontsize=10)
        ax.set_ylabel({"psnr":"PSNR (dB)","ssim":"SSIM","haarpsi":"HaarPSI","mse":"MSE"}[k])
        ax.set_title({"psnr":"PSNR (selection metric)","ssim":"SSIM",
                      "haarpsi":"HaarPSI","mse":"MSE (lower is better)"}[k],fontsize=12)
        ax.grid(alpha=.17,axis="y")
        if k=="psnr":
            baseline=ref["C60_rho_1"]["psnr"]; tv=ref["TV_oracle_lambda_0p0322552321_512"]["psnr"]
            ax.axhline(tv,color="#202020",linewidth=1,linestyle="-.",alpha=.7,label=f"TV oracle, 512 iters: {tv:.3f} dB")
            ax.axhline(baseline,color="#818181",linewidth=.8,alpha=.5,label=f"C60 rho=1: {baseline:.3f} dB")
            ax.legend(loc="lower right",fontsize=8,framealpha=.88)
        if k=="mse": ax.set_yscale("log")
    fig.suptitle("CIGS 0279: 100 global multipliers of the frozen C60 parameter map",
                 fontsize=17,y=.965)
    fig.text(.5,.912,
        "Exactly the same noisy 20% Hadamard measurement | C60 epoch 60 | 512 PDHG iterations",
        fontsize=10,ha="center",color="#4B5563")
    fig.text(.5,.055,
        f"PSNR-selected rho={best:g}; baseline C60 {ref['C60_rho_1']['psnr']:.3f} dB; "
        f"tuned C60 {ref['C60_rho_best']['psnr']:.3f} dB; oracle scalar TV (512) "
        f"{ref['TV_oracle_lambda_0p0322552321_512']['psnr']:.3f} dB",
        fontsize=9.7,ha="center",color="#4B5563")
    fig.savefig(FIG/"rho_metrics.pdf")
    fig.savefig(FIG/"rho_metrics.png",dpi=145)
    plt.close(fig)


def all_png_reconstructions():
    cmap,vmin,vmax=image_style("reconstruction")
    assert (vmin,vmax)==(0,1)
    for k in range(1,101):
        p=OUT/"reconstructions"/f"rho_{k:03d}.npz"
        dst=PNG/f"CIGS0279_C60_rho_{k:03d}_{k/10:.1f}.png"
        if dst.exists():continue
        with np.load(p) as f:
            img=f["reconstruction"].copy()
        assert img.shape==(256,256) and np.isfinite(img).all()
        plt.imsave(dst,img,cmap=cmap,vmin=vmin,vmax=vmax,format="png")
    imgs=list(PNG.glob("*.png"))
    assert len(imgs)==100
    print("RENDERED_100_PNGS",sum(p.stat().st_size for p in imgs),flush=True)


def comparison(summary,imgs):
    cmap,vmin,vmax=image_style("reconstruction")
    ref=summary["reference_metrics"]
    images=[imgs["gt"],imgs["zf"],imgs["tv"],imgs["c60"],imgs["best"]]
    keys=("ground_truth","zero_filled","TV_oracle_lambda_0p0322552321_512","C60_rho_1","C60_rho_best")
    fig,axes=plt.subplots(1,5,figsize=(16.7,5.7))
    fig.subplots_adjust(left=.02,right=.985,bottom=.21,top=.78,wspace=.06)
    for j,(ax,img,key,label) in enumerate(zip(axes,images,keys,CATS)):
        ax.imshow(img,cmap=cmap,vmin=vmin,vmax=vmax,interpolation="nearest")
        ax.set_xticks([]);ax.set_yticks([])
        ax.set_title(label,fontsize=12,weight="bold",pad=11)
        m=ref[key]
        a=("PSNR inf" if key=="ground_truth" else f"PSNR {m['psnr']:.3f} dB")
        ax.text(.5,-.09,a,transform=ax.transAxes,ha="center",va="top",fontsize=9.7)
        ax.text(.5,-.16,f"SSIM {m['ssim']:.4f} | HaarPSI {m['haarpsi']:.4f}",
                transform=ax.transAxes,ha="center",va="top",fontsize=8.75)
        ax.text(.5,-.23,f"MSE {m['mse']:.3e}",
                transform=ax.transAxes,ha="center",va="top",fontsize=8.8)
    fig.suptitle(
        f"CIGS 0279 | TV oracle 512 iterations vs U-TV C60 rho=1 and rho={summary['rho_best']:g}",
        fontsize=16.5,y=.94)
    fig.text(.5,.835,"NPL default noise | 20% multilevel Hadamard | AFM hot colourmap, fixed display [0,1]",
             fontsize=9.5,ha="center",color="#475569")
    fig.text(.5,.035,"Both TV and C60 use 512 PDHG iterations. Rho and TV lambda are oracle-tuned on this test image.",
             fontsize=9.3,ha="center",color="#475569")
    fig.savefig(FIG/"comparison.pdf")
    fig.savefig(FIG/"comparison.png",dpi=155)
    plt.close(fig)


def maps(summary,imgs):
    orig=imgs["map"]
    new=orig*float(summary["rho_best"])
    fig,axes=plt.subplots(1,3,figsize=(12.7,4.9))
    fig.subplots_adjust(left=.04,right=.96,bottom=.095,top=.86,wspace=.29)
    upper=float(max(orig.max(),new.max()))
    diff=new-orig
    titles=("C60 original map","C60 scaled map", "Difference (scaled - original)")
    vals=(orig,new,diff)
    for ax,v,title in zip(axes,vals,titles):
        if v is diff:
            im=ax.imshow(v,cmap="coolwarm",vmin=-max(abs(diff.min()),abs(diff.max())),
                         vmax=max(abs(diff.min()),abs(diff.max())))
        else:
            im=ax.imshow(v,cmap="magma",vmin=0.,vmax=upper)
        ax.set_title(title,fontsize=11)
        ax.set_xticks([]);ax.set_yticks([])
        fig.colorbar(im,ax=ax,fraction=.045,pad=.025)
    fig.suptitle(f"C60 parameter-map scaling: rho={summary['rho_best']:g}",fontsize=15)
    fig.savefig(FIG/"parameter_maps.pdf")
    fig.savefig(FIG/"parameter_maps.png",dpi=145)
    plt.close(fig)
    np.save(OUT/"best_scaled_lambda_map.npy",new.astype(np.float32))


def report(summary):
    b=summary["reference_metrics"]
    values=[
      ("Zero-filled",b["zero_filled"]),
      ("Scalar TV oracle 512",b["TV_oracle_lambda_0p0322552321_512"]),
      ("C60 rho=1",b["C60_rho_1"]),
      (f"C60 rho={summary['rho_best']:g}",b["C60_rho_best"]),
    ]
    best=summary["rho_best"]
    data_table="\n".join(
        f"{name} & {v['psnr']:.3f} & {v['ssim']:.4f} & {v['haarpsi']:.4f} & {v['mse']:.3e} \\\\"
        for name,v in values
    )
    tex=r"""\documentclass[10pt,a4paper]{article}
\usepackage[margin=14mm]{geometry}
\usepackage{graphicx,booktabs,array}
\setlength{\parindent}{0pt}
\begin{document}
\begin{center}
{\large\bfseries CIGS 0279: scalar multiplier sweep for C60}\par
\vspace{1mm}
{\small 20\% Hadamard sampling; NPL-default noise; one fixed measurement; 512 PDHG iterations}\par
\end{center}
"""
    tex+=rf"""
We predicted the positive C60 parameter map once, then reconstructed using
$\Lambda_{{\rho}}=\rho\Lambda_{{\mathrm{{C60}}}}$ for
$\rho\in\{{0.1,0.2,\ldots,10.0\}}$ (100 runs).
We selected $\rho^*={best:.1f}$ by the largest PSNR on the ground truth.
This is an \textbf{{oracle test-image experiment}}, not an unbiased test score.

\vspace{{2mm}}
\begin{{center}}
\begin{{tabular}}{{lrrrr}}
\toprule
Method & PSNR (dB) & SSIM & HaarPSI & MSE \\
\midrule
{data_table}
\bottomrule
\end{{tabular}}
\end{{center}}
\vspace{{-3mm}}
\begin{{center}}
\includegraphics[width=.94\linewidth]{{figures/rho_metrics.pdf}}\\[-1mm]
\includegraphics[width=.94\linewidth]{{figures/comparison.pdf}}
\end{{center}}
\end{{document}}
"""
    (OUT/"report.tex").write_text(tex)
    if shutil.which("pdflatex"):
        c=subprocess.run(
          ["pdflatex","-interaction=nonstopmode","-halt-on-error",
           "-output-directory",str(OUT),"report.tex"],
          cwd=OUT,capture_output=True,text=True,timeout=90
        )
        print("PDFLATEX_EXIT_CODE",c.returncode,flush=True)
        if c.returncode:
            print("PDFLATEX_TAIL",c.stdout[-2500:]+c.stderr[-1200:],flush=True)
    if not (OUT/"report.pdf").is_file():
        # Programmatic PDF fallback when the TeX compiler is absent.
        from matplotlib.backends.backend_pdf import PdfPages
        with PdfPages(OUT/"report.pdf") as pdf:
            for f in ("rho_metrics.png","comparison.png"):
                fig=plt.figure(figsize=(16,9))
                fig.figimage(plt.imread(FIG/f),xo=0,yo=0)
                pdf.savefig(fig);plt.close(fig)


def bundle():
    filename=OUT/"C60_CIGS0279_rho_0p1_to_10_full_experiment.zip"
    if filename.exists():filename.unlink()
    files=[]
    for p in sorted(OUT.rglob("*")):
        if not p.is_file() or p==filename or p.name.endswith(".zip"):continue
        if p.suffix in (".aux",".log",".out",".partial"):continue
        files.append(p)
    with zipfile.ZipFile(filename,"w",compression=zipfile.ZIP_DEFLATED,compresslevel=7) as z:
        for p in files:
            z.write(p,arcname=str(p.relative_to(OUT)))
    with zipfile.ZipFile(filename) as z:
        assert z.testzip() is None
        assert sum(n.startswith("png_reconstructions/") and n.endswith(".png") for n in z.namelist())==100
        assert sum(n.startswith("reconstructions/") and n.endswith(".npz") for n in z.namelist())==100
    print("ZIP",filename,filename.stat().st_size,"files",len(files),flush=True)


def main():
    s,rows,imgs=prepare()
    metric_curves(s,rows)
    comparison(s,imgs)
    maps(s,imgs)
    all_png_reconstructions()
    report(s)
    bundle()
    for p in (FIG/"rho_metrics.pdf", FIG/"comparison.pdf",FIG/"parameter_maps.pdf", OUT/"report.pdf",OUT/"report.tex"):
        print("DELIVERABLE",p,p.stat().st_size if p.exists() else "MISSING",flush=True)


if __name__=="__main__":main()
