"""Oracle global multiplier sweep for learned C60 TV map on frozen CIGS 0279.

Run with PYTHONPATH pointing at the archived source snapshot 9188b07, from
outside the live LION checkout. No shared solver or checkpoint is modified.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import os
from pathlib import Path
import time

import numpy as np
import torch

from LION.operators.PhotocurrentMapOp import PhotocurrentMapOp
from LION.pcm.pcm_config import (
    load_pcm_sapm_supervised_config_from_path,
    make_supervised_pcm_training_cases,
)
from LION.pcm.pcm_sapm import (
    load_trained_pcm_checkpoint_model,
    make_pcm_forward_data,
)
from LION.utils.metrics import compute_metrics

ROOT=Path("/store/LION/ttv22/pcm/results/pcm")
OUT=ROOT/"c60_cigs0279_rho_sweep_v1"
BASE=ROOT/"pcm_utv_fixed20_npl_default_20261103/cases/CIGS_0279.npz"
BASE_METRICS=ROOT/"pcm_utv_fixed20_npl_default_20261103/all_450_metrics.csv"
CKPT=ROOT/"pcm_utv_4090_3x56_winner_snapshot_20261103/checkpoints/best_val_epoch60.pt"
CFG=ROOT/"pcm_utv_4090_3x56_winner_snapshot_20261103/requested_config.yaml"
PIN=ROOT/"pcm_utv_three_training_selection_20261103/source_9188b07/LION/pcm/pcm_sapm.py"
TV_512=ROOT/"cigs0279_iteration_comparison_20261106/reconstructions.npz"
TV_ORACLE=ROOT/"cigs0279_scalar_tv_oracle_20261106/best_reconstruction.npz"
PRIOR_MAP=ROOT/"apmtv_cigs0279_global_multiplier_sweep_20261106/best_psnr_and_baseline.npz"
REF=OUT/"comparison_reference/step6_tv_oracle_reference.json"
GRID=tuple(i/10 for i in range(1,101))
METRICS=("psnr","ssim","haarpsi","mse")
GPU_UUID="GPU-fcdc8ea0-7187-86d7-15ba-615774f8801f"


def sha(path:Path)->str:
    with path.open("rb") as f:
        return hashlib.file_digest(f,"sha256").hexdigest()


def digest_arr(arr:np.ndarray)->str:
    return hashlib.sha256(np.ascontiguousarray(arr).tobytes()).hexdigest()


def write_once(path:Path, blob:bytes)->None:
    path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():
        if path.read_bytes()!=blob:raise RuntimeError("Immutable result changed: "+str(path))
        return
    part=path.with_suffix(path.suffix+".partial")
    with part.open("xb") as f:
        f.write(blob);f.flush();os.fsync(f.fileno())
    try:os.link(part,path)
    finally:part.unlink(missing_ok=True)


def json_once(path:Path, data:dict)->None:
    write_once(path,(json.dumps(data,indent=2,allow_nan=False)+"\n").encode())


def csv_once(path:Path, rows:list[dict])->None:
    b=io.StringIO()
    writer=csv.DictWriter(b,fieldnames=list(rows[0]))
    writer.writeheader();writer.writerows(rows)
    write_once(path,b.getvalue().encode())


def npz_once(path:Path, **arrays)->None:
    b=io.BytesIO()
    np.savez_compressed(b,**arrays)
    write_once(path,b.getvalue())


def setup():
    assert os.environ.get("CUDA_VISIBLE_DEVICES")==GPU_UUID, "Reserve the RTX 4090 only"
    assert "4090" in torch.cuda.get_device_name(0)
    torch.set_num_threads(4)
    assert PIN.resolve().exists() and REF.exists()
    import LION.pcm.pcm_config as pinned_module
    if not str(pinned_module.__file__).startswith(str(PIN.resolve().parents[2])):
        raise RuntimeError("Must import archived LION source, not current checkout")
    cfg=load_pcm_sapm_supervised_config_from_path(CFG)
    assert cfg.model.backend=="new"
    assert cfg.model.pdhg.regularisation=="TV"
    assert cfg.model.input_image=="cg" and cfg.model.initial_image=="zeros"
    assert cfg.model.n_iters==512 and cfg.model.cg.max_iters==20
    assert cfg.uses_normalized_op and cfg.model.cnn.init_filters==56
    assert cfg.model.cnn.n_blocks==3
    assert len(GRID)==100 and GRID[0]==.1 and GRID[-1]==10 and GRID[9]==1.0
    assert all(abs((i+1)/10-r)<1e-12 for i,r in enumerate(GRID))

    with np.load(BASE) as b:
        gt=b["ground_truth"].copy()
        zero=b["zero_filled"].copy()
        baseline=b["C"].copy()
        measurement=b["measurement"].copy()
        indices=b["sampled_indices"].copy()
    assert gt.shape==(256,256) and zero.shape==gt.shape and baseline.shape==gt.shape
    assert measurement.shape==(1,1,13107) and indices.shape==(13107,)
    with np.load(TV_512) as t,np.load(TV_ORACLE) as old:
        tv512=t["ScalarTV_one_image_oracle_1024_512"].copy()
        assert np.array_equal(gt,t["target"])
        assert np.array_equal(gt,old["reference"])
        assert np.array_equal(measurement,t["y"]) and np.array_equal(indices,t["indices"])
        tv_lambda=float(old["lambda_reg"])
        assert abs(tv_lambda-0.0322552321)<1e-12
    with BASE_METRICS.open(newline="") as f:
        row=next(r for r in csv.DictReader(f) if r["category"]=="CIGS" and r["sample_id"]=="279")
    assert row["measurement_sha256"]==digest_arr(measurement)
    assert row["pattern_sha256"]==digest_arr(indices)
    record=json.loads(REF.read_text())
    assert record["tv_oracle_lambda"]==tv_lambda
    assert record["measurement_sha256"]==digest_arr(measurement)
    assert record["sampled_indices_sha256"]==digest_arr(indices)

    protocol={
        "name":"c60_cigs0279_global_rho_sweep_100_values_v1",
        "status":"fixed_prior_to_rho_sweep",
        "case":"CIGS 0279","split":"test","test_permutation_position_1based":916,
        "experiment_kind":"per-image ground-truth oracle tuning, not unbiased held-out performance",
        "observation":"archived single NPL default differential measurement, 20% multilevel Hadamard, J=8, coarse_J=6",
        "measurement_sha256":digest_arr(measurement),
        "pattern_indices_sha256":digest_arr(indices),
        "baseline_npz_sha256":sha(BASE),
        "source_snapshot_pcm_sapm_sha256":sha(PIN),
        "checkpoint_epoch":60,"checkpoint_sha256":sha(CKPT),
        "config_sha256":sha(CFG),"pdhg_backend":"new/mrpro",
        "cg_input_iterations":20,"pdhg_initial_image":"zeros",
        "pdhg_iterations":512,"theta":1.0,
        "rho_grid_count":100,"rho_grid_first":.1,"rho_grid_last":10.0,"rho_grid_step":.1,
        "frozen_map_policy":"estimate map once from CG using C60, scale after softplus",
        "constant_over_sweep":["measurement","sampled_indices","CG_input","predicted_map","checkpoint","initial_image","PDHG_stepsizes","PDHG_iterations"],
        "selection":"max PSNR with ties at 1e-8 resolved by smaller rho",
        "baseline":"C60 same observation, rho=1, compare against saved C reconstruction",
        "tv_reference":"single-image scalar TV oracle lambda 0.0322552321 at 512 iterations, not 1024",
        "tv_reference_npz_sha256":sha(TV_512),
        "tv_oracle_source_npz_sha256":sha(TV_ORACLE),
        "tv_reference_manifest_sha256":sha(REF),
        "metrics":list(METRICS),
    }
    json_once(OUT/"protocol.json",protocol)
    if not torch.cuda.is_available():raise RuntimeError("CUDA missing")
    device=torch.device("cuda:0")
    model,epoch,step=load_trained_pcm_checkpoint_model(
        config=cfg,cases=make_supervised_pcm_training_cases(cfg),
        checkpoint_path=CKPT,device=device,
    )
    assert epoch==60 and step==270000
    model.eval().requires_grad_(False)
    op=PhotocurrentMapOp(j_order=8,s_indices=indices,normalized=True,device=device)
    mt=torch.from_numpy(measurement).to(device)
    data=make_pcm_forward_data(
        config=cfg,op=op,measurement=mt,key=0,
        sampling_ratio=.2,coarse_j=6,device=device,
    )
    with torch.inference_mode():
        lam=model.estimate_lambda_map(data.model_input.input_image,0).detach()
    assert lam.shape==(1,1,256,256) and bool((lam>0).all())
    lam_np=lam.squeeze().cpu().numpy().copy()
    with np.load(PRIOR_MAP) as f:
        prior=np.asarray(f["original_lambda_map"])
    map_difference=float(np.max(np.abs(prior-lam_np)))
    assert map_difference<1e-4,("Unexpected C60 map drift",map_difference)
    json_once(OUT/"map_stats.json",{
        "min":float(lam.min()),"max":float(lam.max()),"mean":float(lam.mean()),
        "median":float(lam.median()),"std":float(lam.std()),
        "dtype":str(lam.dtype),"shape":list(lam.shape),
        "sha256":digest_arr(lam_np),
        "prior_sweep_map_max_abs_difference":map_difference,
        "primal_stepsize":float(model.primal_stepsize),
        "dual_stepsize":float(model.dual_stepsize),
    })
    map_file=OUT/"original_lambda_map.npy"
    b=io.BytesIO();np.save(b,lam_np);write_once(map_file,b.getvalue())
    npz_once(OUT/"frozen_case.npz",
             ground_truth=gt,zero_filled=zero,
             baseline_C60=baseline,TV_oracle_512=tv512,
             measurement=measurement,indices=indices)
    return model,data,lam,gt,baseline,zero,tv512


def quality(recon:np.ndarray,reference:np.ndarray)->dict:
    gt=torch.from_numpy(reference)[None,None]
    pred=torch.from_numpy(recon)[None,None]
    dr=float(reference.max()-reference.min())
    score=compute_metrics(recon=pred,target=gt,data_range=dr)
    return {key:float(score[key]) for key in METRICS}


def run_candidate(k:int,model,data,lam,gt,baseline):
    rho=k/10.
    path=OUT/"reconstructions"/f"rho_{k:03d}.npz"
    jp=OUT/"case_metrics"/f"rho_{k:03d}.json"
    if path.exists() and jp.exists():
        with np.load(path) as q:
            assert abs(float(q["rho"])-rho)<1e-6
            result=q["reconstruction"]
        item=json.loads(jp.read_text())
        assert item["rho_index"]==k and abs(item["rho"]-rho)<1e-10
        assert abs(quality(result,gt)["psnr"]-item["psnr"])<1e-5
        print("RESUMED",k,format(rho,".1f"),"psnr",round(item["psnr"],6),flush=True)
        return item
    if path.exists() != jp.exists():
        raise RuntimeError("Partial case pair: "+str(path))
    torch.cuda.synchronize()
    start=time.perf_counter()
    with torch.inference_mode():
        rec=model(
            input_image=None,
            initial_image=data.model_input.initial_image,
            measurement=data.measurement,
            key=data.key,
            forward_op=data.forward_op,
            lambda_reg=lam*rho,
            max_iterations=512,
            use_checkpoint=False,
        )
    torch.cuda.synchronize()
    secs=time.perf_counter()-start
    image=rec.squeeze().cpu().numpy().astype(np.float32)
    assert image.shape==(256,256) and np.isfinite(image).all()
    if k==10:
        diff=float(np.max(np.abs(image-baseline)))
        assert diff<.002,("rho 1 differs from saved baseline",diff)
        print("BASELINE_CHECK",diff,quality(image,gt),flush=True)
    else:diff=None
    metrics=quality(image,gt)
    item={
        "rho_index":k,"rho":rho,"iterations":512,
        "elapsed_seconds":secs,"baseline_max_abs_difference":diff,
        **metrics,
    }
    npz_once(path,reconstruction=image,rho=np.float32(rho))
    json_once(jp,item)
    print("RHO_DONE",f"{k:03d}",f"{rho:.1f}",
          "psnr",round(metrics["psnr"],6),"ssim",round(metrics["ssim"],6),
          "haarpsi",round(metrics["haarpsi"],6),"runtime",round(secs,3),flush=True)
    return item


def summarise(gt,baseline,zero,tv512):
    records=[]
    for k in range(1,101):
        jp=OUT/"case_metrics"/f"rho_{k:03d}.json"
        p=OUT/"reconstructions"/f"rho_{k:03d}.npz"
        assert jp.exists() and p.exists()
        item=json.loads(jp.read_text())
        assert item["rho_index"]==k and abs(item["rho"]-k/10)<1e-12
        records.append(item)
    ranked=sorted(records,key=lambda r:(-r["psnr"],r["rho"]))
    winner=ranked[0]
    baseline_case=records[9]
    with np.load(OUT/"reconstructions"/f"rho_{winner['rho_index']:03d}.npz") as f:
        best=f["reconstruction"]
    npz_once(OUT/"best_vs_baseline.npz",
             rho_best=np.float32(winner["rho"]),
             best_reconstruction=best,baseline_reconstruction=baseline,
             ground_truth=gt,zero_filled=zero,TV_oracle_512=tv512,
             original_map=np.load(OUT/"original_lambda_map.npy"))
    csv_once(OUT/"rho_sweep.csv",records)
    compare={
        "ground_truth":{"psnr":None,"ssim":1.0,"haarpsi":1.0,"mse":0.},
        "zero_filled":quality(zero,gt),
        "TV_oracle_lambda_0p0322552321_512":quality(tv512,gt),
        "C60_rho_1":quality(baseline,gt),
        "C60_rho_best":quality(best,gt),
    }
    result={
        "status":"complete",
        "case":"CIGS/image0279.png",
        "grid":"0.1, 0.2, ..., 10.0, exactly 100 values",
        "iteration_count":512,"selected_by":"PSNR",
        "rho_best":winner["rho"],"winner":winner,
        "baseline_rho_1":baseline_case,
        "PSNR_improvement_vs_C60_rho_1_dB":winner["psnr"]-baseline_case["psnr"],
        "PSNR_difference_vs_TV_oracle_512_dB":winner["psnr"]-compare["TV_oracle_lambda_0p0322552321_512"]["psnr"],
        "reference_metrics":compare,
        "top10":ranked[:10],
        "protocol_sha256":sha(OUT/"protocol.json"),
        "map_sha256":sha(OUT/"original_lambda_map.npy"),
        "csv_sha256":sha(OUT/"rho_sweep.csv"),
        "no_test_set_method_selection_claim":True,
    }
    json_once(OUT/"summary.json",result)
    print("SWEEP_COMPLETE",json.dumps({
        "rho_best":winner["rho"],"best_psnr":winner["psnr"],
        "baseline_psnr":baseline_case["psnr"],
        "TV_512_psnr":compare["TV_oracle_lambda_0p0322552321_512"]["psnr"],
        "best_ssim":winner["ssim"],"best_haarpsi":winner["haarpsi"],
        "top10":ranked[:5],
    }),flush=True)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--max-candidates",type=int,default=100,
                        help="Run rho=1 plus first N grid points; continue later to 100")
    args=parser.parse_args()
    if not 1<=args.max_candidates<=100:parser.error("max-candidates must be 1..100")
    model,data,lam,gt,baseline,zero,tv512=setup()
    lock=OUT/"active_compute.lock"
    with lock.open("x") as f:f.write(str(os.getpid())+"\n")
    try:
        run_candidate(10,model,data,lam,gt,baseline)
        for k in range(1,args.max_candidates+1):
            if k==10:continue
            run_candidate(k,model,data,lam,gt,baseline)
        if args.max_candidates==100:summarise(gt,baseline,zero,tv512)
    finally:
        lock.unlink(missing_ok=True)


if __name__=="__main__":
    main()
