#!/usr/bin/env bash
set -euo pipefail
export LION_DATA_PATH=/store/LION/ttv22/pcm/data
export LION_TTV22_PATH=/store/LION/ttv22
export PYTHONDONTWRITEBYTECODE=1
export CUDA_DEVICE_ORDER=PCI_BUS_ID
export CUDA_VISIBLE_DEVICES=GPU-fcdc8ea0-7187-86d7-15ba-615774f8801f
export OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=2 MKL_NUM_THREADS=2
export PYTHONPATH=/store/LION/ttv22/pcm/results/pcm/pcm_utv_three_training_selection_20261103/source_9188b07
cd /tmp
/home/t/micromamba/envs/lion_3/bin/python -B -u /home/t/Documents/GIT/LION/scripts/experiments/pcm/c60_rho_sweep_20261107.py
cd /home/t/Documents/GIT/LION
/home/t/micromamba/envs/lion_3/bin/python -B -u scripts/experiments/pcm/c60_rho_sweep_render_20261107.py
