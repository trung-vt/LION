"""C60 UTV TV-PDHG, replace learned map with a strictly positive, offset zero-fill map times rho.

10 frozen PCM validation acquisitions, two fixed-seed samples/category.
Only lambda_reg changes relative to learned-map C60; all PDHG and
forward-data settings are kept unchanged. PSNR-oracle ternary search on
linear rho 0.0001..10, stopping when bracket width <= .01.
"""
from __future__ import annotations
import csv,hashlib,json,time
from pathlib import Path
import numpy as np,torch
from LION.operators.PhotocurrentMapOp import PhotocurrentMapOp
from LION.pcm.pcm_config import load_pcm_sapm_supervised_config_from_path,make_supervised_pcm_training_cases
from LION.pcm.pcm_sapm import load_trained_pcm_checkpoint_model,make_pcm_forward_data
from LION.utils.metrics import compute_metrics
R=Path('/store/LION/ttv22/pcm/results/pcm')
O=R/'utv_c60_shifted_zero_fill_map_val10_20261110_v1'
CFG=R/'pcm_utv_4090_3x56_winner_snapshot_20261103/requested_config.yaml'
CKPT=R/'pcm_utv_4090_3x56_winner_snapshot_20261103/checkpoints/best_val_epoch60.pt'
LOW,HIGH,TOL=0.0001,10.0,0.01
NITER=512
DIAGNOSTIC=(0.0001,0.001,0.01,0.03,0.1,0.3,0.5,1.,2.,5.,10.)
METRICS=('psnr','ssim','haarpsi','mse')
def digest(x):return hashlib.sha256(np.ascontiguousarray(x).tobytes()).hexdigest()
def score(im,gt):
    r=compute_metrics(recon=torch.from_numpy(im)[None,None].float(),
                      target=torch.from_numpy(gt)[None,None].float(),data_range=1.)
    return {k:float(r[k]) for k in METRICS}
def run(model,data,lam,rho):
    torch.cuda.synchronize()
    start=time.perf_counter()
    with torch.inference_mode():
        rec=model(input_image=None,initial_image=data.model_input.initial_image,
                  measurement=data.measurement,key=data.key,forward_op=data.forward_op,
                  lambda_reg=lam*float(rho),max_iterations=NITER,use_checkpoint=False)
    torch.cuda.synchronize()
    secs=time.perf_counter()-start
    x=rec.squeeze().detach().cpu().numpy().astype(np.float32)
    assert x.shape==(256,256) and np.isfinite(x).all()
    return x,secs
def save_csv(path,rows):
    with path.open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n')
        writer.writeheader();writer.writerows(rows)
def main():
    assert '4090' in torch.cuda.get_device_name(0)
    torch.set_num_threads(4)
    config=load_pcm_sapm_supervised_config_from_path(CFG)
    assert config.model.backend=='new'
    assert config.model.pdhg.regularisation=='TV'
    assert config.model.n_iters==512 and config.model.cg.max_iters==20
    assert config.model.input_image=='cg' and config.model.initial_image=='zeros'
    assert config.uses_normalized_op
    device=torch.device('cuda:0')
    model,epoch,step=load_trained_pcm_checkpoint_model(
      config=config,cases=make_supervised_pcm_training_cases(config),
      checkpoint_path=CKPT,device=device)
    assert epoch==60 and step==270000
    model.eval().requires_grad_(False)
    selection=json.loads((O/'frozen_10_manifest.json').read_text())
    assert len(selection)==10
    print('C60_MODEL_READY','epoch',epoch,'step',step,'samples',len(selection),
          'rho_search_bounds',LOW,HIGH,'tolerance',TOL,flush=True)
    summary=[]
    for manifest in selection:
        key=manifest['sample_name']
        out=O/'cases'/key
        out.mkdir(parents=True,exist_ok=True)
        finished=out/'result.json'
        if finished.exists() and (out/'images.npz').exists():
            record=json.loads(finished.read_text())
            assert record['sample']==key
            summary.append(record)
            print('RESUMED',key,flush=True)
            continue
        with np.load(O/f'{key}.npz',allow_pickle=False) as z:
            gt=z['gt'].copy()
            y=z['measurement'].copy()
            indices=z['indices'].copy()
            zf=z['zero_filled'].copy()
        assert gt.shape==zf.shape==(256,256)
        assert digest(y)==manifest['measurement_sha256']
        assert digest(indices)==manifest['sampled_indices_sha256']
        op=PhotocurrentMapOp(j_order=8,s_indices=indices,normalized=True,device=device)
        data=make_pcm_forward_data(config=config,op=op,
                   measurement=torch.from_numpy(y).to(device),
                   key=0,sampling_ratio=.2,coarse_j=6,device=device)
        with torch.inference_mode():
            learned_map=model.estimate_lambda_map(data.model_input.input_image,0).detach()
        assert learned_map.shape==(1,1,256,256)
        assert bool((learned_map>0).all())
        zero_fill_map=torch.from_numpy((zf-np.min(zf)+np.float32(1e-5)).astype(np.float32,copy=False).copy())[None,None].to(device)
        assert bool((zero_fill_map>0).all()) and abs(float(zero_fill_map.min())-1e-5)<1e-7
        learned,learned_seconds=run(model,data,learned_map,1.0)
        learned_stats=score(learned,gt)
        base=float(learned_stats['psnr'])
        records={}
        # rho is a global coefficient, not a normalised or learned map.
        def evaluate(rho,role='ternary'):
            rho=float(rho)
            assert LOW<=rho<=HIGH
            k=rho.hex()
            if k in records:return records[k]
            img,secs=run(model,data,zero_fill_map,rho)
            scores=score(img,gt)
            entry={'rho':rho,'role':role,'wall_seconds':secs,**scores}
            records[k]=entry
            print('EVAL',key,len(records),f'rho={rho:.7g}',
                f'psnr={scores["psnr"]:.5f}',flush=True)
            return entry
        diagnostic=[evaluate(r,'diagnostic') for r in DIAGNOSTIC]
        left,right=LOW,HIGH
        steps=[]
        while right-left>TOL:
            a=left+(right-left)/3.
            b=right-(right-left)/3.
            ra,rb=evaluate(a),evaluate(b)
            if ra['psnr']<rb['psnr']:
                left=a
            elif ra['psnr']>rb['psnr']:
                right=b
            else:
                left,right=a,b
            steps.append({'iteration':len(steps)+1,'left':left,'right':right,
                          'm1':a,'m2':b,'psnr1':ra['psnr'],'psnr2':rb['psnr'],
                          'width':right-left})
            assert len(steps)<70
        for fraction in (0,.25,.5,.75,1):
            evaluate(left+(right-left)*fraction,'bracket_probe')
        winner=max(records.values(),key=lambda x:x['psnr'])
        rho=winner['rho']
        winner_outside_bracket=not (left-1e-10<=rho<=right+1e-10)
        reconstructed,seconds=run(model,data,zero_fill_map,rho)
        best_stats=score(reconstructed,gt)
        assert abs(best_stats['psnr']-winner['psnr'])<2e-5
        result={
          'sample':key,'category':manifest['category'],'sample_id':manifest['sample_id'],
          'acquisition_sha256':digest(y),'sampling_indices_sha256':digest(indices),
          'selected_rho':rho,'ternary_bracket':[left,right],
          'ternary_width':right-left,'ternary_iterations':len(steps),
          'rho_evaluations':len(records),'best_outside_final_bracket':winner_outside_bracket,
          'learned_metrics':learned_stats,'replaced_metrics':best_stats,
          'psnr_delta_zero_minus_learned':best_stats['psnr']-learned_stats['psnr'],
          'learned_recon_seconds':learned_seconds,
          'selected_recon_seconds':seconds,
          'zero_filled_negative_fraction':manifest['zero_negative_fraction'],
          'shift_offset':float(-np.min(zf)+np.float32(1e-5)),
          'target_pre_rho_minimum':1e-5,
          'raw_zero_filled_min':manifest['zero_min'],
          'positive_map_def':'lambda_rho = rho * (zero_fill - min(zero_fill) + 1e-5), preserving signed values by shifting without clipping',
          'learned_map_stats':{'min':float(learned_map.min()),
               'max':float(learned_map.max()),'mean':float(learned_map.mean())},
          'replacement_map_stats':{'min':float(zero_fill_map.min()),
               'max':float(zero_fill_map.max()),'mean':float(zero_fill_map.mean())},
          'pdhg_iterations':NITER,'search_is_gt_psnr_oracle':True,
          'ternary_requires_unimodality':True,
        }
        save_csv(out/'all_evaluations.csv',list(records.values()))
        save_csv(out/'ternary_steps.csv',steps)
        np.savez_compressed(out/'images.npz',
            ground_truth=gt,zero_filled=zf,
            learned_map=learned_map.squeeze().cpu().numpy(),
            replacement_map=zero_fill_map.squeeze().cpu().numpy(),
            learned_recon=learned,replacement_recon=reconstructed,
            measurement=y,indices=indices,rho=np.float64(rho))
        finished.write_text(json.dumps(result,indent=2)+'\n')
        summary.append(result)
        print('CASE_FINISHED',key,'rho',rho,
              'learnedPSNR',base,'replacementPSNR',best_stats['psnr'],
              'diff',result['psnr_delta_zero_minus_learned'],
              'outside_bracket',winner_outside_bracket,
              'runs',len(records),flush=True)
    O.joinpath('c60_results.json').write_text(json.dumps(summary,indent=2)+'\n')
    print('C60_SWEEP_COMPLETE',len(summary),flush=True)
if __name__=='__main__':main()
