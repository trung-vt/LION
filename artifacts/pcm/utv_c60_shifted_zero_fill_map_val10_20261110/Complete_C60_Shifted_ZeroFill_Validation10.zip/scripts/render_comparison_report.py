"""PCM C60 positive-shifted zero-fill vs clipped zero-fill vs learned lambda.

10 validation images, identical observations, each case has an oracle rho
search using unchanged 512-iteration C60. All computation on tuni.
"""
from __future__ import annotations
from collections import defaultdict
import csv,json,math,textwrap
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages

ROOT=Path("/store/LION/ttv22/pcm/results/pcm")
OUT=ROOT/"utv_c60_shifted_zero_fill_map_val10_20261110_v1"
OLD=ROOT/"utv_c60_zero_fill_map_val10_20261110_v1"
METRICS=("psnr","ssim","haarpsi","mse")
CATS=("CIGS","Organic","Perovskite","Reference","Silicone")
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":10.5,
  "pdf.fonttype":42,"figure.facecolor":"white","savefig.facecolor":"white"})
def quality(x,gt):
    import torch
    from LION.utils.metrics import compute_metrics
    v=compute_metrics(recon=torch.from_numpy(x)[None,None].float(),
              target=torch.from_numpy(gt)[None,None].float(),data_range=1.)
    return {k:float(v[k]) for k in METRICS}
def scores_dict(obj):
    return {k:float(obj[k]) for k in METRICS}
def avg(vals):
    return float(np.mean(vals))
def std(vals):
    return float(np.std(vals,ddof=1)) if len(vals)>1 else 0.
def load_csv(p):
    with p.open(newline="") as f:return list(csv.DictReader(f))
def write_csv(p,rows):
    with p.open("w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator="\n")
        w.writeheader();w.writerows(rows)
def head(fig,title,sub):
    fig.text(.038,.977,title,va="top",weight="bold",fontsize=20.4,color="#152940")
    fig.text(.038,.934,sub,va="top",fontsize=11.3,color="#516379")
    fig.add_artist(plt.Line2D([.038,.965],[.899,.899],
                              transform=fig.transFigure,color="#c4cfdb",lw=1.1))
def foot(fig,text):
    fig.text(.04,.026,text,fontsize=9,color="#5c6b7d",va="bottom")
def draw_table(ax,header,rows,widths=None,font=10):
    ax.axis("off")
    table=ax.table(cellText=rows,colLabels=header,colWidths=widths,loc="center",
                   cellLoc="center",colLoc="center")
    table.auto_set_font_size(False);table.set_fontsize(font)
    table.scale(1,1.58)
    for (i,j),cell in table.get_celld().items():
        cell.set_edgecolor("#d5e0ea")
        cell.set_linewidth(.55)
        cell.set_facecolor("#e6eef7" if i==0 else "#f8fafc" if i%2 else "white")
        if i==0:cell.get_text().set_weight("bold")
    return table
def main():
    newres=json.loads((OUT/"c60_results.json").read_text())
    oldres=json.loads((OLD/"c60_results.json").read_text())
    m=json.loads((OUT/"frozen_10_manifest.json").read_text())
    pnps=load_csv(OUT/"pnp_metrics.csv")
    assert len(newres)==len(oldres)==len(m)==len(pnps)==10
    oldby={x["sample"]:x for x in oldres}
    newby={x["sample"]:x for x in newres}
    pnpby={x["sample"]:x for x in pnps}
    data=[]
    for row in m:
        key=row["sample_name"]
        a=newby[key]; b=oldby[key]; p=pnpby[key]
        with np.load(OUT/"cases"/key/"images.npz",allow_pickle=False) as z:
            shifted={k:z[k].copy() for k in z.files}
        with np.load(OLD/"cases"/key/"images.npz",allow_pickle=False) as z:
            clipped={k:z[k].copy() for k in z.files}
        np.testing.assert_array_equal(shifted["ground_truth"],clipped["ground_truth"])
        np.testing.assert_array_equal(shifted["measurement"],clipped["measurement"])
        np.testing.assert_array_equal(shifted["indices"],clipped["indices"])
        np.testing.assert_array_equal(shifted["zero_filled"],clipped["zero_filled"])
        learned_delta=float(np.max(np.abs(shifted["learned_recon"]-clipped["learned_recon"])))
        assert learned_delta<1e-5,(key,learned_delta)
        gt=shifted["ground_truth"]
        for obj,image in ((a["replaced_metrics"],shifted["replacement_recon"]),
                          (b["replaced_metrics"],clipped["replacement_recon"]),
                          (a["learned_metrics"],shifted["learned_recon"])):
            computed=quality(image,gt)
            assert abs(computed["psnr"]-float(obj["psnr"]))<2e-5,key
        assert a["ternary_width"]<=.0100001 and b["ternary_width"]<=.0100001
        assert abs(float(shifted["replacement_map"].min())-1e-5)<1e-7
        pnp=np.load(OUT/(key+"_pnp_admm_tuned5.npy"),allow_pickle=False)
        assert abs(quality(pnp,gt)["psnr"]-float(p["psnr"]))<2e-5
        data.append({"name":key,"category":row["category"],"id":int(row["sample_id"]),
             "new":a,"old":b,"pnp":p,"pnp_im":pnp,"shift":shifted,"clip":clipped})
    pooled={}
    def calc(method):
        if method=="pnp":return [float(d["pnp"]["psnr"]) for d in data]
        if method=="learned":return [float(d["new"]["learned_metrics"]["psnr"]) for d in data]
        if method=="clipped":return [float(d["old"]["replaced_metrics"]["psnr"]) for d in data]
        if method=="shifted":return [float(d["new"]["replaced_metrics"]["psnr"]) for d in data]
    for k in ("pnp","learned","clipped","shifted"):pooled[k]=calc(k)
    wins=sum(d["new"]["replaced_metrics"]["psnr"]>d["old"]["replaced_metrics"]["psnr"] for d in data)
    learned_wins=sum(d["new"]["replaced_metrics"]["psnr"]>d["new"]["learned_metrics"]["psnr"] for d in data)
    boundary=sum(abs(float(d["new"]["selected_rho"])-1e-4)<1e-12 for d in data)
    outside=sum(d["new"]["best_outside_final_bracket"] for d in data)
    rows=[]
    for d in data:
        oldps=float(d["old"]["replaced_metrics"]["psnr"])
        newps=float(d["new"]["replaced_metrics"]["psnr"])
        learnedps=float(d["new"]["learned_metrics"]["psnr"])
        rows.append({
          "category":d["category"],"sample_id":d["id"],"case":d["name"],
          "rho_clipped":float(d["old"]["selected_rho"]),
          "rho_shifted":float(d["new"]["selected_rho"]),
          "pnp_psnr":float(d["pnp"]["psnr"]),
          "learned_psnr":learnedps,"clipped_psnr":oldps,"shifted_psnr":newps,
          "shifted_minus_clipped_psnr":newps-oldps,
          "shifted_minus_learned_psnr":newps-learnedps,
          "pnp_ssim":float(d["pnp"]["ssim"]),
          "learned_ssim":float(d["new"]["learned_metrics"]["ssim"]),
          "clipped_ssim":float(d["old"]["replaced_metrics"]["ssim"]),
          "shifted_ssim":float(d["new"]["replaced_metrics"]["ssim"]),
          "pnp_haarpsi":float(d["pnp"]["haarpsi"]),
          "learned_haarpsi":float(d["new"]["learned_metrics"]["haarpsi"]),
          "clipped_haarpsi":float(d["old"]["replaced_metrics"]["haarpsi"]),
          "shifted_haarpsi":float(d["new"]["replaced_metrics"]["haarpsi"]),
          "shift_offset":float(d["new"]["shift_offset"]),
          "shifted_selected_rho_outside_final_bracket":bool(d["new"]["best_outside_final_bracket"]),
          "shifted_rho_evaluations":int(d["new"]["rho_evaluations"]),
          "clipped_rho_evaluations":int(d["old"]["rho_evaluations"]),
          "shifted_solve_seconds":float(d["new"]["selected_recon_seconds"]),
          "learned_solve_seconds":float(d["new"]["learned_recon_seconds"]),
          "clipped_solve_seconds":float(d["old"]["selected_recon_seconds"]),
        })
    write_csv(OUT/"comparison_all_10_metrics.csv",rows)
    summary={
      "case_count":len(data),"categories":list(CATS),
      "mean_psnr":{k:avg(v) for k,v in pooled.items()},
      "sample_std_psnr":{k:std(v) for k,v in pooled.items()},
      "mean_difference_shifted_minus_clipped":avg([r["shifted_minus_clipped_psnr"] for r in rows]),
      "mean_difference_shifted_minus_learned":avg([r["shifted_minus_learned_psnr"] for r in rows]),
      "shifted_better_than_clipped_count":wins,
      "shifted_better_than_learned_count":learned_wins,
      "shifted_best_at_lower_boundary_count":boundary,
      "shifted_best_outside_final_bracket_count":outside,
      "per_category":{
         c:{k:avg([r[k+"_psnr"] for r in rows if r["category"]==c])
             for k in ("pnp","learned","clipped","shifted")}
         for c in CATS
      },
      "same_data_and_C60_algorithm":True,
      "shifted_map":"rho*(ZF-min(ZF)+1e-5)",
      "clipped_map":"rho*maximum(ZF,0)",
      "ground_truth_rho_oracle":True,
      "note":"best observed values, ternary search assumes PSNR unimodality not proven",
      "checkpoint":"C60 epoch 60, 512 PDHG, 20 CG input iterations",
      "rho_range":[.0001,10.],
      "interval_width_tolerance":.01,
    }
    (OUT/"comparison_summary.json").write_text(json.dumps(summary,indent=2)+"\n")
    pdf=OUT/"PCM_C60_Shifted_vs_Clipped_vs_Learned_Validation10.pdf"
    with PdfPages(pdf,metadata={
      "Title":"C60 learned vs clipped vs minimum-shifted zero-fill map, 10 validation images",
      "Author":"PCM tuni experiment"}) as book:
        fig=plt.figure(figsize=(17.4,10.3))
        head(fig,"C60 regularisation: minimum-shifted zero-fill map",
             "10 frozen PCM validation images (2/category) | 20% Hadamard | NPL-default noise | 512 PDHG iterations")
        fig.text(.053,.847,f"Mean PSNR (dB): PnP {avg(pooled['pnp']):.3f}  |  "
           f"Learned C60 {avg(pooled['learned']):.3f}  |  "
           f"Clipped ZF {avg(pooled['clipped']):.3f}  |  "
           f"Shifted ZF {avg(pooled['shifted']):.3f}",fontsize=14.5,weight="bold")
        fig.text(.053,.806,
           f"Shifted versus clipped: {summary['mean_difference_shifted_minus_clipped']:+.3f} dB; "
           f"shifted versus learned: {summary['mean_difference_shifted_minus_learned']:+.3f} dB.",
           fontsize=12.4)
        fig.text(.053,.772,
            f"Shifted beats clipped on {wins}/10 images; shifted beats learned on {learned_wins}/10. "
            f"Best rho at lower boundary {boundary}/10; outside final bracket {outside}/10.",fontsize=11.6)
        fig.text(.053,.729,
           r"New positive map: $\Lambda_\rho(x)=\rho\left[x_{\rm ZF}(x)-\min(x_{\rm ZF})+10^{-5}\right]$. "
           "No clipping; same image shape and contrast.",fontsize=11.5)
        ax=fig.add_axes([.10,.315,.82,.345])
        x=np.arange(5)
        for j,(name,key) in enumerate([("PnP","pnp"),("Learned C60","learned"),("Clipped ZF map","clipped"),("Shifted ZF map","shifted")]):
            y=[summary["per_category"][cat][key] for cat in CATS]
            ax.bar(x+(j-1.5)*.19,y,.19,label=name)
        ax.set_xticks(x,CATS);ax.set_ylabel("Mean PSNR (dB)")
        ax.set_ylim(0);ax.grid(axis="y",alpha=.19);ax.legend(fontsize=10,ncol=2)
        fig.text(.052,.252,"Interpretation",weight="bold",fontsize=13.5)
        explain=("This repeat retains signed zero-filled pixel contrast by adding a constant offset to every pixel, "
            "so the minimum equals 1e-5 before rho scaling. All experiments use the same archived measurements "
            "and unchanged C60 checkpoint and PDHG. Rho was selected using GT PSNR on each validation image. "
            "The clipped and shifted results both use finite search ranges; boundary results and non-unimodality "
            "must be considered before drawing a general conclusion.")
        fig.text(.052,.220,"\n".join(textwrap.wrap(explain,139)),fontsize=11.4,va="top",linespacing=1.5)
        foot(fig,"The validation subset and PnP baselines are identical to the earlier clipped zero-fill probe.")
        book.savefig(fig);plt.close(fig)
        fig=plt.figure(figsize=(17.4,10.3))
        head(fig,"Per-image scores and parameter multipliers","Positive PSNR gain means shifted zero-fill outperforms the previous clipped zero-fill map.")
        body=[]
        for r in rows:
            body.append([r["case"],f'{r["rho_clipped"]:.5g}',f'{r["rho_shifted"]:.5g}',
             f'{r["pnp_psnr"]:.2f}',f'{r["learned_psnr"]:.2f}',
             f'{r["clipped_psnr"]:.2f}',f'{r["shifted_psnr"]:.2f}',
             f'{r["shifted_minus_clipped_psnr"]:+.2f}',f'{r["shifted_minus_learned_psnr"]:+.2f}'])
        ax=fig.add_axes([.032,.37,.936,.45])
        draw_table(ax,["Image","Old rho","Shift rho","PnP PSNR","Learned PSNR",
              "Clipped PSNR","Shifted PSNR","Shift - clip","Shift - learned"],
              body,widths=[.17,.09,.095,.105,.108,.106,.108,.11,.11],font=9.4)
        fig.text(.055,.297,"Search protocol and cautions",size=13.2,weight="bold")
        notes=[
          "Fixed rho interval [0.0001,10]. Linear-rho ternary search stops at interval width 0.01. Log-spaced diagnostic candidates and final bracket probes are also evaluated.",
          "The best observed candidate is selected, even if it is outside the final ternary interval. Non-unimodality is possible; this is not a mathematically certified global optimum.",
          "The learned checkpoint and PnP hyperparameters were selected using validation data before this experiment. The rho multiplier is also chosen with validation GT, so all conclusions are exploratory."
        ]
        y=.26
        for note in notes:
            fig.text(.055,y,"\n".join(textwrap.wrap(note,145)),fontsize=10.5,va="top",linespacing=1.5)
            y-=.067
        foot(fig,"Same 10 frozen validation acquisitions, same C60 and PnP baselines. Per-image search traces are archived.")
        book.savefig(fig);plt.close(fig)
        fig=plt.figure(figsize=(17.4,10.3))
        head(fig,"Experiment definition and positivity treatment",
           "Two simple maps from exactly the same zero-filled reconstruction, compared with learned C60 and PnP.")
        sections=[
          ("Shared solver","C60 epoch-60 checkpoint; 512 TV-PDHG iterations; 20 CG iterations for original learned-map input; "
            "zero image initialization; normalized 20% multilevel Hadamard forward operator. No LION source changes."),
          ("Previous clipped map",r"$\Lambda_{\rho}^{\rm clip}(x)=\rho\max(x_{\rm ZF}(x),0)$."
            " Negative pixels were set to zero; this changes the local contrast and may give exactly zero weights."),
          ("New shifted map",r"$\Lambda_{\rho}^{\rm shift}(x)=\rho[x_{\rm ZF}(x)-\min(x_{\rm ZF})+10^{-5}]$."
            " Uses each image's own raw minimum. No clipping, no upper bound. The parameter map minimum BEFORE rho is 1e-5."),
          ("Original learned map","The original learned positive C60 parameter map is predicted by the same pretrained CNN. "
            "It is neither shifted nor globally rescaled; it is recomputed and verified against the earlier archived C60 output."),
          ("Comparison","GT, zero-fill, PnP-ADMM-tuned-5 (rho=0.5, sigma=0.075), C60 learned-map, C60 clipped-map with best observed rho, "
            "and C60 shifted-map with best observed rho."),
          ("Selection and interpretation","One rho per image chosen by GT PSNR. C60 learned-map and PnP baseline are fixed. "
            "The scalar selection is oracle-only and may not generalise; repeat experiments on independent data are needed "
            "for claims about performance.")
        ]
        y=.850
        for title,text in sections:
            fig.text(.06,y,title,weight="bold",fontsize=13,va="top")
            lines=textwrap.wrap(text,width=142)
            fig.text(.06,y-.033,"\n".join(lines),fontsize=11.1,va="top",linespacing=1.6)
            y-=.126 if len(lines)>2 else .105
        foot(fig,"Full acquisitions, individual map arrays and each rho-evaluation trace are in the complete ZIP archive.")
        book.savefig(fig);plt.close(fig)
        for i,d in enumerate(data,1):
            a=d["new"];b=d["old"];n=d["name"];p=d["pnp"]
            img=d["shift"];oldimg=d["clip"]
            learned=img["learned_recon"]
            clipped=oldimg["replacement_recon"]
            shifted=img["replacement_recon"]
            gt=img["ground_truth"]
            images=[
              ("Ground truth",gt,None),
              ("Zero-filled",img["zero_filled"],quality(img["zero_filled"],gt)),
              ("PnP-ADMM-tuned-5",d["pnp_im"],scores_dict(p)),
              ("Learned C60",learned,a["learned_metrics"]),
              (f"Clipped ZF | rho={float(b['selected_rho']):.4g}",clipped,b["replaced_metrics"]),
              (f"Shifted ZF | rho={float(a['selected_rho']):.4g}",shifted,a["replaced_metrics"])
            ]
            fig=plt.figure(figsize=(23.0,11.7))
            head(fig,f"{i:02d}. {n}",
               f"Validation position {next(m['validation_position'] for m in json.loads((OUT/'frozen_10_manifest.json').read_text()) if m['sample_name']==n)} "
               "| same measurement | same C60 (512 iterations) | per-image GT-PSNR selected rho")
            grid=fig.add_gridspec(2,6,left=.024,right=.977,top=.813,bottom=.137,
                  wspace=.15,hspace=.42)
            for j,(label,im,metric) in enumerate(images):
                ax=fig.add_subplot(grid[0,j])
                ax.imshow(im,cmap="magma",vmin=0,vmax=1,interpolation="nearest")
                ax.set_xticks([]);ax.set_yticks([])
                sub="" if metric is None else (
                   f"\nPSNR {float(metric['psnr']):.2f} dB | SSIM {float(metric['ssim']):.3f}"
                   f"\nHaarPSI {float(metric['haarpsi']):.3f}")
                ax.set_title(label+sub,fontsize=10.1,pad=8,
                  weight="bold" if j==5 else "normal")
            maps=[
             ("Learned lambda map",img["learned_map"],False),
             ("Clipped ZF lambda * rho",oldimg["replacement_map"]*float(b["selected_rho"]),False),
             ("Shifted ZF lambda * rho",img["replacement_map"]*float(a["selected_rho"]),False),
             ("GT crop",gt[40:185,65:205],True),
             ("Learned C60 crop",learned[40:185,65:205],True),
             ("Shifted ZF crop",shifted[40:185,65:205],True)
            ]
            for j,(label,im,isimage) in enumerate(maps):
                ax=fig.add_subplot(grid[1,j])
                clim=1. if isimage else max(1e-7,float(np.quantile(im,.995)))
                ax.imshow(im,cmap="magma" if isimage else "viridis",
                      vmin=0,vmax=clim,interpolation="nearest")
                ax.set_xticks([]);ax.set_yticks([])
                desc="" if isimage else f"\nmin {float(im.min()):.3g} | mean {float(im.mean()):.3g} | max {float(im.max()):.3g}"
                ax.set_title(label+desc,fontsize=9.9,pad=8)
            fig.text(.032,.097,
              f"Shifted vs clipped: {float(a['replaced_metrics']['psnr'])-float(b['replaced_metrics']['psnr']):+.3f} dB  |  "
              f"Shifted vs learned: {float(a['replaced_metrics']['psnr'])-float(a['learned_metrics']['psnr']):+.3f} dB",
              fontsize=11.6,weight="bold")
            fig.text(.032,.062,
              f"Shifted rho evaluations: {a['rho_evaluations']}, final width {a['ternary_width']:.5f}, "
              f"best {'outside' if a['best_outside_final_bracket'] else 'within'} final bracket. "
              f"Zero-fill shift offset: {a['shift_offset']:.5g}. Image panels share [0,1]; parameter maps have independent colour scales.",
              fontsize=10.1)
            foot(fig,"All reconstructions and GT are raw and not clipped when computing metrics. Orange/dark image colours are for display only.")
            book.savefig(fig,dpi=150);plt.close(fig)
    assert pdf.stat().st_size>100000
    print("REPORT_DONE",pdf,pdf.stat().st_size,"pages",len(data)+3,
          "avg",summary["mean_psnr"],
          "delta_shift_clip",summary["mean_difference_shifted_minus_clipped"],
          "wins",wins,"boundary",boundary,"outside",outside,flush=True)
if __name__=="__main__":
    main()
