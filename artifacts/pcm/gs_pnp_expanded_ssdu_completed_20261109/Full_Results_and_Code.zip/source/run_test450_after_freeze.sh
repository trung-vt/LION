#!/usr/bin/env bash
# Retrospective test is strictly gated on frozen SSDU validation selection.
set -Eeuo pipefail
ROOT=/store/LION/ttv22/pcm/results/pcm/ssdu_pnp_tuning_20261108_v1/next_gs_ssdu_sweep_v1
WT=/home/t/Documents/GIT/LION_pcm_ssdu_tuning_20261108
PY=/home/t/micromamba/envs/lion_3/bin/python
OUT="$ROOT/test450"
mkdir -p "$OUT/logs"
exec 9>"$OUT/logs/controller.lock"
flock -n 9 || { echo 'Controller already running';exit 66; }
cd "$WT"
export PYTHONDONTWRITEBYTECODE=1 LION_DATA_PATH=/store/LION/ttv22/pcm/data LION_TTV22_PATH=/store/LION/ttv22
export OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 MPLBACKEND=Agg
export CUDA_DEVICE_ORDER=PCI_BUS_ID CUBLAS_WORKSPACE_CONFIG=:4096:8 PYTHONUNBUFFERED=1
export CUDA_VISIBLE_DEVICES=GPU-fcdc8ea0-7187-86d7-15ba-615774f8801f
if [ -s "$OUT/logs/status.txt" ];then
 echo 'Controller status exists; refusing duplicate run' >&2;exit 8
fi
echo "WAITING_FOR_FROZEN_SELECTION $(date -Is)" > "$OUT/logs/status.txt"
while [ ! -s "$ROOT/frozen_selection.json" ];do
 if [ -s "$ROOT/logs/supervisor.pid" ];then
   prior=$(cat "$ROOT/logs/supervisor.pid")
   if ! kill -0 "$prior" 2>/dev/null;then
      echo 'STOPPED_NO_SELECTION: tuning supervisor stopped without freezing' > "$OUT/logs/status.txt"
      exit 1
   fi
 fi
 sleep 8
done
echo "FROZEN_VERIFIED $(date -Is)" > "$OUT/logs/status.txt"
"$PY" -B -u -m scripts.experiments.pcm.ssdu_pnp_tuning_20261108.expanded_gs_test450 preflight > "$OUT/logs/preflight.log" 2>&1
echo "TEST450_RUNNING $(date -Is)" > "$OUT/logs/status.txt"
"$PY" -B -u -m scripts.experiments.pcm.ssdu_pnp_tuning_20261108.expanded_gs_test450 run > "$OUT/logs/reconstruction.log" 2>&1
echo "TEST450_COMPLETED $(date -Is)" > "$OUT/logs/status.txt"
"$PY" -B -u -m scripts.experiments.pcm.ssdu_pnp_tuning_20261108.expanded_gs_analysis > "$OUT/logs/analysis.log" 2>&1
echo "ANALYSIS_COMPLETED $(date -Is)" > "$OUT/logs/status.txt"
"$PY" -B -u -m scripts.experiments.pcm.ssdu_pnp_tuning_20261108.expanded_gs_full_report > "$OUT/logs/report.log" 2>&1
cd "$ROOT/report"
latexmk -pdf -interaction=nonstopmode -halt-on-error GS_PnP_Expanded_SSDU_Tuning_Full_Report.tex > "$OUT/logs/latex.log" 2>&1
pdfinfo GS_PnP_Expanded_SSDU_Tuning_Full_Report.pdf |grep -E 'Pages:|File size:'
echo "FULL_REPORT_COMPILED $(date -Is)" > "$OUT/logs/status.txt"
