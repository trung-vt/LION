#!/usr/bin/env bash
set -Eeuo pipefail
ROOT=/store/LION/ttv22/pcm/results/pcm/ssdu_pnp_tuning_20261108_v1/next_gs_ssdu_sweep_v1
WORK=/home/t/Documents/GIT/LION_pcm_ssdu_tuning_20261108
PY=/home/t/micromamba/envs/lion_3/bin/python
TEST="$ROOT/test450"
test -s "$ROOT/frozen_selection.json"
cd "$WORK"
exec 9>"$TEST/logs/resume.lock"
flock -n 9 || { echo 'Test already running';exit 66; }
export PYTHONDONTWRITEBYTECODE=1 LION_DATA_PATH=/store/LION/ttv22/pcm/data LION_TTV22_PATH=/store/LION/ttv22
export OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 MPLBACKEND=Agg
export CUDA_DEVICE_ORDER=PCI_BUS_ID CUBLAS_WORKSPACE_CONFIG=:4096:8
export CUDA_VISIBLE_DEVICES=GPU-fcdc8ea0-7187-86d7-15ba-615774f8801f PYTHONUNBUFFERED=1
echo "TEST450_RUNNING $(date -Is)" > "$TEST/logs/status.txt"
"$PY" -B -u -m scripts.experiments.pcm.ssdu_pnp_tuning_20261108.expanded_gs_test450 run > "$TEST/logs/reconstruction.log" 2>&1
echo "TEST450_COMPLETED $(date -Is)" > "$TEST/logs/status.txt"
"$PY" -B -u -m scripts.experiments.pcm.ssdu_pnp_tuning_20261108.expanded_gs_analysis > "$TEST/logs/analysis.log" 2>&1
echo "ANALYSIS_COMPLETED $(date -Is)" > "$TEST/logs/status.txt"
"$PY" -B -u -m scripts.experiments.pcm.ssdu_pnp_tuning_20261108.expanded_gs_full_report > "$TEST/logs/report.log" 2>&1
cd "$ROOT/report"
latexmk -pdf -interaction=nonstopmode -halt-on-error GS_PnP_Expanded_SSDU_Tuning_Full_Report.tex > "$TEST/logs/latex.log" 2>&1
echo "FULL_REPORT_COMPILED $(date -Is)" > "$TEST/logs/status.txt"
