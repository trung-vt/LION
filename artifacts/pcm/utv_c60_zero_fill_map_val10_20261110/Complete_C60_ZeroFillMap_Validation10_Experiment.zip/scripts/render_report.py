"""Final comparison report: C60 learned lambda map vs scaled zero-fill parameter map.

All data and PDF rendering stay on tuni. The report includes 10 frozen
validation images, same acquisitions for PnP and both UTV variants.
"""
from pathlib import Path
import csv,json,math
from collections import defaultdict
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.colors import Normalize
from matplotlib.cm import ScalarMappable

ROOT=Path('/store/LION/ttv22/pcm/results/pcm')
O=ROOT/'utv_c60_zero_fill_map_val10_20261110_v1'
MANIFEST=json.loads((O/'frozen_10_manifest.json').read_text())
C60=json.loads((O/'c60_results.json').read_text())
with (O/'pnp_metrics.csv').open(newline='') as f:
    PNP=list(csv.DictReader(f))
assert len(MANIFEST)==len(C60)==len(PNP)==10
pnps={r['sample']:r for r in PNP}
c60={r['sample']:r for r in C60}
categories=['CIGS','Organic','Perovskite','Reference','Silicone']
data=[]
for m in MANIFEST:
    key=m['sample_name']
    assert key in pnps and key in c60
    case=c60[key]
    with np.load(O/'cases'/key/'images.npz',allow_pickle=False) as z:
        img={k:z[k].copy() for k in z.files}
    pnp=np.load(O/f'{key}_pnp_admm_tuned5.npy',allow_pickle=False)
    assert img['learned_recon'].shape==pnp.shape==(256,256)
    assert np.isfinite(img['replacement_recon']).all()
    assert (img['replacement_map']>=0).all()
    selected=float(case['selected_rho'])
    assert 0.0001<=selected<=10 and case['ternary_width']<=.010001
    data.append((m,case,pnps[key],img,pnp))
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,
    'pdf.fonttype':42,'figure.facecolor':'white','savefig.facecolor':'white'})
def stats(arr):
    x=np.asarray(arr,dtype=np.float64)
    return float(x.mean()),float(x.std(ddof=1)) if x.size>1 else 0.
def table(ax,col,body,size=9.7,widths=None,scale=1.58):
    ax.axis('off')
    t=ax.table(cellText=body,colLabels=col,colLoc='center',cellLoc='center',
            loc='center',colWidths=widths)
    t.auto_set_font_size(False);t.set_fontsize(size);t.scale(1,scale)
    for (i,j),c in t.get_celld().items():
        c.set_edgecolor('#d9e0e8');c.set_linewidth(.55)
        c.set_facecolor('#e8eff7' if i==0 else '#f8fafc' if i%2 else 'white')
        if i==0:c.get_text().set_weight('bold')
def head(fig,title,subtitle):
    fig.text(.047,.973,title,va='top',size=19.5,weight='bold',color='#172b42')
    fig.text(.047,.926,subtitle,va='top',size=11,color='#465d73')
    fig.add_artist(plt.Line2D([.047,.957],[.890,.890],
             transform=fig.transFigure,color='#c8d3e0',lw=1.1))
def footer(fig,text):
    fig.text(.047,.028,text,size=8.5,color='#616c77',va='bottom')
def metric_dict(a):
    return {k:float(a[k]) for k in ('psnr','ssim','haarpsi','mse')}
def measure_x(im,gt):
    from LION.utils.metrics import compute_metrics
    import torch
    met=compute_metrics(recon=torch.from_numpy(im.astype('float32'))[None,None],
                        target=torch.from_numpy(gt.astype('float32'))[None,None],data_range=1.)
    return {k:float(met[k]) for k in ('psnr','ssim','haarpsi','mse')}
for _,_,_,img,_ in data:
    for key in ('zero_filled','learned_recon','replacement_recon'):
        assert img[key].shape==(256,256)
groups=defaultdict(list)
for row in data:
    groups[row[0]['category']].append(row)
def mean_psnr(cat,field):
    vals=[]
    for m,s,p,img,pr in groups[cat]:
        vals.append(float(p['psnr']) if field=='pnp' else
                    float(s['learned_metrics']['psnr']) if field=='learned' else
                    float(s['replaced_metrics']['psnr']))
    return stats(vals)
means={method:stats([float(p['psnr']) if method=='pnp' else
         float(s['learned_metrics']['psnr']) if method=='learned' else
         float(s['replaced_metrics']['psnr'])
         for m,s,p,img,pr in data]) for method in ('pnp','learned','replacement')}
win=sum(float(s['psnr_delta_zero_minus_learned'])>0 for m,s,p,img,pr in data)
boundary=sum(abs(float(s['selected_rho'])-0.0001)<1e-12 for m,s,p,img,pr in data)
outside=sum(bool(s['best_outside_final_bracket']) for m,s,p,img,pr in data)
out_pdf=O/'PCM_C60_Learned_vs_ZeroFillMap_Validation10.pdf'
summary_rows=[]
for m,s,p,img,pnp in data:
    summary_rows.append({'category':m['category'],'sample_id':int(m['sample_id']),
      'case':m['sample_name'],'selected_rho':s['selected_rho'],
      'pnp_psnr':float(p['psnr']),
      'learned_psnr':float(s['learned_metrics']['psnr']),
      'replacement_psnr':float(s['replaced_metrics']['psnr']),
      'delta_psnr':float(s['psnr_delta_zero_minus_learned']),
      'pnp_ssim':float(p['ssim']),
      'learned_ssim':float(s['learned_metrics']['ssim']),
      'replacement_ssim':float(s['replaced_metrics']['ssim']),
      'pnp_haarpsi':float(p['haarpsi']),
      'learned_haarpsi':float(s['learned_metrics']['haarpsi']),
      'replacement_haarpsi':float(s['replaced_metrics']['haarpsi']),
      'best_outside_bracket':s['best_outside_final_bracket'],
      'zero_negative_frac':s['zero_filled_negative_fraction'],
      'rho_evaluations':s['rho_evaluations'],
      'learned_recon_seconds':s['learned_recon_seconds'],
      'replaced_recon_seconds':s['selected_recon_seconds']})
with (O/'all_10_metrics.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(summary_rows[0]),lineterminator='\n')
    w.writeheader();w.writerows(summary_rows)
analysis={
 'scope':'10 frozen validation images, random seed 20261110, 2/category',
 'zero_map':'rho*maximum(zero_fill,0), no max-1 clipping, no CNN',
 'learned_map':'original post-softplus C60 map learned from 20 CG iteration input',
 'reconstruction_iterations':512,'rho_range':[0.0001,10],
 'ternary_interval_width':0.01,'mean_metrics':means,
 'replacement_better_psnr_count':win,
 'rho_at_lower_bound_count':boundary,
 'selected_outside_bracket_count':outside,
 'per_category':{cat:{k:mean_psnr(cat,k) for k in ('pnp','learned','replacement')}
                 for cat in categories},
 'validation_leakage_warning':'Oracle rho selected using GT on validation images; C60 checkpoint and PnP hyperparameters were also selected on validation data.',
 'ternary_warning':'PSNR unimodality not proven; best observed evaluated rho selected.'
}
(O/'report_summary.json').write_text(json.dumps(analysis,indent=2)+'\n')
with PdfPages(out_pdf,metadata={
    'Title':'PCM C60: learned map vs scaled nonnegative zero-fill map (validation 10)',
    'Author':'PCM experiment','Subject':'Frozen 20% NPL PCM, C60 512 PDHG, PSNR-oracle rho sweep'}) as pdf:
    fig=plt.figure(figsize=(14.8,9.0))
    head(fig,'C60 regularisation: learned map vs zero-fill map',
         'Executive summary | 10 frozen validation images (2/category), 20% sampling, NPL-default noise')
    fig.text(.053,.854,f"Average PSNR (dB): PnP-ADMM-tuned-5 {means['pnp'][0]:.3f}  |  "
             f"C60 learned {means['learned'][0]:.3f}  |  "
             f"C60 zero-fill-map tuned {means['replacement'][0]:.3f}",fontsize=13.4,weight='bold')
    fig.text(.053,.805,
             f"Zero-fill map beats learned map on {win}/10 cases. "
             f"Best rho at lower search boundary on {boundary}/10 cases; "
             f"best observed rho lies outside final ternary bracket on {outside}/10.",
             fontsize=11.4)
    fig.text(.053,.765,'Each zero-filled parameter map is nonnegative: '
             r'$\Lambda_\rho=\rho\max(x_{\mathrm{ZF}},0)$'
             ', because raw zero-fill contains negative values.',fontsize=11)
    ax=fig.add_axes([.10,.355,.81,.34])
    x=np.arange(5);width=.22
    for d,(label,key) in enumerate([('PnP-ADMM-tuned-5','pnp'),('C60 learned','learned'),('C60 zero-fill-map','replacement')]):
        val=[mean_psnr(cat,key)[0] for cat in categories]
        ax.bar(x+(d-1)*width,val,width,label=label)
    ax.set_xticks(x,categories)
    ax.set_ylabel('Mean PSNR (dB)');ax.set_ylim(bottom=0)
    ax.grid(axis='y',alpha=.2);ax.legend(fontsize=10)
    fig.text(.052,.294,'Interpretation',weight='bold',size=13)
    explanation=(
      'The replacement map uses the measured image directly, not a trained CNN. '
      'Its absolute regularisation scale and spatial distribution differ from the learned map. '
      'The multiplier is chosen with ground-truth PSNR for each image, so these are oracle results. '
      'This is a validation subset also used in earlier model/hyperparameter selection, '
      'not an independent estimate of generalisation.')
    import textwrap
    fig.text(.052,.268,'\n'.join(textwrap.wrap(explanation,115)),size=10.7,va='top',linespacing=1.6)
    footer(fig,'Per-case methods and images follow; every reconstruction uses the identical archived acquisition for that case.')
    pdf.savefig(fig);plt.close(fig)
    fig=plt.figure(figsize=(16.0,9.2))
    head(fig,'Per-image PSNR and selected multipliers',
        'A positive delta means the zero-fill-map reconstruction outperforms learned-map C60.')
    body=[]
    for r in summary_rows:
        body.append([r['case'],f"{r['selected_rho']:.6g}",f"{r['pnp_psnr']:.3f}",
          f"{r['learned_psnr']:.3f}",f"{r['replacement_psnr']:.3f}",
          f"{r['delta_psnr']:+.3f}",
          'Yes' if r['best_outside_bracket'] else 'No'])
    ax=fig.add_axes([.045,.31,.91,.53])
    table(ax,['Image','Selected rho','PnP PSNR','Learned PSNR','ZF-map PSNR','Delta (dB)','Outside bracket'],
          body,size=10,widths=[.21,.13,.13,.15,.15,.12,.12],scale=1.67)
    fig.text(.055,.262,'Search protocol',size=12.6,weight='bold')
    fig.text(.055,.229,
        'Linear-rho ternary search on [0.0001, 10], stop when bracket width <= 0.01. '
        'Additional log-spaced diagnostics and final bracket probes are evaluated.',size=10.7)
    fig.text(.055,.197,
        'Select best observed PSNR over all evaluated candidates. Ternary search is not a '
        'global guarantee without unimodality; boundary and out-of-bracket selections are flagged.',size=10.6)
    fig.text(.055,.149,'Fixed C60 checkpoint epoch 60, 20 CG input iterations, 512 PDHG iterations. '
        'PnP uses the existing validation-selected rho=0.5, sigma=0.075 and residual stopping rule.',size=10.4)
    footer(fig,'Measurements, indices, PnP outputs and both UTV variants are frozen per image and downloadable as NPZ.')
    pdf.savefig(fig);plt.close(fig)
    fig=plt.figure(figsize=(15.4,9.0))
    head(fig,'Methods, positivity and comparability',
       'One changed ingredient: the spatial regularisation weight map supplied to the unchanged C60 solver.')
    details=[
       ('Learned C60 baseline',r'$\lambda_{\rm learned}(x)=\mathrm{softplus}(\mathrm{CNN}(x_{\rm CG}))(x)$, '
        'predicted once from the 20-step CG image. Its weights are not rescaled.'),
       ('Replacement map',r'$\lambda_{\rm ZF,\rho}(x)=\rho\max(x_{\rm ZF}(x),0)$, '
        'with no CNN evaluation, no map normalisation, and no upper clipping. '
        'Negative zero-fill pixel values are set to zero because L1 penalties require nonnegative weights.'),
       ('Fixed forward data','For each selected case, all reconstructions use the same archived '
        '20% multilevel Hadamard measurement, NPL-default noise, sampling indices and GT.'),
       ('Fixed reconstruction','C60 TV-PDHG uses the same checkpoint, 512 iterations, '
        'zero initial image, step sizes and normalized PCM operator. Only lambda_reg differs.'),
       ('PnP baseline','PnP-ADMM-tuned-5 uses validation-selected (rho=0.5, sigma=0.075), '
        'the original DRUNet model and residual-based stopping, without per-image GT tuning.'),
       ('Rho tuning','Each replacement map is multiplied by one scalar rho. '
        'Ternary stopping width 0.01 refers to rho, not PSNR accuracy. '
        'Best observed rho may lie at search boundaries.'),
       ('Interpretation limit','The C60 model and PnP hyperparameters have previously been selected '
        'on validation data. Also, the new rho is explicitly tuned using GT on these '
        'validation cases. Results are exploratory, not held-out test results.')
    ]
    y=.838
    for title,txt in details:
        fig.text(.060,y,title,fontsize=12,weight='bold',va='top')
        wrapped='\n'.join(textwrap.wrap(txt,118,break_long_words=False))
        fig.text(.060,y-.028,wrapped,fontsize=10.75,va='top',linespacing=1.48)
        y-=.088 if len(wrapped)<130 else .103
    footer(fig,'Primary implementation: local LION C60 checkpoint and original PCM frozen validation acquisition archive.')
    pdf.savefig(fig);plt.close(fig)
    for index,(m,case,pnpr,img,pnp_image) in enumerate(data,1):
        key=m['sample_name']
        best=float(case['selected_rho'])
        fig=plt.figure(figsize=(19.6,11.8))
        head(fig,f'{index:02d}. {key}',
             f'Frozen validation position {m["validation_position"]} | '
             f'512 PDHG iterations | PSNR-optimal evaluated rho={best:.7g}')
        gs=fig.add_gridspec(2,5,left=.025,right=.97,top=.833,bottom=.13,
                           hspace=.43,wspace=.17)
        gt=img['ground_truth']
        zf=img['zero_filled']
        def metrics_for(im):return measure_x(im,gt)
        measures=[
          ('Ground truth',gt,None),
          ('Zero-filled reconstruction',zf,metrics_for(zf)),
          ('PnP-ADMM-tuned-5',pnp_image,metric_dict(pnpr)),
          ('C60 with learned map',img['learned_recon'],case['learned_metrics']),
          (f'C60 with ZF map (rho={best:.5g})',img['replacement_recon'],case['replaced_metrics']),
        ]
        for i,(title,image,metrics) in enumerate(measures):
            ax=fig.add_subplot(gs[0,i])
            ax.imshow(image,cmap='magma',vmin=0,vmax=1,interpolation='nearest')
            ax.set_xticks([]);ax.set_yticks([])
            label=title if metrics is None else (
                f"{title}\nPSNR {metrics['psnr']:.2f} dB | SSIM {metrics['ssim']:.3f}\n"
                f"HaarPSI {metrics['haarpsi']:.3f}")
            ax.set_title(label,fontsize=9.8,weight='bold' if i==4 else 'normal',pad=7)
        lmap=img['learned_map']
        zmap=img['replacement_map']*best
        crops=[
          ('Learned parameter map',lmap,False),
          ('Zero-fill parameter map * rho',zmap,False),
          ('GT texture crop',gt[40:185,65:205],True),
          ('Learned-map C60 crop',img['learned_recon'][40:185,65:205],True),
          ('Zero-map C60 crop',img['replacement_recon'][40:185,65:205],True)
        ]
        for i,(title,array,isimage) in enumerate(crops):
            ax=fig.add_subplot(gs[1,i])
            scale=float(np.quantile(array,.995)) if not isimage else 1.
            if not np.isfinite(scale) or scale<=0:scale=float(np.max(array)+1e-8)
            ax.imshow(array,cmap='magma' if isimage else 'viridis',
                      vmin=0,vmax=scale,interpolation='nearest')
            ax.set_xticks([]);ax.set_yticks([])
            desc='' if isimage else f'\nmin {np.min(array):.3g} | mean {np.mean(array):.3g} | max {np.max(array):.3g}'
            ax.set_title(title+desc,fontsize=9.8,pad=7)
        fig.text(.034,.083,
          f"PSNR change ZF-map minus learned: {case['psnr_delta_zero_minus_learned']:+.3f} dB   |   "
          f"rho evaluations: {case['rho_evaluations']}   |   final bracket width: {case['ternary_width']:.5f}",
          fontsize=11,weight='bold')
        fig.text(.034,.054,
          f"Zero-fill negative pixel fraction: {case['zero_filled_negative_fraction']:.1%}. "
          f"Best rho {'outside' if case['best_outside_final_bracket'] else 'inside'} final bracket. "
          'Map panels have independent display scales; image panels all use [0,1].',
          fontsize=9.8)
        footer(fig,'Single-image GT-guided PSNR search. High-quality outputs and search traces are retained in the experiment archive.')
        pdf.savefig(fig,dpi=145);plt.close(fig)
assert out_pdf.stat().st_size>100000
print('REPORT_READY',out_pdf,'pages',len(data)+3,'bytes',out_pdf.stat().st_size,
      'means',means,'win_count',win,'boundary_count',boundary,'outside',outside,flush=True)
