from __future__ import annotations
from pathlib import Path
import json,hashlib
import numpy as np,torch
from scripts.experiments.pcm.pnp_admm_tuning import step2e_validation as val
R=Path('/store/LION/ttv22/pcm/results/pcm')
OUT=R/'utv_c60_zero_fill_map_val10_20261110_v1'
selection=json.loads((OUT/'selection.json').read_text())['selected']
archive=json.loads((val.ARCHIVE/'manifest.json').read_text())
protocol=json.loads((val.ARCHIVE/'protocol.json').read_text())
assert len(selection)==10 and len(archive['acquisitions'])==50
device=torch.device('cuda:0')
index=[]
for r in selection:
    cat=r['category'];sid=int(r['sample_id'])
    op,gt,y,gt64,meta,ids=val.load_case(r,protocol,device)
    zero=op.pseudo_inv(y)
    assert gt.shape==(1,1,256,256) and y.shape==(1,1,13107)
    record={'category':cat,'sample_id':sid,
            'sample_name':f'{cat}_{sid:04d}',
            'original_archive_file':r['file'],
            'original_archive_sha256':r['sha256'],
            'measurement_sha256':hashlib.sha256(y.detach().cpu().contiguous().numpy().tobytes()).hexdigest(),
            'sampled_indices_sha256':hashlib.sha256(np.ascontiguousarray(ids,dtype=np.int64).tobytes()).hexdigest(),
            'zero_min':float(zero.min()),'zero_max':float(zero.max()),
            'zero_mean':float(zero.mean()),
            'zero_negative_fraction':float((zero<0).float().mean()),
            'zero_negative_pixels':int((zero<0).sum()),
            'validation_position':int(r['permutation_position_1based'])}
    arrays={'gt':gt.squeeze().cpu().numpy().astype(np.float32),
            'measurement':y.detach().cpu().numpy().astype(np.float32),
            'indices':np.asarray(ids,dtype=np.int64),
            'zero_filled':zero.squeeze().cpu().numpy().astype(np.float32)}
    np.savez_compressed(OUT/(record['sample_name']+'.npz'),**arrays)
    index.append(record)
    print('STAGED',record['sample_name'],'ZERO',record['zero_min'],record['zero_max'],'NEG_FRAC',record['zero_negative_fraction'],flush=True)
(OUT/'frozen_10_manifest.json').write_text(json.dumps(index,indent=2)+'\n')
print('STAGED_ALL',len(index),flush=True)
