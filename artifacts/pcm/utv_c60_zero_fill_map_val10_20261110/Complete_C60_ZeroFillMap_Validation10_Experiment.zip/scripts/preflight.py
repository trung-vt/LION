from pathlib import Path
import json
import numpy as np
import torch
from scripts.experiments.pcm.pnp_admm_tuning import step2e_validation as val
from LION.operators.PhotocurrentMapOp import PhotocurrentMapOp
from LION.pcm.pcm_config import load_pcm_sapm_supervised_config_from_path,make_supervised_pcm_training_cases
from LION.pcm.pcm_sapm import make_pcm_forward_data,load_trained_pcm_checkpoint_model
R=Path('/store/LION/ttv22/pcm/results/pcm')
OUT=R/'utv_c60_zero_fill_map_val10_20261110_v1'
OUT.mkdir(parents=True,exist_ok=True)
manifest=json.loads((val.ARCHIVE/'manifest.json').read_text())
protocol=json.loads((val.ARCHIVE/'protocol.json').read_text())
assert len(manifest['acquisitions'])==50
rng=np.random.default_rng(20261110)
categories=['CIGS','Organic','Perovskite','Reference','Silicone']
selected=[]
for cat in categories:
    pool=[r for r in manifest['acquisitions'] if r['category']==cat]
    assert len(pool)==10 and len({r['sample_id'] for r in pool})==10
    ids=rng.choice(len(pool),2,replace=False)
    selected.extend(pool[int(i)] for i in ids)
print('SELECTED',[(r['category'],r['sample_id']) for r in selected])
(OUT/'selection.json').write_text(json.dumps({'rng_seed':20261110,'method':'numpy default_rng choice 2 of 10 per category','selected':selected,'archive_root':str(val.ARCHIVE)},indent=2)+'\n')
device=torch.device('cuda:0')
op,gt,y,gt64,meta,indices=val.load_case(selected[0],protocol,device)
zero=op.pseudo_inv(y)
print('MEAS',float(y.min()),float(y.max()),y.dtype,'zero',zero.shape,float(zero.min()),float(zero.max()),'negative_frac',float((zero<0).float().mean()),'zero_fraction',float((zero==0).float().mean()))
config=load_pcm_sapm_supervised_config_from_path(R/'pcm_utv_4090_3x56_winner_snapshot_20261103/requested_config.yaml')
model,epoch,step=load_trained_pcm_checkpoint_model(config=config,cases=make_supervised_pcm_training_cases(config),checkpoint_path=R/'pcm_utv_4090_3x56_winner_snapshot_20261103/checkpoints/best_val_epoch60.pt',device=device)
print('MODEL_EPOCH',epoch,step)
data=make_pcm_forward_data(config=config,op=op,measurement=y,key=0,sampling_ratio=.2,coarse_j=6,device=device)
with torch.inference_mode():
  learned=model.estimate_lambda_map(data.model_input.input_image,0).detach()
print('LEARNED_MAP',(float(learned.min()),float(learned.max()),float(learned.mean())),'ZERO_POS_MAP',(float(zero.clamp_min(0).min()),float(zero.clamp_min(0).max()),float(zero.clamp_min(0).mean())))
print('CONFIG_STEPS',config.model.n_iters,config.model.pdhg.primal_stepsize,config.model.pdhg.dual_stepsize)
