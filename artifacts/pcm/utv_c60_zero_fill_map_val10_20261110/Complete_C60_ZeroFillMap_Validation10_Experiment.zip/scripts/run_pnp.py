"""PnP-ADMM tuned-5 validation comparison on original archived 20% acquisition.

Uses fixed previously validation-selected rho=.5, sigma=.075 and residual
stopping rule as in step3_final_heldout.live_admm, with no GT tuning.
"""
from pathlib import Path
import csv,json,hashlib
import numpy as np,torch
from LION.operators.PhotocurrentMapOp import PhotocurrentMapOp
from LION.utils.metrics import compute_metrics
from scripts.experiments.pcm.pnp_admm_tuning.step3_final_heldout import live_admm,load_model,RHO,SIGMA
R=Path('/store/LION/ttv22/pcm/results/pcm')
OUT=R/'utv_c60_zero_fill_map_val10_20261110_v1'
rows=json.loads((OUT/'frozen_10_manifest.json').read_text())
assert len(rows)==10
torch.set_num_threads(3)
assert '4070' in torch.cuda.get_device_name(0)
denoiser=load_model()
scores=[]
for row in rows:
    key=row['sample_name']
    source=OUT/f'{key}.npz'
    with np.load(source,allow_pickle=False) as z:
        gt=z['gt'].copy()
        y=z['measurement'].copy()
        indices=z['indices'].copy()
    assert hashlib.sha256(np.ascontiguousarray(y).tobytes()).hexdigest()==row['measurement_sha256']
    op=PhotocurrentMapOp(j_order=8,s_indices=indices,normalized=True,device=torch.device('cuda:0'))
    with torch.no_grad():
        result=live_admm(op,torch.from_numpy(y).to('cuda'),denoiser)
    rec=result['x'].squeeze().cpu().numpy().astype(np.float32)
    assert rec.shape==gt.shape and np.isfinite(rec).all()
    metrics=compute_metrics(recon=torch.from_numpy(rec)[None,None],
                            target=torch.from_numpy(gt)[None,None],data_range=1.)
    stat={'sample':key,'category':row['category'],'sample_id':row['sample_id'],
          'method':'PnP-ADMM-tuned-5','rho':RHO,'sigma':SIGMA,
          'iterations':result['stop_iteration'],'wall_seconds':result['wall_seconds'],
          **{k:float(metrics[k]) for k in ('psnr','ssim','haarpsi','mse')}}
    scores.append(stat)
    np.save(OUT/f'{key}_pnp_admm_tuned5.npy',rec)
    print('PNP_DONE',key,'iterations',result['stop_iteration'],
          'PSNR',stat['psnr'],'time',stat['wall_seconds'],flush=True)
with (OUT/'pnp_metrics.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(scores[0]),lineterminator='\n')
    w.writeheader();w.writerows(scores)
print('PNP_COMPLETE',len(scores),flush=True)
