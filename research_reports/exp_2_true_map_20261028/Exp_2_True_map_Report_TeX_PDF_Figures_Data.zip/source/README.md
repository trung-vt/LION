# exp 2 True map

**Ground-truth-informed spatial regularisation maps for U-TV PCM reconstruction**

Status: **prepared, not executed**. All GPU phases must be explicitly launched. The script does not alter the original LION solver, models, datasets, checkpoints, or existing training sessions.

## Purpose

We test the counterfactual question: *If the regularisation map were informed by the actual reference image, would the resulting PDHG reconstruction be more accurate and/or need fewer solver iterations?*

This must not be confused with finding the mathematically optimal spatial TV weight. There is no unique, automatically defined "true map" associated with an image. This experiment uses **two precisely specified GT-informed proxies**:

1. **GT-to-CNN:** Feed the noise-free ground truth (in LION's image intensity scaling) to the **existing frozen** U-TV map CNN. That is, compare `Lambda_theta(CG(y))` against `Lambda_theta(S*x_GT)`; the same key and CNN weights are reused. The GT image is not used as the PDHG initial image, measurement, target constraint, or warm start. Using GT as CNN input is out of distribution relative to the model's original CG training input; success is not guaranteed.
2. **GT-edge design:** Construct positive TV weights from the actual clean-image forward differences: `w = eps+(1-eps)*exp[-(abs(grad_gt)/kappa)^2]`. Here `eps=0.05`, and `kappa` is the 90th percentile of nonzero gradient magnitudes. Match the map's mean to the mean learned measurement-conditioned TV map. This is an explicit structural heuristic, not a proven optimal map.

The experiment also retains the **raw GT-to-CNN map** without any mean adjustment. A separate mean-matched version ensures that a shape change cannot be mistaken for an arbitrary global-amplitude change.

## Data and fairness

- **Exactly the same four CIGS 256x256 images:** 0674, 0985, 0917, 0864.
- **Exact same Hadamard acquisition / noise / normalization / PDHG checkpoint** as Experiment 1 Stage I (20% sampling, coarse J=6, PCM NPL noise).
- **Same five noise realizations per image** as Experiment 1: two calibration seeds (`reference`, `cal_1101`) and three evaluation seeds (`test_2101`, `test_2102`, `test_2103`). Acquisitions are regenerated using LION and then checked against actual Exp 1 archived y, pattern and ground truth arrays (not simply against seed labels).
- **Original September 2026 frozen U-TV checkpoint**, epoch 99, step 39600, 256-step PDHG. No new network training. A later completed noisy-trained checkpoint can be studied separately with a distinct protocol, but cannot silently replace this checkpoint.
- Audit the narrow-line coordinates from the final Experiment 1 protocol. CIGS 0917 is an **electrode/conductor track**, not a verified material crack. The remaining features are described as **crack-like** but not confirmed to be material defects.

## Comparisons

For the *same* measurements and initialization, evaluate:

| Method | Weight map | Global scale |
|---|---|---|
| `measured_c1` | `Lambda_theta(CG(y))` | 1 (original) |
| `measured_c8` | `Lambda_theta(CG(y))` | 8 (Exp 1 calibrated control) |
| `gt_cnn_raw_c1` | `Lambda_theta(S*x_GT)` | 1 |
| `gt_cnn_raw_c8` | `Lambda_theta(S*x_GT)` | 8 |
| `gt_cnn_matched_calibrated` | `Lambda_theta(S*x_GT)` rescaled to equal mean of measured map | selected on two calibration seeds |
| `gt_edge_matched_calibrated` | hand-designed GT-edge map rescaled to equal mean | selected on two calibration seeds |

The two GT-informed mean-matched variants are swept over `c={0.5,1,2,4,8,16,32}` using *calibration* seeds only. The PSNR-optimal scale is frozen before looking at three separate *test-noise* seeds. Test PSNR is never used to tune the method's scalar.

### Accuracy and fine features

Report image-level PSNR, MSE, SSIM, HaarPSI, original measurement residual/noise ratio, local signed contrast retention, centre-line recall proxy, line gaps and off-line false positives. Compare maps visually and measure their correlation, means and gradient-conditioned strength. Use the same `afmhot`-style intensity limits for close-ups and avoid treating increased PSNR as evidence of preserved defects.

### What exactly is "reconstruction speed"?

This is an important part of the experiment. A different map does **not** reduce the number of PDHG steps by itself, and each PDHG step executes the same operators. So we separately measure:

1. **Map creation time:** compare frozen CNN map evaluation on CG(y), frozen CNN map evaluation on scaled GT, and the hand-designed GT-edge map. CG construction is a shared input preparation cost and not equivalent to obtaining GT.
2. **Fixed-depth PDHG time:** compare GPU timings at the same iterations. A properly controlled comparison should have roughly similar per-step cost for all weight maps.
3. **Iterations / GPU seconds to comparable quality:** run independently from *identical zero initialization* at K = 64, 128, 256, 512 and 1024; compare earliest K reaching the **measured c=8 256-step reference PSNR minus 0.1 dB**. Some GT methods may never reach it. Also report relative distance to each method's *own* 1024-step solution as a non-rigorous convergence diagnostic. We do **not** claim a primal-dual-gap bound.
4. **Timing reproducibility:** warm up GPU, repeat each solve three times, synchronize, and randomize method/depth order for each datum. If the RTX 4070 is sharing GPU with existing U-TV training, timings will be labelled *contended exploratory measurements*. Run timing again with the GPU idle before any firm speed claim.

The true cost of acquiring a ground-truth PCM image is **not included**, because ground truth would not be available during ordinary measurement reconstruction. This is a diagnostic upper-bound experiment, **not** a deployable inference speedup.

## Safe execution phases (no stage has been started)

From the LION root, after installing this folder at `scripts/experiments/pcm/exp_2_true_map_20261028/`:

```bash
D=scripts/experiments/pcm/exp_2_true_map_20261028
bash "$D/launch.sh" preflight          # CPU, validates real input files and code
bash "$D/launch.sh" smoke              # GPU, only 16 iterations per method
bash "$D/launch.sh" calibration        # GPU, two calibration seeds per image
bash "$D/launch.sh" evaluate           # GPU, three separate test seeds
bash "$D/launch.sh" timing             # GPU, separate iteration-depth benchmark
bash "$D/launch.sh" analyse            # CPU, checks completeness and saves CSV
bash "$D/launch.sh" report             # CPU, builds TeX/PDF and a ZIP
```

GPU phases automatically reject an occupied RTX 4070 unless you append `--allow-shared-gpu`, in which case they permit **only** the known existing U-TV training process. A 10% sustained training slowdown, missing trainer, 30-minute stage timeout, unexpected GPU occupant, or another Exp 2 GPU session aborts **Exp 2 only**. No daemon, automation or background task is created by these scripts. Existing image and checkpoint files are read-only. CPU-only test functions are safe to run during training.

Output root (created by first launched GPU phase):

```
/store/LION/ttv22/pcm/results/exp_2_true_map_20261028/
  run_fingerprint.json
  smoke/results.json
  calibration/metrics.csv
  calibration/selection.json
  evaluate/metrics.csv
  evaluate/images/0674/test_2101/
    gt.npy
    measured_c1.npy
    measured_c8.npy
    gt_cnn_raw_c1.npy
    gt_cnn_raw_c8.npy
    gt_cnn_matched_calibrated.npy
    gt_edge_matched_calibrated.npy
    maps/measured_cnn.npy
    maps/gt_cnn_raw.npy
    maps/gt_cnn_meanmatched.npy
    maps/gt_edge_meanmatched.npy
  timing/metrics.csv
  analysis/summary.json
  analysis/paired_gains.csv
  analysis/depth_convergence.csv
  analysis/reach_times.csv
  report/Exp_2_True_map_Report.tex
  report/Exp_2_True_map_Report.pdf
  report/Exp_2_True_map_Report_TeX_PDF_Figures_Data.zip
```

The results will be resumable. The `run_fingerprint.json` guard rejects a changed protocol, checkpoint, key LION source files or runner. Please preserve the executed source copy if changing this experiment after its first GPU run.

## Report commitments

The report generator refuses to compile until all 12 test acquisitions, 72 fixed-depth reconstructions and 180 depth-diagnostic rows exist. It includes both main research questions, calibration-only selections, pairwise quality tables, map visualizations, all four whole-image/zoom comparisons, line-retention and false-positive comments, and the full PDHG speed-versus-accuracy curves. It clearly separates **observed results** from **oracle-ground-truth input assumptions** and **possible confounding**.

The report title will start with **exp 2 True map**. The source/figure ZIP will permit recompilation without connected tuni paths for the figures. All metrics are computed on original float reconstructions, not exported display PNGs.
