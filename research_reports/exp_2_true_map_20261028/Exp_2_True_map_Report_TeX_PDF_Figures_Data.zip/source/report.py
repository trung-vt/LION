"""Produce an illustrated, compilable TeX/PDF after Exp 2 has actually run.

Strict completeness checks prevent fabricated or premature reports. CPU only.
"""
from __future__ import annotations

import csv
import json
import math
import re
import shutil
import subprocess
import zipfile
from collections import defaultdict
from pathlib import Path

import numpy as np

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

from analyse import compute,rows,ROOT,P

HERE=Path(__file__).resolve().parent


def tex_escape(s):
    s=str(s)
    mapping={'\\':r'\textbackslash{}','&':r'\&','%':r'\%','$':r'\$','#':r'\#','_':r'\_',
             '{':r'\{','}':r'\}','~':r'\textasciitilde{}','^':r'\textasciicircum{}'}
    return ''.join(mapping.get(c,c) for c in s)


def fmt(value,d=3):return ('--' if not np.isfinite(float(value)) else f'{float(value):.{d}f}')


def collect_map_statistics(out):
    result=[]
    for image in P['data']['image_ids']:
        for seed in P['data']['noise_seed_specs']:
            if seed['split']!='test':continue
            meta=out/'evaluate/images'/f'{image:04d}'/seed['key']/'maps/map_meta.json'
            if not meta.exists():raise FileNotFoundError(meta)
            s=json.loads(meta.read_text())
            for key,values in s['statistics'].items():
                result.append(dict(image_id=image,seed_key=seed['key'],kind=key,**values))
    return result


def figures(out, summary):
    chart=out/'report/figures';chart.mkdir(parents=True,exist_ok=True)
    table=rows(out/'evaluate/metrics.csv');timings=rows(out/'timing/metrics.csv')
    methods=P['scale']['test_methods']
    names={'measured_c1':'Measured CNN map, c=1','measured_c8':'Measured CNN map, c=8',
           'gt_cnn_raw_c1':'GT-to-CNN map, c=1','gt_cnn_raw_c8':'GT-to-CNN map, c=8',
           'gt_cnn_matched_calibrated':'GT-to-CNN mean-matched',
           'gt_edge_matched_calibrated':'GT-edge analytic mean-matched'}
    cols=plt.rcParams['axes.prop_cycle'].by_key()['color']
    # Global comparison of all six strategies.
    fig,ax=plt.subplots(1,2,figsize=(12,4),layout='constrained')
    values=[summary['methods'][m]['mean']['psnr'] for m in methods]
    contrast=[summary['methods'][m]['mean']['signed_retained_contrast'] for m in methods]
    ax[0].bar(range(len(methods)),values);ax[0].set_ylabel('PSNR (dB)')
    ax[1].bar(range(len(methods)),contrast);ax[1].set_ylabel('Mean signed retained line contrast')
    for a in ax:
        a.set_xticks(range(len(methods)),labels=[names[m].replace(' ','\n',1) for m in methods],rotation=35,ha='right',fontsize=8)
        a.grid(axis='y',alpha=.2)
    fig.savefig(chart/'accuracy_summary.png',dpi=160);plt.close(fig)

    fig,ax=plt.subplots(figsize=(8.5,5),layout='constrained')
    for i in P['data']['image_ids']:
        x=[float(r['psnr']) for r in table if int(r['image_id'])==i and r['method']=='measured_c8']
        for m in ['gt_cnn_raw_c8','gt_cnn_matched_calibrated','gt_edge_matched_calibrated']:
            y=[float(r['psnr']) for r in table if int(r['image_id'])==i and r['method']==m]
            ax.plot(np.mean(x),np.mean(y),'o',label=f'{i}: {names[m]}' if i==674 else None)
    ax.plot([20,45],[20,45],'k--',alpha=.5)
    ax.set(xlabel='Measured-map c=8 PSNR (dB)',ylabel='GT-informed map PSNR (dB)',title='Comparison to the calibrated baseline')
    ax.grid(alpha=.2);ax.legend(fontsize=8)
    fig.savefig(chart/'psnr_scatter.png',dpi=160);plt.close(fig)

    fig,ax=plt.subplots(1,3,figsize=(14,4),layout='constrained')
    for i,method in enumerate(P['solver']['timing_methods']):
        cases=[r for r in timings if r['method']==method]
        depths=P['solver']['diagnostic_iterations']
        secs=[np.median([float(r['time_median_s']) for r in cases if int(r['iterations'])==k]) for k in depths]
        quality=[np.mean([float(r['psnr']) for r in cases if int(r['iterations'])==k]) for k in depths]
        ax[0].plot(depths,quality,'o-',label=names[method])
        ax[1].plot(depths,secs,'o-',label=names[method])
        ax[2].plot(secs,quality,'o-',label=names[method])
    ax[0].set(xlabel='PDHG iterations',ylabel='Mean PSNR (dB)')
    ax[1].set(xlabel='PDHG iterations',ylabel='Median GPU solve time (s)')
    ax[2].set(xlabel='Median GPU solve time (s)',ylabel='Mean PSNR (dB)')
    for a in ax:a.grid(alpha=.2)
    ax[0].legend(fontsize=8)
    fig.savefig(chart/'accuracy_speed.png',dpi=165);plt.close(fig)
    # Show all four GT images and their network- and gradient-derived maps.
    for i in P['data']['image_ids']:
        folder=out/'evaluate/images'/f'{i:04d}'/'test_2101'
        orig=np.load(folder/'gt.npy')
        mapdir=folder/'maps'
        map_names=['measured_cnn','gt_cnn_raw','gt_cnn_meanmatched','gt_edge_meanmatched']
        maps=[np.load(mapdir/(m+'.npy')) for m in map_names]
        mn=min(float(m.min()) for m in maps);mx=max(float(m.max()) for m in maps)
        fig,ax=plt.subplots(1,5,figsize=(16,3.4),layout='constrained')
        ax[0].imshow(orig,cmap='gray',vmin=0,vmax=1.2)
        ax[0].set_title(f'CIGS {i} ground truth')
        for j,m in enumerate(maps):
            z=ax[j+1].imshow(m,cmap='magma',vmin=mn,vmax=mx)
            ax[j+1].set_title(map_names[j].replace('_',' '),fontsize=9)
        for a in ax:a.axis('off')
        fig.colorbar(z,ax=ax[1:].tolist(),shrink=.8,fraction=.015,label='TV weight (common range)')
        fig.savefig(chart/f'maps_{i:04d}.png',dpi=160);plt.close(fig)

        labels=['Ground truth']+[names[m] for m in methods]
        images=[orig]+[np.load(folder/(m+'.npy')) for m in methods]
        fig,ax=plt.subplots(2,4,figsize=(13.5,7.8),layout='constrained')
        for a,im,label in zip(ax.flat,images,labels):
            a.imshow(im,cmap='magma',vmin=0,vmax=1.2,interpolation='nearest');a.set_title(label,fontsize=9);a.axis('off')
        for a in list(ax.flat)[len(images):]:a.axis('off')
        fig.savefig(chart/f'full_{i:04d}.png',dpi=165);plt.close(fig)

        # ROI centred on the previously audited narrow feature, preserving scale.
        exp1=json.loads(Path(P['paths']['source_exp1_protocol']).read_text())
        spec=exp1['line_annotations'][str(i)]
        if spec['direction']=='horizontal':
            x0=max(0,spec['start']-10);x1=min(256,spec['end_exclusive']+10)
            y0=max(0,spec['center']-16);y1=min(256,spec['center']+17)
        else:
            x0=max(0,spec['center']-16);x1=min(256,spec['center']+17)
            y0=max(0,spec['start']-10);y1=min(256,spec['end_exclusive']+10)
        fig,ax=plt.subplots(2,4,figsize=(13.5,6.5),layout='constrained')
        for a,im,label in zip(ax.flat,images,labels):
            a.imshow(im[y0:y1,x0:x1],cmap='magma',vmin=0,vmax=1.2,interpolation='nearest')
            a.set_title(label,fontsize=9);a.axis('off')
        for a in list(ax.flat)[len(images):]:a.axis('off')
        fig.savefig(chart/f'roi_{i:04d}.png',dpi=165);plt.close(fig)
    return chart


def write_tex(out,summary,charts):
    choice=json.loads((out/'calibration/selection.json').read_text())['selected']
    conf=P['evaluation']
    title='exp 2 True map'
    subtitle='Ground-truth-informed spatial regularisation maps for PCM U-TV'
    q=[r'\documentclass[11pt,a4paper]{article}',r'\usepackage[margin=22mm]{geometry}',
       r'\usepackage[T1]{fontenc}',r'\usepackage{lmodern}',r'\usepackage{amsmath,amssymb}',
       r'\usepackage{graphicx}',r'\usepackage{booktabs,longtable,tabularx}',
       r'\usepackage{float}',r'\usepackage{hyperref}',r'\hypersetup{colorlinks=true,linkcolor=blue,urlcolor=blue}',
       r'\setlength{\parskip}{0.5em}',r'\setlength{\parindent}{0pt}',
       r'\title{\textbf{exp 2 True map}\\[4pt]\large Ground-truth-informed spatial regularisation maps for PCM U-TV\\ Accuracy, line retention, and PDHG computation time}',
       r'\author{PCM LION research experiment}',r'\date{28 October 2026}',r'\begin{document}',
       r'\maketitle\tableofcontents\clearpage',
       r'\section{Executive summary}',
       r'This experiment is an \textbf{offline counterfactual diagnostic}, not a deployable reconstruction algorithm: the actual ground-truth image is used only to compute alternative TV maps. The noisy measurements, operator, solver and initial iterate remain the same. The maps are not provably optimal; their use of ground truth must not be confused with a practical inverse-problem method.',
       r'The main comparison is always against the calibrated measurement-conditioned U-TV map at $c=8$, not only the uncalibrated $c=1$ method. Both mean-matching and calibration-only scalar selection are used to limit confounding by global regularisation strength.',
       r'\section{Map construction and experimental setup}',
       r'We study $y=Ax^\star+\varepsilon$ with the same PCM Hadamard measurement simulation, sample patterns, and noise seeds as Experiment 1. The original U-TV image is produced with the learned map $\Lambda_y=\Lambda_\theta(z(y))$, where $z(y)$ is the CG image used by the trained model. The alternative CNN map is $\Lambda_{\mathrm{GT}}=\Lambda_\theta(Sx^\star)$, with $S$ the same image intensity scaling used by the PCM forward model. Both maps use the \emph{same frozen CNN}.',
       r'\begin{align*}',
       r'\widetilde\Lambda_{\mathrm{GT}}&=\Lambda_{\mathrm{GT}}\frac{\operatorname{mean}(\Lambda_y)}{\operatorname{mean}(\Lambda_{\mathrm{GT}})},\\',
       r'\Lambda_{\mathrm{edge}}&=\operatorname{mean}(\Lambda_y)\frac{w(\nabla Sx^\star)}{\operatorname{mean}(w(\nabla Sx^\star))},\\',
       r'w(g)&=\epsilon+(1-\epsilon)\exp[-(g/\kappa)^2].',
       r'\end{align*}',
       r'Here $\epsilon=0.05$ and $\kappa$ is the 90th percentile of strictly positive GT gradient magnitudes. The edge map is designed to penalise known sharp transitions less strongly; it is a heuristic, \emph{not} an oracle-minimising parameter map. Mean-matching makes the average unscaled TV penalty comparable to the measurement-conditioned baseline.',
       r'\begin{equation*}',r'x_{m,c,K}=\mathrm{PDHG}_{K}\!\left(y,\;c\Lambda_m\right),',r'\end{equation*}',
       r'with identical $y,A$, zero initialisation and model step sizes for all compared maps. All primary reconstructions use 256 steps. Map-scale candidates are selected only from the two calibration noise seeds, and the results below are for three held-out noise seeds per image.',
       r'\subsection{Ground-truth disclosure and inference limitation}',
       r'Using $x^\star$ to design a regulariser can produce more informative spatial weights but is unavailable for real measurements. Any apparent reduction in pre-processing time by bypassing CG is \emph{not} a realistic inference-time improvement. GPU timing on a 4070 shared with ongoing model training is exploratory until repeated on an otherwise idle device.',
       r'\section{Scale calibration (calibration seeds only)}',
       r'\begin{center}\begin{tabular}{lrr}\toprule Map type & Selected scalar $c$ & Calibration mean PSNR (dB)\\\midrule']
    for key in P['scale']['selection_methods']:
        z=choice[key];q.append(f'{tex_escape(key)} & {fmt(z["chosen_scale"],3)} & {fmt(z["chosen_calibration_psnr"],3)} \\\\')
    q+=[r'\bottomrule\end{tabular}\end{center}',
       r'This selection uses ground-truth PSNR for the two calibration-noise seeds of each of the same four CIGS images. The three held-out test-noise seeds are excluded from selecting scale; this is not a test on previously unseen image structures.',
       r'\textbf{Boundary warning:} the GT-edge map selects $c=0.5$, the \emph{smallest} prespecified candidate in $\{0.5,1,2,4,8,16,32\}$. Its optimum may lie below the tested range. Its observed PSNR deficit therefore does not rule out better edge-map performance with a wider scale search.',
       r'\section{Held-out test accuracy}',
       r'\begin{center}\small\begin{tabular}{lrrrr}\toprule Method & PSNR & SSIM & HaarPSI & MSE $\times 10^3$ \\\midrule']
    for method in P['scale']['test_methods']:
        d=summary['methods'][method]['mean'];q.append(f'{tex_escape(method)} & {fmt(d["psnr"])} & {fmt(d["ssim"])} & {fmt(d["haarpsi"])} & {fmt(d["mse"]*1000)} \\\\')
    q+=[r'\bottomrule\end{tabular}\end{center}',
        r'Means are balanced across the four images, each evaluated at three noise seeds. With only four distinct images, do not interpret noise-seed variations as twelve independent image samples.',
        r'\begin{figure}[H]\centering\includegraphics[width=.99\textwidth]{figures/accuracy_summary.png}\caption{Global accuracy and local annotated-line contrast. A gain in PSNR can coexist with a loss in a true thin line.}\end{figure}',
        r'\begin{figure}[H]\centering\includegraphics[width=.77\textwidth]{figures/psnr_scatter.png}\caption{Comparison of ground-truth-assisted maps against the calibrated $c=8$ measurement-conditioned map. Points above the diagonal favour the alternative map.}\end{figure}',
        r'\section{Paired changes against the calibrated U-TV baseline}',
        r'\begin{center}\begin{tabular}{lr}\toprule Method & Mean PSNR difference (dB) \\\midrule']
    for m,gain in summary['paired_mean_psnr_gain_vs_fixed_c8'].items():
        q.append(f'{tex_escape(m)} & {gain:+.4f} \\\\')
    q+=[r'\bottomrule\end{tabular}\end{center}',
        r'The signed line contrast is evaluated separately. CIGS image 0917 contains a conductor track, not a confirmed crack; none of the four line annotations is a validated material-defect segmentation.',
        r'\section{PDHG iteration count, accuracy, and runtime}',
        r'\begin{figure}[H]\centering\includegraphics[width=\textwidth]{figures/accuracy_speed.png}\caption{Measured PDHG iterations, median solve time and image accuracy. Timings exclude GT acquisition and are not a deployable end-to-end speed comparison.}\end{figure}',
        r'Time-to-quality is measured by the earliest step count reaching the measured-map $c=8$ PSNR (256 steps) minus $0.1$ dB. A second criterion measures distance to each map\textquotesingle s own 1024-step approximate solution. Neither is a rigorous primal-dual gap certificate. Methods may fail to reach a common target; these failures are reported rather than assigned a fictional runtime.',
        r'All whole-image and ROI comparisons use a common intensity range $[0,1.2]$. The maps in each per-image figure use a shared range across displayed variants; mean-matched maps suppress the effect of arbitrary CNN output scale. These figures show \emph{one predeclared test noise realisation per image}; the quantitative tables cover all three.',
       ]
    q += [r'\subsection{Line preservation}',
          r'\begin{center}\small\begin{tabular}{lrrr}\toprule Method & Retained contrast & Line recall & False positive rate \\ \midrule']
    for method in P['scale']['test_methods']:
        v=summary['methods'][method]['mean']
        q.append(f'{tex_escape(method)} & {fmt(v["signed_retained_contrast"])} & {fmt(v["ridge_0p025_center_recall"])} & {fmt(v["ridge_0p025_false_positive_fraction"])} \\\\')
    q += [r'\bottomrule\end{tabular}\end{center}',
          r'These are fixed-threshold fine-line diagnostics, not verified crack-segmentation metrics. Image 0917 contains a conductor track.']
    timing_rows=rows(out/'timing/metrics.csv')
    q += [r'\subsection{Fixed-depth PDHG runtime}',
          r'\begin{center}\small\begin{tabular}{lrrr}\toprule Method & 128 steps (s) & 256 steps (s) & 512 steps (s) \\ \midrule']
    for method in P['solver']['timing_methods']:
        vals=[np.median([float(r['time_median_s']) for r in timing_rows
             if r['method']==method and int(r['iterations'])==k]) for k in (128,256,512)]
        q.append(f'{tex_escape(method)} & {fmt(vals[0],4)} & {fmt(vals[1],4)} & {fmt(vals[2],4)} \\\\')
    q += [r'\bottomrule\end{tabular}\end{center}',
          r'Times are measured from the actual GPU execution and exclude GT acquisition and CG construction. Concurrent 4070 training may affect timings.']
    reached=rows(out/'analysis/reach_times.csv')
    q += [r'\subsection{Time to comparable reconstruction quality}',
          r'\begin{center}\small\begin{tabular}{lrrr}\toprule Method & Successful / 12 & Median steps & Median time (s) \\ \midrule']
    for method in P['solver']['timing_methods']:
        hits=[r for r in reached if r['method']==method and r['reach_reference_psnr_step'] not in ('',None,'None')]
        steps=fmt(np.median([float(r['reach_reference_psnr_step']) for r in hits]),0) if hits else '--'
        sec=fmt(np.median([float(r['reach_reference_psnr_time_s']) for r in hits]),4) if hits else '--'
        q.append(f'{tex_escape(method)} & {len(hits)}/12 & {steps} & {sec} \\\\')
    q += [r'\bottomrule\end{tabular}\end{center}',
          r'The reference is the measured-map c=8 at 256 iterations, allowing 0.1 dB lower PSNR. Inaccessible quality targets are failures, not zero-cost successes.']
    unique={}
    for rr in rows(out/'evaluate/metrics.csv'):
        unique.setdefault((rr['image_id'],rr['seed_key']),rr)
    q += [r'\subsection{Map-generation overhead}',
          r'\begin{center}\begin{tabular}{lr}\toprule Map creation & Median seconds \\ \midrule']
    for key,label in [('map_predict_measured_s',r'CNN(CG($y$))'),('map_predict_gt_s',r'CNN($Sx^\star$)'),('map_design_edge_s','GT edge weighting')]:
        q.append(f'{label} & {fmt(np.median([float(v[key]) for v in unique.values()]),6)} \\\\')
    q += [r'\bottomrule\end{tabular}\end{center}',
          r'These costs assume the input image is already available. GT itself is inaccessible in real PCM reconstruction and cannot be counted as a speed gain.']
    q.append(r'\section{Complete four-image visual comparisons}')
    for i in P['data']['image_ids']:
        q+=[f'\\subsection{{CIGS {i:04d}}}',
            rf'\begin{{figure}}[H]\centering\includegraphics[width=\textwidth]{{figures/maps_{i:04d}.png}}\caption{{GT and spatial regularisation maps for CIGS {i:04d}. The GT-informed CNN prediction is not an optimal or deployable map.}}\end{{figure}}',
            rf'\begin{{figure}}[H]\centering\includegraphics[width=\textwidth]{{figures/full_{i:04d}.png}}\caption{{Whole-image reconstruction comparison for CIGS {i:04d} under one shared acquisition.}}\end{{figure}}',
            rf'\begin{{figure}}[H]\centering\includegraphics[width=\textwidth]{{figures/roi_{i:04d}.png}}\caption{{Common-scale close-ups of the audited fine-line region, CIGS {i:04d}. Distinguish the conductor track in image 0917 from crack-like lines.}}\end{{figure}}']
    q+=[r'\section{Interpretation and limitations}',
       r'\begin{enumerate}',
       r'\item The GT-informed map need not minimise expected reconstruction error, because the original U-Net was never trained to map clean ground truth to optimal regularisation weights. Passing GT may also be an out-of-distribution input relative to its CG training images.',
       r'\item The GT-edge map is a hand-crafted spatial prior; matching global map means is helpful but does not imply equal effective TV regularisation for each image. Its selected scalar is the lower boundary of the tested search grid; sub-0.5 scalars are an untested sensitivity analysis.',
       r'\item Compare measured $c=8$ with GT-informed variants at the same PDHG depth. At a fixed number of iterations, a changed map need not make PDHG itself faster.',
       r'\item A comparison at the same target PSNR can show practical iteration savings, but it is not a mathematically rigorous convergence-rate comparison because each map defines a different objective.',
       r'\item Input GT is supplied for free only as an upper-bound diagnostic. It must not be described as a deployable PCM measurement-to-reconstruction algorithm or measured as a real reduction in end-to-end inference latency.',
       r'\item These four images were already examined in Experiment 1. The result is exploratory; scale-calibration seeds and test-noise seeds are disjoint, but no completely untouched image population is claimed.',
       r'\end{enumerate}',
       r'\section{Reproducibility and source data}',
       r'All experiment code, source protocol, map arrays, reconstructions and metrics were generated with a frozen checkpoint and the exact Experiment 1 acquisition seeds. The archive includes \texttt{protocol.json}, \texttt{metrics.csv}, \texttt{selection.json}, and report figures. No new network parameters were trained.',
       r'\end{document}']
    tex=out/'report'/'Exp_2_True_map_Report.tex'
    tex.write_text('\n'.join(q)+'\n')
    return tex


def compile_tex(tex):
    folder=tex.parent
    outputs=[]
    for pass_no in (1,2):
        result=subprocess.run(['pdflatex','-interaction=nonstopmode','-halt-on-error',tex.name],
                              cwd=folder,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                              text=True,timeout=120)
        outputs.append(result.stdout)
        if result.returncode!=0:
            (folder/'pdflatex.log').write_text('\n'.join(outputs))
            raise RuntimeError(f'LaTeX failed on pass {pass_no}:\n'+result.stdout[-7000:])
    (folder/'pdflatex.log').write_text('\n'.join(outputs))
    pdf=tex.with_suffix('.pdf')
    if not pdf.is_file():raise RuntimeError('Expected report PDF absent')
    # Quick independent structural check.
    info=subprocess.run(['pdfinfo',str(pdf)],capture_output=True,text=True,check=True).stdout
    if 'Pages:' not in info:raise RuntimeError('Invalid compiled PDF')
    print('EXPERIMENT_REPORT_PDF_OK',pdf)
    return pdf


def package(out,tex,pdf,figs):
    z=out/'report'/'Exp_2_True_map_Report_TeX_PDF_Figures_Data.zip'
    paths=[tex,pdf,HERE/'run.py',HERE/'true_maps.py',HERE/'analyse.py',HERE/'report.py',
           HERE/'protocol.json',HERE/'README.md',HERE/'launch.sh',
           out/'calibration/selection.json',out/'evaluate/metrics.csv',out/'timing/metrics.csv',
           out/'analysis/summary.json',out/'analysis/paired_gains.csv',out/'analysis/depth_convergence.csv',
           out/'analysis/reach_times.csv']+sorted(figs.glob('*.png'))
    if not all(f.is_file() for f in paths):raise FileNotFoundError('Missing reproducibility file')
    with zipfile.ZipFile(z,'w',compression=zipfile.ZIP_DEFLATED) as archive:
        for f in paths:
            if f.parent==figs: arcname='figures/'+f.name
            elif f.parent==HERE: arcname='source/'+f.name
            elif f.parent==tex.parent: arcname=f.name
            else: arcname='results/'+str(f.relative_to(out))
            archive.write(f,arcname)
    with zipfile.ZipFile(z) as archive:
        if archive.testzip():raise RuntimeError('Output ZIP corrupted')
    print('REPORT_ZIP_VALIDATED',z)


def main():
    summary=compute(ROOT)
    figures_dir=figures(ROOT,summary)
    tex=write_tex(ROOT,summary,figures_dir)
    pdf=compile_tex(tex)
    package(ROOT,tex,pdf,figures_dir)
    print('EXP2_REPORT_COMPLETE',tex,pdf)

if __name__=='__main__':main()
