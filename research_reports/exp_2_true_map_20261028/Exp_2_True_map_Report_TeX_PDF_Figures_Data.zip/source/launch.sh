#!/usr/bin/env bash
# Exp 2 True map: safe, bounded, explicitly initiated stages. No background work.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PHASE="${1:-}"
OPTION="${2:-}"
if (( $# < 1 || $# > 2 )); then
    echo 'Usage: bash launch.sh {preflight|smoke|calibration|evaluate|timing|analyse|report} [--allow-shared-gpu]' >&2
    exit 2
fi
case "$PHASE" in
  preflight|smoke|calibration|evaluate|timing|analyse|report) ;;
  *) echo "Unknown phase $PHASE" >&2; exit 2 ;;
esac
case "$OPTION" in
  ''|--allow-shared-gpu) ;;
  *) echo "Unknown option $OPTION" >&2;exit 2 ;;
esac
case "$PHASE" in
  preflight|analyse|report)
    if [[ -n "$OPTION" ]];then echo "GPU option not valid for CPU-only phase" >&2;exit 2;fi;;
esac
REPO=/home/t/Documents/GIT/LION
PY=/home/t/micromamba/envs/lion_3/bin/python
RESULTS=/store/LION/ttv22/pcm/results/exp_2_true_map_20261028
export PYTHONPATH="$HERE:$REPO"
export LION_DATA_PATH=/store/LION/ttv22/pcm/data
export OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 CUDA_DEVICE_ORDER=PCI_BUS_ID
cd "$REPO"
if [[ "$PHASE" == preflight || "$PHASE" == analyse || "$PHASE" == report ]];then
    export CUDA_VISIBLE_DEVICES=''
    echo 'CPU-only stage; no GPU reconstruction.'
    if [[ "$PHASE" == analyse ]];then exec "$PY" -u "$HERE/analyse.py";fi
    if [[ "$PHASE" == report ]];then exec "$PY" -u "$HERE/report.py";fi
    exec "$PY" -u "$HERE/run.py" --phase "$PHASE"
fi

# GPU phases may not affect or stop the incumbent training run.
export CUDA_VISIBLE_DEVICES=0
which nvidia-smi >/dev/null
GPU0="$(nvidia-smi --query-gpu=index,name,uuid --format=csv,noheader | head -1)"
[[ "$GPU0" == 0,*'RTX 4070'* ]] || { echo "Unexpected GPU 0: $GPU0" >&2; exit 3; }
UUID="$(echo "$GPU0" | awk -F', ' '{print $3}')"
GPU_PROCESSES="$(nvidia-smi --query-compute-apps=gpu_uuid,pid --format=csv,noheader | awk -F', ' -v uuid="$UUID" '$1==uuid {print $2}')"
TRAIN_PID=none
if [[ -n "$GPU_PROCESSES" ]];then
    if [[ "$OPTION" != '--allow-shared-gpu' ]];then
        echo '4070 is busy. Explicit --allow-shared-gpu is required; no action started.' >&2;exit 4
    fi
    COUNT=0
    while IFS= read -r pid;do
        [[ -n "$pid" ]] || continue
        cmdline="$(tr '\0' ' ' < "/proc/$pid/cmdline" 2>/dev/null || :)"
        if [[ "$cmdline" != *pcm_supervised_sapm_train* || "$cmdline" != *pcm_utv_zero_inclusive_4070_adam_lr2e4_scale1e3.yaml* ]];then
            echo "Unapproved GPU process $pid: $cmdline; refusing to run" >&2;exit 4
        fi
        COUNT=$((COUNT+1));TRAIN_PID=$pid
    done <<< "$GPU_PROCESSES"
    ((COUNT==1)) || { echo "Unexpected $COUNT existing GPU compute processes" >&2;exit 4; }
fi
WATCH=/store/LION/ttv22/pcm/results/20261027_utv_zero_unet3_f56_prepared/performance_watch/latest.json
TRAIN_LOG=/store/LION/ttv22/pcm/results/20261026_utv_zero_inclusive_4070_launch/train.log
BASELINE=2.30
if [[ "$TRAIN_PID" != none ]];then
    [[ "$OPTION" == '--allow-shared-gpu' ]] || exit 4
    BASELINE="$($PY - "$WATCH" "$TRAIN_LOG" "$TRAIN_PID" <<'PY'
import json,sys,time
from datetime import datetime,timezone
from pathlib import Path
j=json.load(open(sys.argv[1]));v=[x for x in j['rows'] if x['job']=='4070_original']
assert len(v)==1 and int(v[0]['pid'])==int(sys.argv[3]) and bool(v[0]['alive'])
assert v[0]['seconds_per_step'] is not None
age=(datetime.now(timezone.utc)-datetime.fromisoformat(j['utc'])).total_seconds()
assert -5<age<180,('stale monitor',age)
assert Path(sys.argv[2]).stat().st_mtime>time.time()-180
print(float(v[0]['seconds_per_step']))
PY
)"
fi
mkdir -p "$RESULTS/_control_logs"
command -v flock >/dev/null
exec 9>"$RESULTS/_control_logs/.exp2_gpu_stage.lock"
flock -n 9 || { echo 'Another Exp 2 GPU phase is running; abort.' >&2;exit 5; }
LOG="$RESULTS/_control_logs/${PHASE}_$(date -u +%Y%m%dT%H%M%SZ).log"
echo "Exp 2 True map: phase=$PHASE, GPU=4070, incumbent=$TRAIN_PID, monitor_baseline=${BASELINE}s/step, log=$LOG"
# Run the stage in the foreground under a monitor. SIGTERM targets only the
# experiment subprocess group; never send signals to any trainer.
"$PY" -u - "$BASELINE" "$TRAIN_LOG" "$LOG" "$TRAIN_PID" "$PY" -u "$HERE/run.py" --phase "$PHASE" <<'PY'
import os,signal,subprocess,sys,time,threading,re
from pathlib import Path
baseline=float(sys.argv[1]);trainlog=Path(sys.argv[2]);log=Path(sys.argv[3])
trainer=sys.argv[4];command=sys.argv[5:]
proc=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                      text=True,bufsize=1,start_new_session=True)
with log.open('w') as f:
    def relay():
        for line in proc.stdout:
            print(line.rstrip(),flush=True)
            f.write(line);f.flush()
    t=threading.Thread(target=relay,daemon=True);t.start()
    bad=0;reason=None;start=time.monotonic()
    while proc.poll() is None:
        if trainer!='none' and not Path('/proc/'+trainer).exists():
            reason='Incumbent trainer disappeared; abort Exp 2 only';break
        if time.monotonic()-start>1800:
            reason='Exp 2 GPU stage reached 30-minute safety limit';break
        if trainer!='none':
            try:
                with trainlog.open('rb') as h:
                    h.seek(max(0,trainlog.stat().st_size-23000))
                    recent=h.read().decode('utf8','replace').replace('\r','\n')
                match=re.findall(r'(\d+(?:\.\d+)?)s/it',recent)
                speed=float(match[-1]) if match else None
                bad=(bad+1 if speed is not None and speed>baseline*1.10 else 0)
                if bad>=3:reason=f'Original training throughput >10% slower: {speed:.3f}s/step';break
            except Exception as e:print('WATCH_WARNING',repr(e),flush=True)
        time.sleep(4)
    if reason:
        print('STOP_ONLY_EXP2',reason,flush=True)
        os.killpg(proc.pid,signal.SIGTERM)
        try:proc.wait(timeout=8)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid,signal.SIGKILL);proc.wait(timeout=4)
    t.join(timeout=8)
    code=proc.wait()
    print('EXP2_STAGE_EXIT',code,'elapsed_s',round(time.monotonic()-start,2),flush=True)
    if code or reason:sys.exit(code or 17)
PY
