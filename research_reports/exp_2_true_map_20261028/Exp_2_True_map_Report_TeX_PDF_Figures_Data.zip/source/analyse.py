"""CPU-only Exp 2 True map analysis. No synthetic/fabricated results permitted."""
from __future__ import annotations

import csv
import json
import math
import statistics
from collections import defaultdict
from pathlib import Path

import numpy as np

HERE=Path(__file__).resolve().parent
P=json.loads((HERE/'protocol.json').read_text())
ROOT=Path(P['paths']['output_root'])


def rows(path):
    if not path.exists():raise FileNotFoundError(path)
    with path.open(newline='') as f:return list(csv.DictReader(f))


def mean(a):
    return float(np.mean(list(a)))


def recs_by(rows_,key):
    d=defaultdict(list)
    for r in rows_:d[r[key]].append(r)
    return d


def validate_evaluation(table):
    ids=P['data']['image_ids']
    test_keys={x['key'] for x in P['data']['noise_seed_specs'] if x['split']=='test'}
    methods=P['scale']['test_methods']
    expected={(i,s,m) for i in ids for s in test_keys for m in methods}
    actual={(int(r['image_id']),r['seed_key'],r['method']) for r in table}
    if actual!=expected or len(table)!=len(expected):
        raise RuntimeError(f'Incomplete / duplicate evaluated results: {len(table)} rows, {len(expected)} expected, distinct {len(actual)}')
    if any(r['split']!='test' for r in table):raise RuntimeError('Evaluation contains non-test rows')


def validate_timing(table):
    ids=P['data']['image_ids']
    test_keys={x['key'] for x in P['data']['noise_seed_specs'] if x['split']=='test'}
    methods=P['solver']['timing_methods']
    depths=P['solver']['diagnostic_iterations']
    expected={(i,s,m,k) for i in ids for s in test_keys for m in methods for k in depths}
    actual={(int(r['image_id']),r['seed_key'],r['method'],int(r['iterations'])) for r in table}
    if len(table)!=len(expected) or expected!=actual:
        raise RuntimeError(f'Incomplete timing data {len(table)}/{len(expected)}')


def aggregate(table,key='method'):
    result={}
    for name,rows_ in recs_by(table,key).items():
        image_means={}
        for i,rs in recs_by(rows_,'image_id').items():
            image_means[i]={metric:mean(float(r[metric]) for r in rs)
                 for metric in ('psnr','ssim','haarpsi','mse','line_contrast',
                                'signed_retained_contrast','ridge_0p025_center_recall',
                                'ridge_0p025_false_positive_fraction','solve_s')}
        result[name]={'n_noisy_data':len(rows_),
                      'per_image':image_means,
                      'mean':{metric:mean(v[metric] for v in image_means.values())
                          for metric in next(iter(image_means.values()))}}
    return result


def matched_gains(table):
    lookup={(int(r['image_id']),r['seed_key'],r['method']):r for r in table}
    report=[]
    for image in P['data']['image_ids']:
        for seed in P['data']['noise_seed_specs']:
            if seed['split']!='test':continue
            ref=lookup[(image,seed['key'],'measured_c8')]
            for name in P['scale']['test_methods']:
                curr=lookup[(image,seed['key'],name)]
                report.append(dict(image_id=image,seed_key=seed['key'],method=name,
                      psnr_minus_measured_c8_db=float(curr['psnr'])-float(ref['psnr']),
                      ssim_minus_measured_c8=float(curr['ssim'])-float(ref['ssim']),
                      haarpsi_minus_measured_c8=float(curr['haarpsi'])-float(ref['haarpsi']),
                      contrast_minus_measured_c8=float(curr['line_contrast'])-float(ref['line_contrast'])))
    return report


def timing_and_convergence(table,root):
    depths=P['solver']['diagnostic_iterations']
    high=P['solver']['iterate_reference_depth']
    data=defaultdict(dict)
    for r in table:
        data[(int(r['image_id']),r['seed_key'],r['method'])][int(r['iterations'])]=r
    ref_rows=rows(root/'evaluate/metrics.csv')
    ref_lookup={(int(r['image_id']),r['seed_key'],r['method']):r for r in ref_rows}
    report=[]
    for (img,seed,method),krows in data.items():
        baseline=ref_lookup[(img,seed,'measured_c8')]
        threshold=float(baseline['psnr'])-P['solver']['fixed_psnr_target_margin_db']
        xref=np.load(root/'timing/images'/f'{img:04d}'/seed/(method+f'_steps_{high:04d}.npy'))
        refnorm=float(np.linalg.norm(xref))
        for k in depths:
            r=krows[k]
            arr=np.load(root/'timing/images'/f'{img:04d}'/seed/(method+f'_steps_{k:04d}.npy'))
            relative=float(np.linalg.norm(arr-xref)/max(refnorm,1e-12))
            report.append(dict(image_id=img,seed_key=seed,method=method,iterations=k,
                          time_median_s=float(r['time_median_s']),psnr=float(r['psnr']),
                          psnr_reference_c8_256=float(baseline['psnr']),
                          achieved_reference_psnr=bool(float(r['psnr'])>=threshold),
                          relative_distance_to_same_map_1024=relative,
                          within_1pct_own_reference=bool(relative<=P['solver']['iterate_relative_tolerance'])))
    return report


def compute(root=ROOT,save=True):
    evaluation=rows(root/'evaluate/metrics.csv')
    timing=rows(root/'timing/metrics.csv')
    validate_evaluation(evaluation);validate_timing(timing)
    summarized=aggregate(evaluation)
    paired=matched_gains(evaluation)
    conv=timing_and_convergence(timing,root)
    per_method_by_image=recs_by(paired,'method')
    paired_means={m:mean(mean(float(r['psnr_minus_measured_c8_db']) for r in rr)
                         for _,rr in recs_by(sub,'image_id').items())
                  for m,sub in per_method_by_image.items()}
    # First depth meeting each reference target, or None if not met.
    grouped=defaultdict(list)
    for r in conv:grouped[(r['image_id'],r['seed_key'],r['method'])].append(r)
    reach=[]
    for (img,seed,method),recs in grouped.items():
        hits=[r for r in recs if r['achieved_reference_psnr']]
        con=[r for r in recs if r['within_1pct_own_reference']]
        reach.append(dict(image_id=img,seed_key=seed,method=method,
                          reach_reference_psnr_step=min((r['iterations'] for r in hits),default=None),
                          reach_reference_psnr_time_s=min((r['time_median_s'] for r in hits),default=None),
                          reach_own_1pct_step=min((r['iterations'] for r in con),default=None),
                          reach_own_1pct_time_s=min((r['time_median_s'] for r in con),default=None)))
    result=dict(experiment=P['experiment'],status='complete-data-analysis',
                n_images=4,n_test_acquisitions=12,n_evaluation_rows=len(evaluation),
                n_timing_rows=len(timing),methods=summarized,
                paired_mean_psnr_gain_vs_fixed_c8=paired_means,
                line_feature_note='CIGS 0917 annotation is an electrode/conductor track, not a validated crack.',
                map_semantics_note='Ground-truth-assisted maps are diagnostic, NOT uniquely optimal nor deployable for PCM measurements.',
                runtime_warning=P['solver']['timing_warning'])
    if save:
        out=root/'analysis';out.mkdir(parents=True,exist_ok=True)
        (out/'summary.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
        for filename,items in [('paired_gains.csv',paired),('depth_convergence.csv',conv),('reach_times.csv',reach)]:
            with (out/filename).open('w',newline='') as f:
                w=csv.DictWriter(f,fieldnames=list(items[0]));w.writeheader();w.writerows(items)
    return result


def main():
    result=compute()
    print('EXP2_ANALYSIS_COMPLETE',json.dumps(dict(
          n_test_acquisitions=result['n_test_acquisitions'],n_timing_rows=result['n_timing_rows'],
          psnr_gains=result['paired_mean_psnr_gain_vs_fixed_c8']),indent=2))

if __name__=='__main__':main()
