"""Map construction and analysis helpers for Exp 2 True map.

No network or LION dependency at import time. PyTorch is used only by callers.
"""
from __future__ import annotations

import math
from typing import Any

import numpy as np


def forward_gradient_magnitude(x):
    """Magnitude of forward finite differences; the last row/column are zero.

    Used solely to construct a GT-edge diagnostic map, NOT as a claim of
    identical boundary conventions to mrpro's PDHG gradient operator.
    x: torch.Tensor with shape (B,1,H,W)
    """
    import torch
    assert x.ndim == 4 and x.shape[1] == 1
    dx = torch.zeros_like(x)
    dy = torch.zeros_like(x)
    dx[..., :-1] = x[..., 1:] - x[..., :-1]
    dy[..., :-1, :] = x[..., 1:, :] - x[..., :-1, :]
    return torch.sqrt(dx.square() + dy.square())


def ground_truth_edge_map(gt_model, measured_map, *, percentile=0.90,
                          minimum_weight=0.05, gradient_eps=1e-5,
                          normalisation_eps=1e-10):
    """Construct an edge-protecting positive TV map from GT gradients.

    Low weights at strong reference gradients reduce penalisation near true
    discontinuities. Mean weight is matched to the measured CNN map to
    isolate the *spatial pattern* of regularisation from its global scale.
    This is a designed diagnostic map, not an oracle optimal map.
    """
    import torch
    assert gt_model.shape == measured_map.shape
    assert 0 < minimum_weight < 1
    assert 0 < percentile < 1
    grad = forward_gradient_magnitude(gt_model)
    positive = grad[grad > gradient_eps]
    if positive.numel():
        kappa = torch.quantile(positive, percentile).clamp_min(gradient_eps)
        weight = minimum_weight + (1-minimum_weight) * torch.exp(-((grad / kappa)**2))
    else:
        kappa = torch.as_tensor(gradient_eps, device=gt_model.device, dtype=gt_model.dtype)
        weight = torch.ones_like(gt_model)
    out = match_map_mean(weight, measured_map, eps=normalisation_eps)
    return out, grad, float(kappa.detach().cpu())


def match_map_mean(candidate, measured_map, *, eps=1e-10):
    """Match spatial mean per sample; no elementwise GT leakage into PDHG."""
    import torch
    assert candidate.ndim==4 and candidate.shape==measured_map.shape
    if not bool(torch.isfinite(candidate).all()) or not bool(torch.isfinite(measured_map).all()):
        raise ValueError('Nonfinite parameter map')
    if float(candidate.min()) < 0 or float(measured_map.min()) < 0:
        raise ValueError('Map must be non-negative')
    avg = candidate.mean(dim=(-1,-2,-3),keepdim=True)
    if bool(torch.any(avg <= eps)):
        raise ValueError('Candidate map has near-zero mean; cannot mean-match')
    ref = measured_map.mean(dim=(-1,-2,-3),keepdim=True)
    if bool(torch.any(ref <= eps)):
        raise ValueError('Measured map has near-zero mean; cannot mean-match')
    return candidate * ref / avg


def map_statistics(candidate: np.ndarray, reference: np.ndarray,
                   gt_gradient: np.ndarray | None = None) -> dict[str,float]:
    a=np.asarray(candidate,dtype=np.float64).reshape(-1)
    b=np.asarray(reference,dtype=np.float64).reshape(-1)
    if a.shape!=b.shape or not np.isfinite(a).all() or not np.isfinite(b).all():
        raise ValueError('Invalid map for statistics')
    if a.std()>1e-12 and b.std()>1e-12:
        correlation=float(np.corrcoef(a,b)[0,1])
    else:
        correlation=float('nan')
    result=dict(map_min=float(a.min()),map_mean=float(a.mean()),
                map_max=float(a.max()),map_std=float(a.std()),
                map_mae_to_measured=float(np.mean(np.abs(a-b))),
                map_corr_to_measured=correlation)
    if gt_gradient is not None:
        g=np.asarray(gt_gradient,dtype=np.float64).reshape(-1)
        assert g.shape==a.shape
        good=g>1e-5
        if good.any() and (~good).any():
            q=np.quantile(g[good],.90)
            hi=g>=q
            if hi.any() and (~hi).any():
                result['lambda_mean_high_grad_over_other']=float(a[hi].mean()/max(a[~hi].mean(),1e-12))
    return result


def map_validity(maps:dict):
    """Live checks before PDHG invocation."""
    import torch
    expected={'measured_cnn','gt_cnn_raw','gt_cnn_meanmatched','gt_edge_meanmatched'}
    assert expected <= set(maps)
    ref=maps['measured_cnn']
    assert ref.ndim==4 and ref.shape[1]==1
    for name,v in maps.items():
        if name=='gt_gradient':continue
        assert v.shape == ref.shape, (name,v.shape,ref.shape)
        assert bool(torch.isfinite(v).all()), name
        assert float(v.min())>=0, name
        assert float(v.mean())>0, name
    for name in ('gt_cnn_meanmatched','gt_edge_meanmatched'):
        rel=abs(float(maps[name].mean())/float(ref.mean())-1)
        assert rel < 1e-5, (name,rel)


def select_by_calibration(rows:list[dict], scales:list[float], methods:list[str],
                          ids:list[int], seed_keys:list[str]) -> dict:
    """Choose each method's scale using ONLY calibration records.

    First average over seeds within each image, then give images equal weight.
    Tie-break to the smaller scale. Does NOT consult test metrics.
    """
    wanted={(int(i),str(s),str(m),float(c)) for i in ids for s in seed_keys
            for m in methods for c in scales}
    parsed={(int(r['image_id']),str(r['seed_key']),str(r['map_kind']),float(r['scale'])):r
            for r in rows}
    if len(parsed)!=len(rows):raise ValueError('Duplicate calibration records')
    if not wanted.issubset(parsed):
        missing=wanted-set(parsed)
        raise ValueError(f'Incomplete calibration: {len(missing)} missing; first {list(missing)[:3]}')
    if any(r['split']!='calibration' for r in rows):raise ValueError('Non-calibration row leaked into scale selection')
    results={}
    for method in methods:
        candidates=[]
        for c in scales:
            image_means=[]
            for i in ids:
                scores=[float(parsed[(i,s,method,float(c))]['psnr']) for s in seed_keys]
                image_means.append(float(np.mean(scores)))
            candidates.append(dict(scale=float(c),mean_psnr=float(np.mean(image_means))))
        candidates.sort(key=lambda x:(-x['mean_psnr'],x['scale']))
        results[method]={'chosen_scale':candidates[0]['scale'],
                         'chosen_calibration_psnr':candidates[0]['mean_psnr'],
                         'full_calibration_curve':sorted(candidates,key=lambda x:x['scale'])}
    return results


def timed_statistics(values:list[float]) -> dict:
    a=np.asarray(values,dtype=float)
    if not a.size or not np.all(np.isfinite(a)) or np.any(a<=0):
        raise ValueError('Invalid times')
    return dict(time_median_s=float(np.median(a)),time_mean_s=float(np.mean(a)),
                time_min_s=float(a.min()),time_max_s=float(a.max()))
