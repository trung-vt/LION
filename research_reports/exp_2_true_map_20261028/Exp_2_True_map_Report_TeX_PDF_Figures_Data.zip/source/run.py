"""Exp 2 True map: offline oracle-map diagnostic for U-TV PCM.

Phases: preflight (CPU), smoke (GPU), calibration (GPU), evaluate (GPU),
        timing (GPU), analyse (CPU), report (CPU).
Do not invoke GPU phases directly; launch.sh enforces the 4070 guard.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import sys
import time
from types import SimpleNamespace

import numpy as np

from true_maps import (ground_truth_edge_map, match_map_mean,
                       map_statistics, map_validity, select_by_calibration,
                       timed_statistics)

HERE = Path(__file__).resolve().parent
PROTOCOL_PATH = HERE / 'protocol.json'


def sha256(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(2**20),b''):h.update(chunk)
    return h.hexdigest()


def load():
    p=json.loads(PROTOCOL_PATH.read_text())
    assert p['experiment']=='exp 2 True map'
    assert p['data']['image_ids']==[674,985,917,864]
    assert len(p['data']['noise_seed_specs'])==5
    assert sum(s['split']=='calibration' for s in p['data']['noise_seed_specs'])==2
    assert sum(s['split']=='test' for s in p['data']['noise_seed_specs'])==3
    assert p['solver']['main_iterations']==256
    assert sorted(p['solver']['diagnostic_iterations'])==p['solver']['diagnostic_iterations']
    return p


def source_modules(p):
    src=Path(p['paths']['source_exp1_code'])
    if str(src) not in sys.path:sys.path.insert(0,str(src))
    import run as source
    import metrics as line_module
    return source,line_module


def root(p):return Path(p['paths']['output_root'])


def read_records(path):
    if not path.exists():return []
    with path.open(newline='') as f:return list(csv.DictReader(f))


def add_row(path: Path, record: dict):
    path.parent.mkdir(parents=True,exist_ok=True)
    exists=path.exists()
    if exists:
        with path.open(newline='') as f:
            reader=csv.DictReader(f)
            if reader.fieldnames!=list(record):
                raise RuntimeError(f'CSV schema mismatch: {path}; refuse to mix results')
    with path.open('a',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(record))
        if not exists:writer.writeheader()
        writer.writerow(record)
        f.flush()
        os.fsync(f.fileno())


def write_json(path, x):
    path.parent.mkdir(parents=True,exist_ok=True)
    text=json.dumps(x,indent=2,allow_nan=False,sort_keys=True)+'\n'
    if path.exists():
        if path.read_text()!=text:raise RuntimeError(f'Existing immutable metadata differs: {path}')
    else:path.write_text(text)


def fingerprint(p,source,model_manifest):
    base=Path(p['paths']['repo'])
    return dict(experiment=p['experiment'],protocol_sha256=sha256(PROTOCOL_PATH),
                exp1_protocol_sha256=sha256(Path(p['paths']['source_exp1_protocol'])),
                exp1_run_sha256=sha256(Path(p['paths']['source_exp1_code'])/'run.py'),
                checkpoint=model_manifest,
                runner_sha256=sha256(HERE/'run.py'),
                maps_sha256=sha256(HERE/'true_maps.py'),
                lion_model_sha256=sha256(base/'LION/models/AdaptiveTVPCMNetwork.py'),
                lion_base_solver_sha256=sha256(base/'LION/models/BasePdhgNet.py'))


def preflight(p):
    import inspect
    source,lines=source_modules(p)
    q=source.load_protocol(Path(p['paths']['source_exp1_protocol']))
    assert q['data']['ids']==p['data']['image_ids']
    assert q['data']['sampling_ratio']==p['data']['sampling_ratio']
    assert q['data']['coarse_j']==p['data']['coarse_j']
    assert q['noise']['seed_sets']==p['data']['noise_seed_specs']
    assert len(q['line_annotations'])>=4
    exp1=Path(p['paths']['source_exp1_results'])
    issues=[]
    for image in p['data']['image_ids']:
        f,_=source.original_png(source.data_root(q),image)
        assert f.exists() and sha256(f)
        for seed in p['data']['noise_seed_specs']:
            d=exp1/'images'/f'{image:04d}'/seed['key']
            for name in ('measurement.npy','sampled_indices.npy','ground_truth.npy','fixed_lambda_map.npy'):
                f=d/name
                if not f.is_file():issues.append(str(f))
    if issues:raise FileNotFoundError('Exp1 archived data missing: '+'; '.join(issues[:6]))
    ckpt=Path(p['checkpoint']['run_dir'])/'checkpoints'/p['checkpoint']['filename']
    conf=Path(p['checkpoint']['run_dir'])/p['checkpoint']['config_name']
    assert ckpt.is_file() and conf.is_file()
    assert sha256(ckpt)==p['checkpoint']['expected_sha256'],('Checkpoint changed',ckpt)
    if os.environ.get('CUDA_VISIBLE_DEVICES','')=='0':
        raise AssertionError('CPU preflight must not make GPU visible')
    from LION.models.AdaptiveTVPCMNetwork import AdaptiveTVPCMNetwork
    for a in ('max_iterations','lambda_reg'):
        assert a in inspect.signature(AdaptiveTVPCMNetwork.forward).parameters
    print('CPU_PREFLIGHT_PASS',json.dumps(dict(
        images=p['data']['image_ids'],acquisitions=20,
        checkpoint=str(ckpt),checkpoint_sha256=sha256(ckpt),
        source_exp1_coarse=str(exp1),
        calibrated_scale=p['scale']['measured_calibrated'],
        report_name=p['experiment'],no_gpu_execution=True),indent=2))


def load_model_and_case(p):
    if os.environ.get('CUDA_VISIBLE_DEVICES')!='0':
        raise RuntimeError('GPU stages require the guarded launcher on CUDA_VISIBLE_DEVICES=0')
    source,lines=source_modules(p)
    q=source.load_protocol(Path(p['paths']['source_exp1_protocol']))
    torch=source.prepare_environment(q)
    args=SimpleNamespace(model='old',checkpoint_run_dir=None,checkpoint_file=None)
    conf,model,key,meta=source.prepare_model(q,args,torch)
    assert meta['checkpoint_sha256']==p['checkpoint']['expected_sha256']
    assert int(meta['epoch'])==p['checkpoint']['expected_epoch']
    assert int(meta['step'])==p['checkpoint']['expected_step']
    assert int(meta['solver_n_iters'])==p['solver']['main_iterations']
    dest=root(p)
    write_json(dest/'run_fingerprint.json',fingerprint(p,source,meta))
    return source,lines,q,torch,conf,model,key


def make_problem(p,source,q,torch,conf,key,image_id,seed,stage):
    place=root(p)/stage/'acquisition'
    pcm_conf,trial,data,noise,pattern_hash,y_hash,gt_hash=source.make_case(
        q,image_id,seed,place,conf,key,torch)
    original=Path(p['paths']['source_exp1_results'])/'images'/f'{image_id:04d}'/seed['key']
    expected_y=np.load(original/'measurement.npy')
    expected_gt=np.load(original/'ground_truth.npy')
    expected_indices=np.load(original/'sampled_indices.npy')
    actual_y=trial.recon_input.y.detach().cpu().squeeze().numpy()
    actual_gt=trial.trial.target.detach().cpu().squeeze().numpy()
    actual_indices=np.asarray(trial.sampled_indices)
    assert np.array_equal(actual_indices,expected_indices)
    assert np.max(abs(actual_y-expected_y))<=1.e-5
    assert np.max(abs(actual_gt-expected_gt))<=1.e-6
    # The PCM acquisition preset owns the ground-truth intensity scaling.
    # It is distinct from the supervised U-TV model configuration.
    assert hasattr(pcm_conf, 'scaling') and hasattr(pcm_conf.scaling, 'scale')
    return pcm_conf,trial,data,noise,pattern_hash,y_hash,gt_hash,original


def timed_call(torch,fn):
    torch.cuda.synchronize()
    start=time.perf_counter()
    result=fn()
    torch.cuda.synchronize()
    return result,time.perf_counter()-start


def calculate_maps(p,torch,model,pcm_conf,trial,data,key,source_archive,save_dir=None):
    """One source measurement and a shared GT; only map source varies."""
    with torch.no_grad():
        y_map,t_y=timed_call(torch,lambda:model.estimate_lambda_map(data.model_input.input_image,key).detach())
        gt_model=pcm_conf.scaling.scale(trial.trial.target)
        assert gt_model.shape==data.model_input.input_image.shape
        gt_map,t_gt=timed_call(torch,lambda:model.estimate_lambda_map(gt_model,key).detach())
        gt_matched=match_map_mean(gt_map,y_map,eps=p['map_design']['mean_match_eps'])
        (edge_map,gt_grad,kappa),t_edge=timed_call(torch,lambda:ground_truth_edge_map(
            gt_model,y_map,percentile=p['map_design']['edge_gradient_positive_quantile'],
            minimum_weight=p['map_design']['edge_floor'],
            gradient_eps=p['map_design']['gradient_eps'],
            normalisation_eps=p['map_design']['mean_match_eps']))
    maps=dict(measured_cnn=y_map,gt_cnn_raw=gt_map,gt_cnn_meanmatched=gt_matched,
              gt_edge_meanmatched=edge_map,gt_gradient=gt_grad)
    map_validity(maps)
    original=np.load(source_archive/'fixed_lambda_map.npy')
    actual=y_map.detach().cpu().squeeze().numpy()
    max_error=float(np.max(abs(actual-original)))
    assert max_error<=2.e-4, f'Exp1 learned map differs, max error: {max_error}'
    gt_array=pcm_conf.scaling.scale(trial.trial.target).detach().cpu().squeeze().numpy()
    input_array=data.model_input.input_image.detach().cpu().squeeze().numpy()
    times=dict(map_predict_measured_s=t_y,map_predict_gt_s=t_gt,map_design_edge_s=t_edge)
    stats={name:map_statistics(value.detach().cpu().squeeze().numpy(),actual,
                              gt_grad.detach().cpu().squeeze().numpy())
           for name,value in maps.items() if name!='gt_gradient'}
    if save_dir is not None:
        save_dir.mkdir(parents=True,exist_ok=True)
        for name,value in maps.items():
            f=save_dir/(name+'.npy')
            if not f.exists():np.save(f,value.detach().cpu().squeeze().numpy())
        for name,array in [('gt_model',gt_array),('model_input_cg',input_array)]:
            f=save_dir/(name+'.npy')
            if not f.exists():np.save(f,array)
        meta_path=save_dir/'map_meta.json'
        if not meta_path.exists():
            write_json(meta_path,dict(
                checkpoint=sha256(Path(p['checkpoint']['run_dir'])/'checkpoints'/p['checkpoint']['filename']),
                measured_vs_exp1_max_abs=max_error,gradient_kappa=kappa,
                prediction_cost_seconds=times,statistics=stats))
    return maps, times, stats


def solve(p,torch,model,trial,data,key,lam,iterations):
    with torch.no_grad():
        x,elapsed=timed_call(torch,lambda:model(
            input_image=None,initial_image=data.model_input.initial_image,
            measurement=trial.recon_input.y,key=key,forward_op=data.forward_op,
            lambda_reg=lam,max_iterations=int(iterations),use_checkpoint=False))
        if not bool(torch.isfinite(x).all()):raise RuntimeError('Nonfinite PDHG solution')
    return x,elapsed


def evaluate_result(p,torch,pcm_conf,trial,data,noise,lines,spec,x):
    from LION.utils.metrics import compute_metrics
    xr=pcm_conf.scaling.rescale(x)
    scores=compute_metrics(recon=xr,target=trial.trial.target,data_range=trial.data_range)
    image=xr.detach().cpu().squeeze().numpy()
    ground_truth=trial.trial.target.detach().cpu().squeeze().numpy()
    lm=lines.line_metrics(image,ground_truth,spec,
                          p['evaluation'].get('ridge_thresholds',[0.015,0.025,0.04]))
    residual=float(torch.linalg.vector_norm(trial.recon_input.y-trial.recon_input.op(x)))
    return dict(psnr=float(scores['psnr']),ssim=float(scores['ssim']),
                haarpsi=float(scores['haarpsi']),mse=float(scores['mse']),
                residual_norm=residual,residual_to_noise=residual/noise,
                **lm),image


def method_variants(p,chosen):
    c=float(p['scale']['measured_calibrated'])
    if not chosen:
        return {'measured_c1':('measured_cnn',1.),'measured_c8':('measured_cnn',c),
                'gt_cnn_raw_c1':('gt_cnn_raw',1.),'gt_cnn_raw_c8':('gt_cnn_raw',c)}
    return {'measured_c1':('measured_cnn',1.),'measured_c8':('measured_cnn',c),
            'gt_cnn_raw_c1':('gt_cnn_raw',1.),'gt_cnn_raw_c8':('gt_cnn_raw',c),
            'gt_cnn_matched_calibrated':('gt_cnn_meanmatched',float(chosen['gt_cnn_meanmatched']['chosen_scale'])),
            'gt_edge_matched_calibrated':('gt_edge_meanmatched',float(chosen['gt_edge_meanmatched']['chosen_scale']))}


def step_smoke(p):
    source,lines,q,torch,conf,model,key=load_model_and_case(p)
    image_id=674;seed=p['data']['noise_seed_specs'][0]
    pcm_conf,trial,data,noise,_,_,_,archive=make_problem(p,source,q,torch,conf,key,image_id,seed,'smoke')
    maps,times,stats=calculate_maps(p,torch,model,pcm_conf,trial,data,key,archive)
    spec=lines.LineSpec.from_dict(q['line_annotations'][str(image_id)])
    rows=[]
    for name,(mapkind,scale) in method_variants(p,None).items():
        x,elapsed=solve(p,torch,model,trial,data,key,scale*maps[mapkind],16)
        scores,_=evaluate_result(p,torch,pcm_conf,trial,data,noise,lines,spec,x)
        rows.append(dict(method=name,scale=scale,steps=16,solve_s=elapsed,**scores))
    f=root(p)/'smoke'/'results.json'
    write_json(f,dict(status='passed',metrics=rows,map_cost=times,map_stats=stats,
                       note='Only 16 PDHG iterations, not a scientific result.'))
    print('GPU_SMOKE_PASS',f)


def _stage_rows(p,stage):return root(p)/stage/'metrics.csv'


def step_calibration(p):
    source,lines,q,torch,conf,model,key=load_model_and_case(p)
    scales=list(map(float,p['scale']['calibration_candidates']))
    kinds=p['scale']['selection_methods']
    records=read_records(_stage_rows(p,'calibration'))
    done={(int(a['image_id']),a['seed_key'],a['map_kind'],float(a['scale'])) for a in records}
    if len(done)!=len(records):raise RuntimeError('Duplicate calibration keys')
    for image_id in p['data']['image_ids']:
        spec=lines.LineSpec.from_dict(q['line_annotations'][str(image_id)])
        for seed in p['data']['noise_seed_specs']:
            if seed['split']!='calibration':continue
            todo=[(kind,c) for kind in kinds for c in scales
                  if (image_id,seed['key'],kind,c) not in done]
            if not todo:continue
            pcm_conf,trial,data,noise,pattern_hash,y_hash,gt_hash,archive=make_problem(
                p,source,q,torch,conf,key,image_id,seed,'calibration')
            maps,_,_=calculate_maps(p,torch,model,pcm_conf,trial,data,key,archive,
                  root(p)/'calibration/maps'/f'{image_id:04d}'/seed['key'])
            for kind,c in todo:
                x,sec=solve(p,torch,model,trial,data,key,c*maps[kind],p['solver']['main_iterations'])
                scores,_=evaluate_result(p,torch,pcm_conf,trial,data,noise,lines,spec,x)
                row=dict(image_id=image_id,seed_key=seed['key'],split=seed['split'],
                         map_kind=kind,scale=c,iterations=p['solver']['main_iterations'],
                         solve_s=sec,measurement_sha256=y_hash,
                         pattern_sha256=pattern_hash,ground_truth_sha256=gt_hash,**scores)
                add_row(_stage_rows(p,'calibration'),row)
                print('CALIBRATION',image_id,seed['key'],kind,c,
                      f'PSNR={scores["psnr"]:.3f}',flush=True)
    all_rows=read_records(_stage_rows(p,'calibration'))
    selection=select_by_calibration(all_rows,scales,kinds,p['data']['image_ids'],
        [v['key'] for v in p['data']['noise_seed_specs'] if v['split']=='calibration'])
    write_json(root(p)/'calibration'/'selection.json',dict(
        protocol_hash=sha256(PROTOCOL_PATH),
        only_calibration_used=True,selected=selection,
        measured_fixed_scale=8.0,
        note='Ground-truth oracle selection uses calibration images/noise only, NOT the held-out test seeds.'))
    print('SCALES_FROZEN',selection)


def require_selection(p):
    f=root(p)/'calibration/selection.json'
    if not f.is_file():raise RuntimeError('Complete calibration stage before test or timing')
    obj=json.loads(f.read_text())
    if obj['protocol_hash']!=sha256(PROTOCOL_PATH):raise RuntimeError('Protocol changed after calibration')
    return obj['selected']


def step_evaluate(p):
    chosen=require_selection(p)
    source,lines,q,torch,conf,model,key=load_model_and_case(p)
    methods=method_variants(p,chosen)
    outfile=_stage_rows(p,'evaluate')
    oldrows=read_records(outfile)
    done={(int(r['image_id']),r['seed_key'],r['method']) for r in oldrows}
    if len(done)!=len(oldrows):raise RuntimeError('Duplicate evaluation keys')
    for image_id in p['data']['image_ids']:
        spec=lines.LineSpec.from_dict(q['line_annotations'][str(image_id)])
        for seed in p['data']['noise_seed_specs']:
            if seed['split']!='test':continue
            todo=[m for m in methods if (image_id,seed['key'],m) not in done]
            if not todo:continue
            pcm_conf,trial,data,noise,pattern_hash,y_hash,gt_hash,archive=make_problem(
                p,source,q,torch,conf,key,image_id,seed,'evaluate')
            place=root(p)/'evaluate/images'/f'{image_id:04d}'/seed['key']
            maps,times,stats=calculate_maps(p,torch,model,pcm_conf,trial,data,key,archive,
                                            place/'maps')
            if not (place/'gt.npy').exists():
                place.mkdir(parents=True,exist_ok=True)
                np.save(place/'gt.npy',trial.trial.target.detach().cpu().squeeze().numpy())
            for name in todo:
                kind,c=methods[name]
                x,sec=solve(p,torch,model,trial,data,key,c*maps[kind],p['solver']['main_iterations'])
                scores,img=evaluate_result(p,torch,pcm_conf,trial,data,noise,lines,spec,x)
                if name in ('measured_c1','measured_c8'):
                    exp1file=archive/('c_'+f'{float(c):.10f}'.replace('.','p').replace('-','m')+'.npy')
                    # First show that both reconstructions truly reproduce Exp1.
                    if exp1file.is_file():
                        err=float(np.max(abs(np.load(exp1file)-img)))
                        if err>1.e-4:raise RuntimeError(f'Exp1 baseline mismatch {name}: {err}')
                outfileimg=place/(name+'.npy')
                np.save(outfileimg,img)
                row=dict(image_id=image_id,seed_key=seed['key'],split='test',
                         method=name,map_kind=kind,scale=float(c),
                         iterations=p['solver']['main_iterations'],
                         solve_s=sec,map_predict_measured_s=times['map_predict_measured_s'],
                         map_predict_gt_s=times['map_predict_gt_s'],
                         map_design_edge_s=times['map_design_edge_s'],
                         measurement_sha256=y_hash,pattern_sha256=pattern_hash,
                         ground_truth_sha256=gt_hash,**scores)
                add_row(outfile,row)
                print('TEST',image_id,seed['key'],name,c,
                      f'PSNR={scores["psnr"]:.3f}',flush=True)
    expected=4*3*len(methods)
    rows=read_records(outfile)
    assert len(rows)==expected,('Incomplete test',len(rows),expected)
    print('EVALUATION_COMPLETE',len(rows),outfile)


def step_timing(p):
    chosen=require_selection(p)
    source,lines,q,torch,conf,model,key=load_model_and_case(p)
    methods={k:v for k,v in method_variants(p,chosen).items()
             if k in p['solver']['timing_methods']}
    depths=p['solver']['diagnostic_iterations']
    reps=int(p['solver']['timing_repeats'])
    outfile=_stage_rows(p,'timing')
    oldrows=read_records(outfile)
    done={(int(r['image_id']),r['seed_key'],r['method'],int(r['iterations'])) for r in oldrows}
    if len(done)!=len(oldrows):raise RuntimeError('Duplicate timing keys')
    for image_id in p['data']['image_ids']:
        spec=lines.LineSpec.from_dict(q['line_annotations'][str(image_id)])
        for seed in p['data']['noise_seed_specs']:
            if seed['split']!='test':continue
            todo=[(n,k) for n in methods for k in depths
                  if (image_id,seed['key'],n,k) not in done]
            if not todo:continue
            pcm_conf,trial,data,noise,pattern_hash,y_hash,gt_hash,archive=make_problem(
                p,source,q,torch,conf,key,image_id,seed,'timing')
            maps,_,_=calculate_maps(p,torch,model,pcm_conf,trial,data,key,archive)
            place=root(p)/'timing/images'/f'{image_id:04d}'/seed['key']
            place.mkdir(parents=True,exist_ok=True)
            # First short PDHG warmup to avoid measuring first-use overhead.
            kind,c=methods['measured_c8']
            solve(p,torch,model,trial,data,key,c*maps[kind],p['solver']['warmup_iterations'])
            # Fixed, deterministic randomised method/iteration ordering to reduce bias.
            rng=np.random.default_rng(20261028+image_id+int(seed['noise_seed']))
            rng.shuffle(todo)
            for method_name,iterations in todo:
                kind,c=methods[method_name]
                measured=[]
                xlast=None
                for _ in range(reps):
                    x,seconds=solve(p,torch,model,trial,data,key,c*maps[kind],iterations)
                    measured.append(seconds)
                    if xlast is None:xlast=x
                scores,img=evaluate_result(p,torch,pcm_conf,trial,data,noise,lines,spec,xlast)
                np.save(place/(method_name+f'_steps_{iterations:04d}.npy'),img)
                row=dict(image_id=image_id,seed_key=seed['key'],method=method_name,
                         map_kind=kind,scale=float(c),iterations=iterations,
                         repeats=reps,measurement_sha256=y_hash,
                         pattern_sha256=pattern_hash,ground_truth_sha256=gt_hash,
                         **timed_statistics(measured),**scores)
                add_row(outfile,row)
                print('TIMING',image_id,seed['key'],method_name,iterations,
                      f'{row["time_median_s"]:.4f}s',flush=True)
    rows=read_records(outfile)
    expected=4*3*len(methods)*len(depths)
    assert len(rows)==expected,(len(rows),expected)
    print('TIMING_COMPLETE',len(rows),outfile)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--phase',required=True,choices=('preflight','smoke','calibration','evaluate','timing'))
    args=parser.parse_args()
    p=load()
    if args.phase=='preflight':preflight(p);return
    {'smoke':step_smoke,'calibration':step_calibration,'evaluate':step_evaluate,
     'timing':step_timing}[args.phase](p)

if __name__=='__main__': main()
