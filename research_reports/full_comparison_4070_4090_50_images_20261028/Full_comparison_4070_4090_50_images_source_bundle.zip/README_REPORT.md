# Full comparison of 4070 and 4090 trainings — 50-image repeat (28 October 2026)

## Deliverables

- `Full_comparison_4070_4090_50_images.pdf`: completed full scientific report (21 A4 pages).
- `Full_comparison_4070_4090_50_images.tex`: editable LaTeX report. Compile with `latexmk -pdf` beside `figures/*.pdf`.
- `figures/`: nine zoomable figure PDFs and matching PNG previews, including image reconstructions and absolute error maps with shared display scales.
- `summary_50.json`: complete mean, CI, category, noise and sampling-bin statistics.
- `all_paired_results_old_new.csv`: 100 acquisition rows, with metrics for all four frozen checkpoints.
- `protocol_manifest_50.json`: reproducible 50-image selection, provenance and checkpoint hashes.
- `evaluate_current_50.py`, `summarize_50.py`, `make_figures.py`, `build_report_50.py`: source code for evaluation, statistics, charts and TeX.
- `old_reference_metrics_subset.csv`: subset of exact old 450-image independent test results.
- `example_{category}_{condition}.npz`: qualitative ground truth, zero-filled image, and current checkpoint reconstructions on ten preselected acquisitions.

The source bundle intentionally excludes large model checkpoint binaries (total ~784 MiB). Those remain under this directory on tuni. Re-compiling the report from the source bundle does not require those binaries; rerunning inference does.

## Protocol and cautions

The test images were not used for fitting or validation but had been evaluated in the earlier 450-image full comparison. The 50-image repeat is **not** an untouched new test. See report for details.

The evaluation was done on RTX 4070 with both currently running model checkpoints frozen before testing. All 100 acquisitions exactly match SHA-256 measurement and pattern checksums from the 27 October full comparison.
